// global vars for console access
var sys;
var ff;
var network_instance;
var env_instance;
var interfaces = {
  network_in : null,
  network_out : null,
  env_in : null,
  env_out : null
};
var send_message = function (msg, channel) {
  env_instance.sendMessageViaInterface(msg, interfaces.env_out, channel);
};


(function($) {

  var Renderer = function(canvas) { // TODO Consider moving to Arbor support module
    var canvas = $(canvas).get(0);
    var ctx = canvas.getContext("2d");
    var particleSystem;

    var that = {
      init:function(system) {
        //
        // the particle system will call the init function once, right before the
        // first frame is to be drawn. it's a good place to set up the canvas and
        // to pass the canvas size to the particle system
        //
        // save a reference to the particle system for use in the .redraw() loop
        particleSystem = system;

        // inform the system of the screen dimensions so it can map coords for us.
        // if the canvas is ever resized, screenSize should be called again with
        // the new dimensions
        particleSystem.screenSize(canvas.width, canvas.height);
        particleSystem.screenPadding(80); // leave an extra 80px of whitespace per side
        
        // set up some event handlers to allow for node-dragging
        that.initMouseHandling();
      },
      
      redraw:function() {
        // 
        // redraw will be called repeatedly during the run whenever the node positions
        // change. the new positions for the nodes can be accessed by looking at the
        // .p attribute of a given node. however the p.x & p.y values are in the coordinates
        // of the particle system rather than the screen. you can either map them to
        // the screen yourself, or use the convenience iterators .eachNode (and .eachEdge)
        // which allow you to step through the actual node objects but also pass an
        // x,y point in the screen's coordinate system
        // 
        
        ctx.fillStyle = "white";
        ctx.fillRect(0,0, canvas.width, canvas.height);
        ctx.font = "12px Arial";
        
        particleSystem.eachEdge(function(edge, pt1, pt2) {
          // edge: {source:Node, target:Node, length:#, data:{}}
          // pt1:  {x:#, y:#}  source position in screen coords
          // pt2:  {x:#, y:#}  target position in screen coords

          // draw a line from pt1 to pt2
          if (edge.data.activated === true) {
            edge.data.activated = undefined;
            edge.data.thickness = 2;
            
            // Move node back a bit
            var x1 = edge.source.p.x;
            var x2 = edge.target.p.x;
            var y1 = edge.source.p.y;
            var y2 = edge.target.p.y;
            
            var ex = x1 - x2;
            var ey = y1 - y2;
            
            var emag = Math.sqrt(ex * ex + ey * ey);
            var mag = 0.15;
            
            ex = mag * ex / emag;
            ey = mag * ey / emag;
            
            edge.source.p.x = edge.source.p.x + ex;
            edge.source.p.y = edge.source.p.y + ey;
            
          } else if (edge.data.thickness !== undefined) {
            edge.data.thickness -= 0.04;
            if (edge.data.thickness < 0.5) {
              edge.data.thickness = undefined;
            }
          }
          
          if (edge.data.thickness === undefined) {
            ctx.strokeStyle = "rgba(0,0,0, .333)";
            ctx.lineWidth = 1;
          } else {
            ctx.strokeStyle = "rgba(0,0,0, " + edge.data.thickness + ")";
            ctx.lineWidth = edge.data.thickness;
          }
          
          var headlen = 10;   // length of head in pixels
          var angle = Math.atan2(pt2.y-pt1.y,pt2.x-pt1.x);
          ctx.fillStyle = "rgba(0,0,0, .3)";
          ctx.fillText(edge.data.name,(((pt1.x + pt2.x))/2 + 15),(((pt1.y + pt2.y)/2) + 3));
          ctx.beginPath();
          ctx.moveTo(pt1.x, pt1.y);
          ctx.lineTo(pt2.x, pt2.y);
          ctx.lineTo(pt2.x-headlen*Math.cos(angle-Math.PI/6),pt2.y-headlen*Math.sin(angle-Math.PI/6));
          ctx.moveTo(pt2.x, pt2.y);
          ctx.lineTo(pt2.x-headlen*Math.cos(angle+Math.PI/6),pt2.y-headlen*Math.sin(angle+Math.PI/6));
          ctx.stroke();
          
          //console.log(edge.name);
        })

        particleSystem.eachNode(function(node, pt) {
          // node: {mass:#, p:{x,y}, name:"", data:{}}
          // pt:   {x:#, y:#}  node position in screen coords

          // draw a rectangle centered at pt
          var w = node.data.size;
          if (w === undefined) {
            node.data.size = 3;
            w = 1;
          }
          
          // Set the node colour
          var f = "black";
          if (node.data.input)
            f = "orange";
          if (node.data.output)
            f = "blue";
          
          // Draw circle to represent the node
          ctx.beginPath();
          ctx.fillStyle = f;
          ctx.arc(pt.x,pt.y,w,0,2*Math.PI);
          ctx.stroke();
          
          // Print the node id next to the circle
          ctx.fillText(node.name,pt.x+15,pt.y+3);
          
        })    			
      },
      
      initMouseHandling:function() {
        // no-nonsense drag and drop (thanks springy.js)
        var dragged = null;

        // set up a handler object that will initially listen for mousedowns then
        // for moves and mouseups while dragging
        var handler = {
          clicked:function(e) {
            var pos = $(canvas).offset();
            _mouseP = arbor.Point(e.pageX-pos.left, e.pageY-pos.top);
            dragged = particleSystem.nearest(_mouseP);

            /*if (dragged.node.name === 'a') {
              _mouseP = null;
              dragged = null;
              return
            }*/

            if (dragged && dragged.node !== null) {
              // while we're dragging, don't let physics move the node
              dragged.node.fixed = true;
            }

            $(canvas).bind('mousemove', handler.dragged);
            $(window).bind('mouseup', handler.dropped);

            return false;
          },
          dragged:function(e) {
            var pos = $(canvas).offset();
            var s = arbor.Point(e.pageX-pos.left, e.pageY-pos.top);

            if (dragged && dragged.node !== null) {
              var p = particleSystem.fromScreen(s);
              dragged.node.p = p;
            }

            return false;
          },

          dropped:function(e){
            if (dragged===null || dragged.node===undefined) return;
            if (dragged.node !== null) dragged.node.fixed = false;
            dragged.node.tempMass = 1000;
            dragged = null;
            $(canvas).unbind('mousemove', handler.dragged);
            $(window).unbind('mouseup', handler.dropped);
            _mouseP = null;
            return false;
          }
        }
        
        // start listening
        $(canvas).mousedown(handler.clicked);

      },
      
    }
    return that;
  }
  
  Spock.onReady(function() {
    Spock.loadData.printSummary();
    
    //Spock.Tools.enableProgressLogging = true;
    //Spock.Tools.enableFunctionLogging = true;
    
    // Define arbor instance
    console.log('Starting arbor instance');
    arbor_instance = arbor.ParticleSystem(1000, 600, 0.5) // create the system with sensible repulsion/stiffness/friction
    arbor_instance.parameters({gravity:true}) // use center-gravity to make the graph settle nicely (ymmv)
    arbor_instance.renderer = Renderer("#viewport") // our newly created renderer will have its .init() method called shortly by sys...
    
    // Define network instance
    console.log('Starting network instance');
    network_instance = Spock.Network.networks.newNeuralNetwork(9009);
    
    // Set custom edge colouring function
    network_instance.connectionFunctions = {};
    network_instance.connectionFunctions.sendSignalViaConnection = function (signal, connectionID, network, senderNodeID) {
      arbor_instance.edges[connectionID].data.activated = true;
      Network.connections.sendSignalViaConnection(signal, connectionID, network, senderNodeID, true);
    }
    
    // Develop the initial node template
    var template = Templates.getModuleCopy('STORE_SignalQueue');
    template = Templates.combine(template, Templates.getModuleCopy('TS_WeightedSelection'));
    template = Templates.combine(template, Templates.getModuleCopy('Feedback_Learning'));
    
    // Build initial network
    var layerSize = 2;
    ff = network_instance.addNodesByPattern('FeedForward', template, {layerSize : layerSize,
                                                                      layerQuantity : 5,
                                                                      arrayLayers : null});
     
    
    // Set up basic environment
    env_instance = Environment.newEnvironment(9010, 'Testing');
    EnvironmentTemplates.loadTemplateIntoExistingEnvironment("HTMLManualTest", env_instance);
    
    // Set up interfaces
    interfaces.network_in = Spock.Common.createInterface(network_instance, layerSize, true, "network");
    Spock.Common.connectNodesToInterfaceByRange(network_instance, interfaces.network_in, ff.start); 
    
    interfaces.network_out = Spock.Common.createInterface(network_instance, layerSize, false, "network");
    Spock.Common.connectNodesToInterfaceByRange(network_instance, interfaces.network_out, ff.end); 
    
    var net_in_int = network_instance.getComponentByID(interfaces.network_in);
    var old_callback = net_in_int.messagecallback;
    net_in_int.messagecallback = function(signal, channel) { // Set graph sending behaviour for input interface, TODO find better way to integrate this with the program structure
      var target = net_in_int.channelToNodeIDMap[channel];
      var targets = arbor_instance.getEdgesFrom(net_in_int.getid);
      
      for (var e in targets) {
        if (targets[e].target.name === target) {
          targets[e].data.activated = true;
          break;
        }
      }
      old_callback(signal, channel);
    }
    
    interfaces.env_in = Spock.Common.createInterface(env_instance, layerSize, true, function (signal, channel) {
      console.log('Environment received message "' + signal.toString() + '" on channel "' + channel + '"');
      
      var results = $('#results');
      var children = results.children();
      
      // TODO Make this better! (replace most interface functionality by nodes)
      var env = env_instance.getInterfaceByID(interfaces.env_in);
      var nid = env.foreignInterfacingContext.getComponentByID(env.connectedToInterfaceID).channelToNodeIDMap[channel];
      var n = env.foreignInterfacingContext.getComponentByID(nid);
      n.accept(signal, interfaces.env_in);
      
      var msg = '<p>Message received by channel '+channel+': ' + signal.toString();
      msg += ' <a href="#" onClick="">reward</a> ';
      msg += ' <a href="#" onClick="">punish</a> ';
      msg += '</p>';
      if (children.length === 0) {
        results.append(msg);
      } else {
        children.first().before(msg);
        if (children.length > 10) {
          children.last().remove();
        }
      }
    });
    interfaces.env_out = Spock.Common.createInterface(env_instance, layerSize, false, null);
    
    // Connect interfaces
    console.log('Attempting to connect environment -> network');
    console.log(Spock.Common.connectInterfacesViaContexts('programmatic', network_instance, interfaces.network_in, env_instance, interfaces.env_out));
    console.log('Attempting to connect network -> environment');
    console.log(Spock.Common.connectInterfacesViaContexts('programmatic', env_instance, interfaces.env_in, network_instance, interfaces.network_out));
    
    // Add onclick handler to buttons
    var buttons = $('button.test.input');
    env_instance.AttachManaulInputFunctionToObject(buttons, env_instance, interfaces.env_out);
    
    // Integrate arbor and network instances
    console.log('Integrating');
    Spock.ArborSupport.integrate(network_instance, arbor_instance);
    
    
    
    /*
    
    Idea for arbor integration
    
    Init a network as per normal. Have separte module, Spock.arborSupport, that when you're ready, you feed it a reference to the network (Spock.arborSupport.enableForNetwork(network)) which adds hooks into each node so that they can be changed in the visualisation and also scans the current nodes and adds then to the graph.
    
    */
    
    network_instance.printNodes = function () {
      for (var i = 1; i <= 4; i++) { 
        var cs = network_instance.getComponentByID(i).STORE.getConnections(); 
        for (var c in cs) { 
          var outs = network_instance.getComponentByID(c).nodes; 
          for (var m in outs) { 
            console.log(i + ' -> ' + m + '('+(outs[m]?'in':'out')+') via connection ' + c); 
          } 
        }
      }
    };
    
  });
  
})(this.jQuery)
