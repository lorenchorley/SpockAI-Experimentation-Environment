SpockJS
=======

This is a modest attempt at a neural network based on Javascript and NodeJS with a focus on rapid development and ease of use for testing concepts.
