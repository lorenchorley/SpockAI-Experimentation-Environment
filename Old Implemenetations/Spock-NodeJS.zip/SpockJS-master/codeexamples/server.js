var LC = require('./LC');
var http = require('http');

var ip = LC.Tools.getLocalAddress();
var port;
if (process.argv[2] !== undefined) {
  port = process.argv[2];
} else {
  port = 1337;
}


var srv = http.createServer(function (req, res) {
  req.on('data', function(data) {
    console.log('data ' + data);
  });
  req.on('end',  function() {
    console.log('end');
  });

  res.writeHead(200, {'Content-Type': 'text/plain'});
  res.end('Hello World from ' + req.connection.remoteAddress + '\n');
  //Tools.printObjectMethods(req, 1);
  console.log("Recieved message from: " + req.headers.host);
  
}).listen(port, ip);

    
console.log('Started server. (http://' + ip + ':' + port + '/)');

