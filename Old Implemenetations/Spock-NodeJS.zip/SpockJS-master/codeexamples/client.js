var LC = require('./LC')
var http=require('http');

var ip, port;
if (process.argv[2] !== undefined) {
  ip = process.argv[2];
} else {
  ip = LC.Tools.getLocalAddress();
}

if (process.argv[3] !== undefined) {
  port = process.argv[3];
} else {
  port = 1337;
}

console.log('Attempting to connect to server. (http://' + ip + ':' + port + '/)');


httpOptions = {
  'host': ip,
  'port': port,
  'path': '/',
  'method': 'POST'
};

var callback = function (msg) {
  console.log('callback: ' + msg);
};

var req = http.request(httpOptions, function(res) {
    res.setEncoding('utf8');
});

req.on('response', function (response) {

    response.on('data', function (chunk) {
        console.log('data' + chunk);
    });

    response.on('end', function(){
        console.log('end');
    })

});

req.on('error', function(e) {
    callback(e);
});

req.write("message from client");
req.end();
