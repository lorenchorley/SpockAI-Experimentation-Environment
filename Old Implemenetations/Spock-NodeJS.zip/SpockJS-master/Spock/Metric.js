var Metric = {};

Metric.init = function (gns) {
  Spock = gns;
  Metric.initialised = true;
};



if (typeof Spock === 'undefined') { // NodeJS
  var Spock = {};
  module.exports = Metric;
} else { // Javascript
  Spock.Metric = Metric;
}
