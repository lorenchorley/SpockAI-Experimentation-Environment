var Common = {};

Common.init = function (gns) {
  Spock = gns;
  Common.initialised = true;
};

Common.addInterfacingCapability = function (context, port) {
  Spock.Tools.logFunction("Common.addInterfacingCapability", context.contextClass, port);
  
  var interfaces = {};
  context.interfacingPort = port;
  context.server = null;
  
  context.getInterfaces = function () {
    return interfaces;
  };
  
  context.getInterfaceByID = function (id) {
    Spock.Tools.logFunction("InterfacingInstance.getInterfaceByID", id); 
    return interfaces[id];
  };
  
  context.hasInterface = function (id) {
    return interfaces[id] !== undefined;
  };
  
};

Common.createInterface = function (context, channelquantity, isinput, messagecallback) {
  Spock.Tools.logFunction("Common.createInterface", context.contextClass, channelquantity, isinput, messagecallback);
  
  var int = {};
  int.getid = context.getUID();
  int.connectionType = null;
  int.connectedToURL = '';
  int.foreignInterfacingContext = null;
  int.connectedToInterfaceID = '';
  int.channelquantity = channelquantity;
  int.channelToNodeIDMap = {}; // Generate sequentially from 1
  for (var i = 1; i <= channelquantity; i++) {
    int.channelToNodeIDMap[i] = null; // maps the channel i to node with id i
  }
  
  // Insert appropriate callback for receiving messaging
  int.isinput = isinput;
  if (isinput) {
    if (messagecallback === "network") {
      int.messagecallback = function(signal, channel) {
        //console.log('(network_in) msg: ' + msg + ' channel: ' + channel);
        
        var id = int.channelToNodeIDMap[channel];
        var node = network_instance.getComponentByID(id);
        var singal = Network.newStringSignal(signal);
        
        node.accept(signal, null);
      }
    } else if (messagecallback !== undefined || messagecallback !== null) {
      int.messagecallback = messagecallback;
    } else {
      //Error
    }
  }
  
  // register in interface array and the components array
  if (typeof(context.interfaceVerifier) === 'function') {
    if (context.interfaceVerifier(int)) {
      context.getInterfaces()[int.getid] = int;
      context.getComponents()[int.getid] = int;
    } else {
      console.log('Error, interface could not be verified');
    }
  } else {
    context.getInterfaces()[int.getid] = int;
    context.getComponents()[int.getid] = int;
  }
  
  return int.getid;
}; 

Common.createInterfaceByRange = function (context, range, isinput, messagecallback) {
  Spock.Tools.logFunction("Common.createInterfaceByRange", context.contextClass, range, isinput, messagecallback);
  
  // insert magic
  var magic;
  
  var id = context.createInterface(magic, isinput, messagecallback);
  var int = context.getInterfaceByID(id);
  int.channelToNodeIDMap = magic;
  
  return id;
};

Common.createInterfaceByMap = function (context, channelToNodeIDMap, isinput, messagecallback) {
  Spock.Tools.logFunction("Common.createInterfaceByMap", context.contextClass, channelToNodeIDMap, isinput, messagecallback);
  
  // insert magic
  
  //TODO check to make sure there are a consecutive set of numbers, each with a valid node id
  
  var id = context.createInterface(magic, isinput, messagecallback);
  var int = context.getInterfaceByID(id);
  int.channelToNodeIDMap = channelToNodeIDMap;
  //int.nodeIDToChannelMap = magic;
  
  return id;
};

Common.connectNodeToInterface = function (context, interfaceID, nodeID) {
  Spock.Tools.logFunction("Common.connectNodeToInterface", context.contextClass, interfaceID, nodeID);
  
  var int = context.getInterfaceByID(interfaceID);
  if (int === undefined) {
    Tools.logError('connectNodeToInterface: Unknown interface ID: ' + interfaceID);
    return;
  }
  var node = context.getComponentByID(nodeID);
  if (node === undefined) {
    Tools.logError('connectNodeToInterface: Unknown node ID: ' + nodeID);
    return;
  } else if (node.componentClass !== "n") {
    Tools.logError('connectNodeToInterface: Unknown node ID: ' + nodeID);
    return; 
  }
  
  var contextFunctions = null;
  
  if (context.contextClass === 'network') {
    contextFunctions = Network;
  } else {
    Tools.logError('connectNodeToInterface: Unsupported context class');
    return;
  }
  
  var found = false;
  for (var i = 1; i <= int.channelquantity; i++) {
    if (int.channelToNodeIDMap[i] === undefined || int.channelToNodeIDMap[i] === null || int.channelToNodeIDMap[i] === "") {
      int.channelToNodeIDMap[i] = nodeID;
      var connection = context.newConnection();
      var connectionID = connection.getid();
      contextFunctions.connectNodeToConnection(context, connectionID, nodeID, !int.isinput);
      contextFunctions.connectInterfaceToConnection(context, connectionID, interfaceID, int.isinput, i);
      found = true;
      break;
    }
  }
  if (!found) {
    Tools.logError('connectNodeToInterface: Not enough space in interface to add node with ID ' + nodeID);
  }
  
};

Common.connectNodesToInterfaceByRange = function (context, interfaceID, range) {
  Spock.Tools.logFunction("Common.connectNodesToInterfaceByRange", context.contextClass, interfaceID, range); 
  
  var start = Number(range.start);
  var end = Number(range.end); 
  
  // TODO e4or check sts5 anf end here
  
  Tools.logProgress("Connecting nodes to interface by range: " + start + " - " + end);
  
  for (var i = start; i <= end; i++) {
    Spock.Common.connectNodeToInterface(context, interfaceID, i); 
  }
  
};

Common.connectNodeToInterfaceByMap = function (context, interfaceID, map) {
  Spock.Tools.logFunction("Common.connectNodeToInterfaceByMap", context.contextClass, interfaceID, map); 
  //TODO
  //
};

Common.disconnectInterace = function (context, interfaceID) {
  Spock.Tools.logFunction("Common.connectInterfacesViaContexts", context.contextClass, interfaceID);
  
  if (!context.hasInterface(interfaceID)) {
    return "failure: no such interface";
  }

  var li = context.getInterfaceByID(interfaceID);
  
  if (li.connectedToInterfaceID === '') {
    return "failure";
  }
  
  if (li.connectionType === 'programmatic') {
    var foreignInterfacingContext = li.foreignInterfacingContext;
    var fi = foreignInterfacingContext.getInterfaceByID(li.connectedToInterfaceID);
    
    li.connectedToInterfaceID = '';
    fi.connectedToInterfaceID = '';
    li.foreignInterfacingContext = null;
    fi.foreignInterfacingContext = null;
    li.connectionType = null;
    fi.connectionType = null;
    
    return "success";
  } else if (li.connectionType === 'localhost') {
    //TODO
  } else if (li.connectionType === 'web') {
    //TODO
  } else {
    return "failure: unknown connection type " + li.connectionType;
  }
  
};

Common.connectInterfacesViaContexts = function (method, context, interfaceID, foreignInterfacingContext, foreignInterfaceID) {
  Spock.Tools.logFunction("Common.connectInterfacesViaContexts", context.contextClass, method, interfaceID, foreignInterfacingContext, foreignInterfaceID);
  
  if (!context.hasInterface(interfaceID)) {
    return "failure: no such interface";
  }

  var li = context.getInterfaceByID(interfaceID);
  
  if (method === "programmatic") {
  
    var fi = foreignInterfacingContext.getInterfaceByID(foreignInterfaceID);
    
    if (li.connectedToInterfaceID === "" && fi.connectedToInterfaceID === "" && li.isinput !== fi.isinput && li.channelquantity === fi.channelquantity) {
      li.connectedToInterfaceID = fi.getid;
      fi.connectedToInterfaceID = li.getid;
      li.foreignInterfacingContext = foreignInterfacingContext;
      fi.foreignInterfacingContext = context;
      li.connectionType = "programmatic";
      fi.connectionType = "programmatic";
      return "success";
    } else {
      return "failure";
    }
    
  } else if (li.connectionType === 'localhost') {
    //TODO
  } else if (li.connectionType === 'web') {
    //TODO
  } else {
    return "failure: unknown connection type " + li.connectionType;
  }
};

Common.acceptIncomingMessageViaInterface = function (context, msg, interfaceID, channel) {
  Spock.Tools.logFunction("Common.acceptIncomingMessageViaInterface", context.contextClass, msg, interfaceID, channel);
  
  if (!context.hasInterface(interfaceID)) {
    return "failure: no such interface";
  }
  
  var li = context.getInterfaceByID(interfaceID);
  
  if (li.isinput) {
    li.messagecallback(msg, channel);
    
    return "success";
  } else {
    return "failure: is not input interface";
  }
  
};

Common.sendMessageViaInterface = function (context, msg, interfaceID, channel) {
  Spock.Tools.logFunction("sendMessageViaInterface", context.contextClass, msg, interfaceID, channel);
  
  if (!context.hasInterface(interfaceID)) {
    return "failure: no such interface";
  }
  
  var li = context.getInterfaceByID(interfaceID);
  
  if (li.connectedToInterfaceID === '') {
    return "failure: not connected";
  }
  if (li.channel < 1 || li.channel > li.channelquantity) {
    return "failure: invalid channel";
  }
  if (li.isinput) {
    return "failure: interface is not an output interface ";
  }
  
  if (li.connectionType === 'programmatic') {
    var foreignInterfacingContext = li.foreignInterfacingContext;
    var fiID = li.connectedToInterfaceID;
    
    return Spock.Common.acceptIncomingMessageViaInterface(foreignInterfacingContext, msg, fiID, channel);
    
  } else if (li.connectionType === 'localhost') {
    //TODO
  } else if (li.connectionType === 'web') {
    //TODO
  } else {
    return "failure: unknown connection type " + li.connectionType;
  }
};

Common.saveInterfaceState = function (context, interfaceID) {
  Spock.Tools.logFunction("Common.saveInterfaceState", context.contextClass, interfaceID); 
  // TODO
  
};

Common.loadInterfaceState = function (state) { // TODO
  Spock.Tools.logFunction("Common.loadInterfaceState", context.contextClass, interfaceID); 
  
};



if (typeof Spock === 'undefined') { // NodeJS
  var Spock = {};
  module.exports = Common;
} else { // Javascript
  Spock.Common = Common;
}
