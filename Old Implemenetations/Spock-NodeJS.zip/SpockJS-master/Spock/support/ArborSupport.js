if (typeof Spock === 'undefined') {
  console.log('This support library is only designed for use by a browser-based version of Javascript, and requires that the Spock namebase be loaded first.');
}

Spock.ArborSupport = function() {
  var that = {};
  
  var integration_template = {
    LC : {
      onBirth : function () {
        Spock.Tools.logFunction('ArborSupport.LC.onBirth');
        //node.network.arbor_instance.addNode(node.getid());
      },
      onDeath : function () { 
        Spock.Tools.logFunction('ArborSupport.LC.onDeath');
        node.network.arbor_instance.removeNode(node.getid());
      }
    },
    EM : {
      onSignalRecieved : function (node) {
        Spock.Tools.logFunction('ArborSupport.EM.onSignalRecieved');
        
        var data = node.network.arbor_instance.getNode(node.getid()).data;
        
        if (data.size === undefined) {
          data.size = 3;
        } else {
          data.size++;
        }
        
        node.network.arbor_instance.renderer.redraw();
      },
      onSignalSent : function (node) { 
        Spock.Tools.logFunction('ArborSupport.EM.onSignalSent');
        
        var data = node.network.arbor_instance.getNode(node.getid()).data;
        
        if (data.size === undefined || data.size <= 3) {
          data.size = 3;
        } else {
          data.size--;
        }
        
        node.network.arbor_instance.renderer.redraw();
      }
    }
  };
  
  that.init = function (gns) {
    that.initialised = true;
  };
  
  that.integrate = function (network_instance, arbor_instance) {
    var nodes = network_instance.getComponents();
    network_instance.arbor_instance = arbor_instance;
    arbor_instance.network_instance = network_instance;
    
    for (var n in nodes) {
      if (nodes[n].componentClass === "n") {
        // Add nodes to arbor instance
        arbor_instance.addNode(nodes[n].getid());
        // Add new node template to existing nodes
        Network.addTemplateFunctionsToNode(integration_template, nodes[n]);
      }
    }
    // Add interfaces
    var interfaces = network_instance.getInterfaces();
    for (var i in interfaces) {
      var an = arbor_instance.addNode(i);
      if (interfaces[i].isinput) {
        an.data.input = true;
        /*for (var c in interfaces[i].channelToNodeIDMap) {
          arbor_instance.addEdge('int' + i, interfaces[i].channelToNodeIDMap[c]); // Add edges
        }*/
      } else {
        an.data.output = true;
        /*for (var c in interfaces[i].channelToNodeIDMap) {
          arbor_instance.addEdge(interfaces[i].channelToNodeIDMap[c], 'int' + i); // Add edges
        }*/
      }
    }
    
    // Add edges
    arbor_instance.edges = {};
    for (var n in nodes) {
      if (nodes[n].componentClass === "n") {
        var connections = nodes[n].STORE.getConnections();
        for (var c in connections) {
          var connectedNodes = network_instance.getComponentByID(c).nodes;
          var connectedInterfaces = network_instance.getComponentByID(c).interfaces;
          for (var o in connectedNodes) { // Nodes in connection
            if (!connectedNodes[o]) {
              var edge = arbor_instance.addEdge(n, o);
              arbor_instance.edges[c] = edge;
              edge.data.name = c;
            }
          }
          for (var o in connectedInterfaces) { // Interfaces in connection
            var channels = connectedInterfaces[o];
            for (var ch in channels) { // channels in interface
              if (!channels[ch]) {
                var edge = arbor_instance.addEdge(n, o);
                arbor_instance.edges[c] = edge;
                edge.data.name = c;
              }
            }
          }
        }
      }
    }
    var interfaces = network_instance.getInterfaces();
    for (var i in interfaces) {
      if (interfaces[i].isinput) {
        var map = interfaces[i].channelToNodeIDMap;
        for (var c in map) {
          arbor_instance.addEdge(i, map[c]);

          // Add edge ids
        }
      }
    }
    // Change display interface nodes
    
  };
  
  return that;
}();
