var NodeTemplates = {};

NodeTemplates.init = function (gns) {
  LC = gns;
  NodeTemplates.initialised = true;
};



if (typeof LC === 'undefined') { // NodeJS
  var LC = {};
  module.exports = NodeTemplates;
} else { // Javascript
  LC.NodeTemplates = NodeTemplates;
}
