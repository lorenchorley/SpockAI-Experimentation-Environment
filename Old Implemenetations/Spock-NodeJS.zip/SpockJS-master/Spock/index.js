dependencies = {};
dependencies.Tools = './Tools';
dependencies.Network = './Network';
dependencies.Environment = './Environment';
dependencies.Metric = './Metric';
dependencies.Common = './Common';
//dependencies.NodeTemplates = './NodeTemplates';
dependencies.EnvironmentTemplates = './EnvironmentTemplates';
//dependencies.NetworkTemplates = './NetworkTemplates';
dependencies.Templates = './templates/'; //Deprecated

if (typeof module === 'undefined') { // Javascript
  
  // Specific dependencies
  dependencies.ArborSupport = './support/ArborSupport';
  
  var Spock = {};
  Spock.runtime = 'js';
  
  Spock.loadData = {};
  Spock.loadData.spockLoaded = false;
  Spock.loadData.documentLoaded = false;
  Spock.loadData.retryInterval = 300;
  Spock.loadData.retryLimit = 50;
  Spock.loadData.startTime = new Date();
  Spock.loadData.loadingTime = 'Not yet set';
  Spock.loadData.onReadyMissCount = 0;
  Spock.loadData.printSummary = function () {
    if (Spock.loadData.loadingTime === 'Not yet set' || Spock.loadData.loadingTime === 'Print when ready') {
      Spock.loadData.loadingTime = 'Print when ready';
    } else {
      console.log('');
      console.log('SpockJS loading summary');
      console.log('Load time: ' + Spock.loadData.loadingTime + 'ms');
      console.log('onReady() miss count: ' + Spock.loadData.onReadyMissCount);
      console.log('');
    }
  }
  Spock.loadScript = function(url) {
    var scrpt = document.createElement('script');
    scrpt.src = url;
    document.head.appendChild(scrpt);
  }
  Spock.pathname = '' //document.URL + '';
  
  var module = {};
  module.exports = {};
  
  for (var d in dependencies) {
    var path = dependencies[d];
    if (path[path.length-1] === '/') {
      Spock.loadScript(Spock.pathname + '../Spock/' + dependencies[d] + 'index.js', null);
    } else {
      Spock.loadScript(Spock.pathname + '../Spock/' + dependencies[d] + '.js', null);
    }
  }
  
  function waitUntilLoaded() {
    for (var m in dependencies) {
      if (typeof Spock[m] === 'undefined') {
        setTimeout(waitUntilLoaded, Spock.loadData.retryInterval);
        return;
      }
    }
    
    // Ensures that each sub name space has the same instance of the main name space
    for (var m in dependencies) {
      Spock[m].init(Spock);
    }
  }
  
  Spock.onReady = function (callback) {
    
    if (Spock.loadData.spockLoaded) {
      if (Spock.loadData.documentLoaded) {
        callback();
      } else {
        $(document).ready(function() {
          Spock.loadData.documentLoaded = true;
          callback();
        });
      }
      return;
    }
    
    var ready = true;
    for (var m in dependencies) {
      if (typeof Spock[m] !== 'undefined') {
        if (Spock[m].initialised !== true) {
          ready = false;
          if (Spock.loadData.onReadyMissCount > Spock.loadData.retryLimit) {
            console.log('Failed to initialise module: ' + m);
            return;
          }
          break;
        }
      } else {
        ready = false;
        if (Spock.loadData.onReadyMissCount > Spock.loadData.retryLimit) {
          console.log('Failed to load module: ' + m);
          return;
        }
        break;
      }
    }
    if (ready) {
      Spock.loadData.spockLoaded = true;
      
      $(document).ready(function() {
        Spock.loadData.documentLoaded = true;
        callback();
      });
    } else {
      Spock.loadData.onReadyMissCount++;
      setTimeout(function() {
        Spock.onReady(callback);
      }, Spock.loadData.retryInterval);
    }
  }
  
  setTimeout(waitUntilLoaded, Spock.loadData.retryInterval);
  // Set loaded time
  setTimeout(function() {
    Spock.onReady(function() {
      if (Spock.loadData.loadingTime === 'Print when ready') {
        Spock.loadData.loadingTime = new Date() - Spock.loadData.startTime;
        Spock.loadData.printSummary();
      } else {
        Spock.loadData.loadingTime = new Date() - Spock.loadData.startTime;
      }
    });
  }, Spock.loadData.retryInterval);
  
} else { // NodeJs
  module.exports.runtime = 'nodejs';
  
  module.exports.pathname = __dirname;
  
  for (var d in dependencies) {
    module.exports[d] = require(dependencies[d]);
  }
  
  // Ensures that each sub name space has the same instance of the main name space
  for (var o in module.exports) {
    if (module.exports.hasOwnProperty(o) && o !== 'pathname' && o !== 'runtime') {
      module.exports[o].init(module.exports);
    }
  }
  
}
