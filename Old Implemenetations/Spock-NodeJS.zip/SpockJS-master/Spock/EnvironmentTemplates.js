var EnvironmentTemplates = {};

EnvironmentTemplates.init = function (gns) {
  Spock = gns;
  EnvironmentTemplates.initialised = true;
};

EnvironmentTemplates.HTMLManualTest = {
  AttachManaulInputFunctionToObject : function (jquery_object, env_instance, out_interface_id) {
    var send_message = function (event) {
      Spock.Common.sendMessageViaInterface(env_instance, event.data.msg, out_interface_id, event.data.channel);
    };
    var channel = 1;
    var localInterface = env_instance.getInterfaceByID(out_interface_id)
    var foreignInterface = localInterface.foreignInterfacingContext.getInterfaceByID(localInterface.connectedToInterfaceID)
    var nodes = foreignInterface.channelToNodeIDMap;
    
    jquery_object.each(function() {
      $(this).click({msg: $(this).text(), channel: nodes[(channel - 1) % 5 + 1]}, send_message); // TODO fix error there are too many buttons for interface
      $(this).text("input " + ((channel - 1) % 5 + 1));
      channel++;
    });
  }
};

// Load via json objects saved to file
// Consider using this for node templating as well
EnvironmentTemplates.loadTemplateIntoExistingEnvironment = function (name, environment) {
  
  // Get json object
  var loadedEnvironment = EnvironmentTemplates.HTMLManualTest;
  
  for (var e in loadedEnvironment) {
    environment[e] = loadedEnvironment[e];
  }
  
  return environment;
};

EnvironmentTemplates.loadTemplateIntoNewEnvironment = function (name, port) {
  
  var environment = Spock.Environment.newEnvironment(port, name);
  
  return EnvironmentTemplates.loadTemplateIntoExistingEnvironment(name, environment);
};


if (typeof Spock === 'undefined') { // NodeJS
  var Spock = {};
  module.exports = EnvironmentTemplates;
} else { // Javascript
  Spock.EnvironmentTemplates = EnvironmentTemplates;
}
