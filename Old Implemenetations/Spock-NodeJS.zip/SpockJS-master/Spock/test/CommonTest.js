var LC = require("../"),
    Test = require("./Test");

Test.cxt = null;
Test.cxt2 = null;
Test.customcallback = null;
Test.customcallback2 = null;

Test.callback = function (msg, channel) {
  Test.customcallback(msg, channel);
};
Test.callback2 = function (msg, channel) {
  Test.customcallback2(msg, channel);
};

Test.BeforeTestSuite = function () {

  Test.cxt = {};
  Test.cxt2 = {};
  
  LC.Common.addInterfacingCapability(Test.cxt, 3456);
  LC.Common.addInterfacingCapability(Test.cxt2, 3457);
  
};

Test.AfterTestSuite = function () {

  Test.cxt = null;
  Test.cxt2 = null;
  
};

Test.Add("Opened context correctly", function () {
  
  Test.AssertDefined("Context initialised correctly", Test.cxt);
  Test.Assert("Context has correct port", Test.cxt.interfacingPort === 3456);
  
  Test.AssertDefined("Context2 initialised correctly", Test.cxt2);
  Test.Assert("Context2 has correct port", Test.cxt2.interfacingPort === 3457);
  
});

Test.Add("Create interfaces", function () {
  Test.int1id = Test.cxt.createInterface(2, true, Test.callback);
  Test.int2id = Test.cxt2.createInterface(3, false, Test.callback2);
  Test.int3id = Test.cxt2.createInterface(2, false, Test.callback2);
  
  Test.int1 = Test.cxt.getInterfaceByID(Test.int1id);
  Test.int2 = Test.cxt2.getInterfaceByID(Test.int2id);
  Test.int3 = Test.cxt2.getInterfaceByID(Test.int3id);
  
  Test.Assert("Interface 1 has valid id", Test.int1id >= 0);
  Test.Assert("Interface 2 has valid id", Test.int2id >= 0);
  Test.Assert("Interface 3 has valid id", Test.int3id >= 0);
  
  Test.Assert("IDs within context 2 are unique (" + Test.int2id + ", " + Test.int3id + ")", Test.int3id !== Test.int2id);
  
  Test.Assert("Interface 1 has correct type", Test.int1.isinput === true);
  Test.Assert("Interface 2 has correct type", Test.int2.isinput === false);
  Test.Assert("Interface 3 has correct type", Test.int3.isinput === false);
  
  Test.Assert("Interface 1 has channel quantity", Test.int1.channelquantity === 2);
  Test.Assert("Interface 2 has channel quantity", Test.int2.channelquantity === 3);
  Test.Assert("Interface 3 has channel quantity", Test.int3.channelquantity === 2);
  
});

Test.Add("Connect interfaces programmatically", function () {
  
  var result1 = Test.cxt.connectToInterfacingContext("programmatic", Test.int1id, Test.cxt2, Test.int2id);
  var result2 = Test.cxt.connectToInterfacingContext("programmatic", Test.int1id, Test.cxt2, Test.int3id);
  
  Test.Assert("Connection result between interface 1 and interface 2 was a failure", result1 === "failure");
  Test.Assert("Connection result between interface 1 and interface 3 was a success", result2 === "success");
  
  //Test.Assert("Manually checking interface 1 is connected to interface 3", Test.);
  Test.Assert("Interface 1 connection type is programmatic", Test.int1.connectionType === "programmatic");
  Test.AssertNull("Interface 2 connection type is null", Test.int2.connectionType);
  Test.Assert("Interface 3 connection type is programmatic", Test.int3.connectionType === "programmatic");

  Test.AssertNotNullOrUndefined("Interface 1 has not null foreign context", Test.int1.foreignInterfacingContext);
  Test.AssertNull("Interface 2 has null foreign context", Test.int2.foreignInterfacingContext);
  Test.AssertNotNullOrUndefined("Interface 3 has not null foreign context", Test.int3.foreignInterfacingContext);
  
});

Test.Add("Send message through interface connections", function () {
  
  Test.customcallback = function (msg, channel) {
    Test.AsyncAssert(1, "Recieved message \"" + msg + "\" through channel " + channel + " in environment 1", msg === "test msg");  
  };

  Test.customcallback2 = function (msg, channel) {
    Test.AsyncAssert(2, "Recieved message \"" + msg + "\" through channel " + channel + " in environment 2", msg === "test msg");  
  };

  var result1 = Test.cxt.sendMessageViaInterface("test msg", Test.int1id, 1);
  var result2 = Test.cxt2.sendMessageViaInterface("test msg", Test.int3id, 2);
  
  Test.Assert("Sending message from interface 1 to interface 3 failed: " + result1, result1 !== "success");
  Test.Assert("Sending message from interface 3 to interface 1 succeeded: " + result2, result2 === "success");
  
});


Test.Add("Disconnect interface", function () {
  
  var result = Test.cxt.disconnectInterace(Test.int1id);
  
  Test.Assert("Disconnection function returned success", result === "success");
  Test.Assert("Interface 1 has been disconnected", Test.int1.connectionType === null && Test.int1.connectedToInterfaceID === '' && Test.int1.connectedToURL === '' && Test.int1.foreignInterfacingContext === null);
  Test.Assert("Interface 3 has been disconnected", Test.int3.connectionType === null && Test.int3.connectedToInterfaceID === '' && Test.int3.connectedToURL === '' && Test.int3.foreignInterfacingContext === null);
  
});

Test.run();



