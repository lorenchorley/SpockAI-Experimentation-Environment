var LC = require("../"),
    Test = require("./Test");

Test.BeforeTestSuite = function () {
  Test.net = LC.NN.newNeuralNetwork(1234);
};

Test.AfterTestSuite = function () {
  Test.net = null;
};

Test.Add("Set up network correctly", function () {
  
  Test.AssertNotNullOrUndefined("Network not null or undefined", Test.net);
  Test.Assert("Network has correct class", Test.net.contextClass === "network");
  
});

Test.Add("Add nodes", function () {
  
  var range = Test.net.addNodes(3);
  Test.n = Test.net.getNodeByID(range.start);
  
  Test.Assert("Start of range is the first node id (" + range.start + ")", range.start === '1');
  Test.Assert("End of range is the third node id (" + range.end + ")", range.end === '3');
  
});

Test.Add("Add additional functions to FC", function () {
  // Try to replace the getStatus, setStatus and checkCondition functions
  
  t1 = {
    FC : {
      getStatus : function () {
        Test.AsyncAssert(1.1, "Assigned new function to FC.getStatus function", false);
      },
      setStatus : function () {
        Test.AsyncAssert(1.2, "Assigned new function to FC.setStatus function", false);
      },
      checkCondition : function () {
        Test.AsyncAssert(1.3, "Assigned new function to FC.checkCondition function", false);
      }
    }
  };
  
  // Replace condition function
  
  t2 = {
    FC : {
      condition : function () {
        Test.AsyncAssert(1.4, "Assigned new function to FC.condition function", true);
      }
    }
  };
  
  // Add new function
  
  t_new = {
    FC : {
      NewFunction : function () {
        Test.AsyncAssert(1.5, "Ran function FC.NewFunction", true);
      }
    }
  };
  
  // Add functions via templates
  NN.addTemplateFunctionsToNode(t1, Test.n);
  NN.addTemplateFunctionsToNode(t2, Test.n);
  NN.addTemplateFunctionsToNode(t_new, Test.n);
  
  // Test functions
  Test.n.FC.NewFunction();
  Test.n.FC.getStatus();
  Test.n.FC.setStatus(false);
  Test.n.FC.checkCondition();
  
});

Test.Add("Add additional functions to TS", function () {
  // Add functions to select
  
  t1 = {
    TS : {
      select : function () {
        Test.AsyncAssert(2.1, "select addition functionality 1", true);
      }
    }
  };
  
  t2 = {
    TS : {
      select : function () {
        Test.AsyncAssert(2.2, "select addition functionality 2", true);
      }
    }
  };
  
  // Replace weightingFunction function
  
  t_weightingFunction = {
    TS : {
      weightingFunction : function () {
        Test.AsyncAssert(2.3, "weightingFunction", true);
      }
    }
  };
  
  // Add new function
  
  t_new = {
    TS : {
      NewFunction : function () {
        Test.AsyncAssert(2.4, "Ran function TS.NewFunction", true);
      }
    }
  };
  
  // Add functions via templates
  NN.addTemplateFunctionsToNode(t1, Test.n);
  NN.addTemplateFunctionsToNode(t2, Test.n);
  NN.addTemplateFunctionsToNode(t_weightingFunction, Test.n);
  NN.addTemplateFunctionsToNode(t_new, Test.n);
  
  // Test new function
  Test.n.TS.NewFunction();
  
});

Test.Add("Add additional functions to DP", function () {
  // Add functions to process
  // Add new function
  
  t_new = {
    DP : {
      NewFunction : function () {
        Test.AsyncAssert(3.1, "Ran function DP.NewFunction", true);
      }
    }
  };
  
  // Add functions via templates
  NN.addTemplateFunctionsToNode(t_new, Test.n);
  
  // Test new function
  Test.n.DP.NewFunction();
  
});

Test.Add("Test templating in TC", function () {
  // Add functions to select
  // Add new function
  
  t_new = {
    TC : {
      NewFunction : function () {
        Test.AsyncAssert(4.1, "Ran function TC.NewFunction", true);
      }
    }
  };
  
  // Add functions via templates
  NN.addTemplateFunctionsToNode(t_new, Test.n);
  
  // Test new function
  Test.n.TC.NewFunction();
  
});

Test.Add("Add additional functions to EE", function () {
  // Add functions to recieved signal
  // Add functions to processed signal
  // Add functions to sent signal
  // Add new function
  
  t_new = {
    EE : {
      NewFunction : function () {
        Test.AsyncAssert(5.1, "Ran function EE.NewFunction", true);
      }
    }
  };
  
  // Add functions via templates
  NN.addTemplateFunctionsToNode(t_new, Test.n);
  
  // Test new function
  Test.n.EE.NewFunction();
  
});

Test.Add("Add additional functions to LC", function () {
  // Add new function
  
  t_new = {
    LC : {
      NewFunction : function () {
        Test.AsyncAssert(6.1, "Ran function LC.NewFunction", true);
      }
    }
  };
  
  // Add functions via templates
  NN.addTemplateFunctionsToNode(t_new, Test.n);
  
  // Test new function
  Test.n.LC.NewFunction();
  
});

Test.Add("Add additional functions to IN", function () {
  // Replace the receiveSignal function
  // Try to replace the accept function
  // Add new function
  
  t_new = {
    IN : {
      NewFunction : function () {
        Test.AsyncAssert(7.1, "Ran function IN.NewFunction", true);
      }
    }
  };
  
  // Add functions via templates
  NN.addTemplateFunctionsToNode(t_new, Test.n);
  
  // Test new function
  Test.n.IN.NewFunction();
  
});

Test.Add("Add additional functions to OUT", function () {
  // Replace the scheduleLoop function
  // Try to replace the loop function
  // Add new function
  
  t_new = {
    OUT : {
      NewFunction : function () {
        Test.AsyncAssert(8.1, "Ran function OUT.NewFunction", true);
      }
    }
  };
  
  // Add functions via templates
  NN.addTemplateFunctionsToNode(t_new, Test.n);
  
  // Test new function
  Test.n.OUT.NewFunction();
  
});

Test.Add("Add additional functions to STORE", function () {
  // Replace addSignal function
  // Replace removeSignal function
  // Add new function
  
  t_new = {
    STORE : {
      NewFunction : function () {
        Test.AsyncAssert(9.1, "Ran function STORE.NewFunction", true);
      }
    }
  };
  
  // Add functions via templates
  NN.addTemplateFunctionsToNode(t_new, Test.n);
  
  // Test new function
  Test.n.STORE.NewFunction();
  
});

Test.Add("Add additional functions to PROP", function () {
  // Try to replace the get, set and remove functions
  // Add new function
  
  t_new = {
    PROP : {
      NewFunction : function () {
        Test.AsyncAssert(10.1, "Ran function PROP.NewFunction", true);
      }
    }
  };
  
  // Add functions via templates
  NN.addTemplateFunctionsToNode(t_new, Test.n);
  
  // Test new function
  Test.n.PROP.NewFunction();
  
});

Test.Add("Add additional functions via file template", function () {
  
  var template = require('./NN_templatetestfile');
  
  NN.addTemplateFunctionsToNode(template, Test.n);
  
});

Test.Add("Interface verification test", function () {

  Test.Assert("Function exist", Test.net.interfaceVerifier !== undefined && typeof(Test.net.interfaceVerifier) === 'function');
  //Try to create an interface that doesn't fit the verifier
  
});

Test.Add("Connect nodes", function () {

  Test.net = LC.NN.newNeuralNetwork(1234);
  
  Test.net.addNodes(3);
  
  Test.n1 = Test.net.getNodeByID('1');
  Test.n2 = Test.net.getNodeByID('2');
  Test.n3 = Test.net.getNodeByID('3');
  
  Test.n1.STORE.addConnection(Test.n2.getid());
  Test.n2.STORE.addConnection(Test.n3.getid());
  
  Test.Assert("Node 1 is connected to Node 2", Test.n1.STORE.hasConnection(Test.n2.getid()));
  Test.Assert("Node 2 is connected to Node 3", Test.n2.STORE.hasConnection(Test.n3.getid()));
  
});

Test.Add("Test fire nodes", function () {
  
  Test.n1.FC.setStatus(true);
  Test.n2.FC.setStatus(true);
  
  Test.n3.IN.receiveSignal = function() {
    Test.AsyncAssert(11.1, "Recieved signal in node 3", true);
  };
  
  Test.n1.accept("test packet");
  
});

Test.run();
