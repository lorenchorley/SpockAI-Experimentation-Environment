var LC = require("../");
var Test = require("./Test");

Test.BeforeTestSuite = function () {
  
};

Test.AfterTestSuite = function () {
  
};

Test.Add("testname", function () {
  Test.Assert("Assert statement 1", false);
});

Test.run();
