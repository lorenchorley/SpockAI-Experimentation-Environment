//var LC = require("../");
var Test = require("./Test");

Test.Before = function () {
  console.log("Before tests");
};

Test.After = function () {
  console.log("After tests");
};

Test.Add("Test 1", function () {
  return 1;
});

Test.Add("Test 2", function () {
  return 0;
});

Test.Add("Test 3", function () {
  
  Test.Assert("Assert statement returning false", false);
  Test.Assert("Assert statement returning true", true);
  
});

Test.Add("Test 4", function () {
  
  Test.Assert("Assert statement 1", false);
  Test.Assert("Assert statement 2", false);
  Test.Assert("Assert statement 3", false);
  
});

Test.run();
