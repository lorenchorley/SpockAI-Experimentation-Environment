var LC = require("../"),
    Test = require("./Test");

LC.Tools.enableProgressLogging = false;
LC.Tools.enableFunctionLogging = false;

Test.BeforeTestSuite = function () {
  
  // Create the environments with interfacing capability
  Test.controlsEnv = LC.Env.newEnvironment(1234, "controlsEnv");
  Test.binaryGateEnv = LC.Env.newEnvironment(1235, "binaryGateEnv");
  
  // Controls logic
  Test.controlsEnv.setLeft = function (bit) {
    //LC.Tools.logFunction("controlsEnv.setLeft", bit);
    
    Test.controlsEnv.sendMessageViaInterface(bit, Test.controlsEnv.controlsOutputInterfaceID, 1);
  };
  
  Test.controlsEnv.setRight = function (bit) {
    //LC.Tools.logFunction("controlsEnv.setRight", bit);
    
    Test.controlsEnv.sendMessageViaInterface(bit, Test.controlsEnv.controlsOutputInterfaceID, 2);
  };
  
  Test.controlsEnv.execute = function () {
    //LC.Tools.logFunction("controlsEnv.execute");
    
    Test.controlsEnv.sendMessageViaInterface(null, Test.controlsEnv.controlsOutputInterfaceID, 3);
  };
  
  Test.controlsEnv.getResult = function (bit) {
    //LC.Tools.logFunction("controlsEnv.getResult", bit);
    
    Test.AsyncAssert(1, "recieved " + bit, bit === Test.controlsEnv.nextCorrectResult());
  };
  
  // Binary gate logic
  Test.binaryGateEnv.left = null;
  Test.binaryGateEnv.right = null;
  
  Test.binaryGateEnv.go = function () {
    LC.Tools.logFunction("binaryGateEnv.go");
  
    if ((Test.binaryGateEnv.left === 0 || Test.binaryGateEnv.left === 1) && (Test.binaryGateEnv.right === 0 || Test.binaryGateEnv.right === 1)) {
      if (Test.binaryGateEnv.left + Test.binaryGateEnv.right === 2) {
        var result = Test.binaryGateEnv.sendMessageViaInterface(1, Test.binaryGateEnv.binaryGateOutputInterfaceID, 1);
      } else {
        var result = Test.binaryGateEnv.sendMessageViaInterface(0, Test.binaryGateEnv.binaryGateOutputInterfaceID, 1);
      }
    } else {
      var result = Test.binaryGateEnv.sendMessageViaInterface(null, Test.binaryGateEnv.binaryGateOutputInterfaceID, 1);
    }
    
    LC.Tools.logProgress("sending from go result " + result);
  };
  
  // Set the interface functionality
  Test.controlscallback = function (msg, channel) {
    LC.Tools.logFunction("controlscallback", msg, channel);
    
    if (channel === 1) {
      Test.controlsEnv.getResult(msg);
    } else {
      Test.AsyncAssert(3, "Wrong channel " + channel, false);
    }
  };
  
  Test.gatecallback = function (msg, channel) {
    LC.Tools.logFunction("gatecallback", msg, channel);
    
    if (channel === 1) { // left
      Test.binaryGateEnv.left = msg;
    } else if (channel === 2) { // right
      Test.binaryGateEnv.right = msg;
    } else if (channel === 3) { // go
      Test.binaryGateEnv.go();
    } else {
      Test.AsyncAssert(4, "Wrong channel " + channel, false);
    }
  };
  
};

Test.AfterTestSuite = function () {
  Test.controlsEnv = null;
  Test.binaryGateEnv = null;
};

Test.Add("Set up environments correctly", function () {
  
  Test.AssertNotNullOrUndefined("Controls environment initialised correctly", Test.controlsEnv);
  Test.Assert("Controls environment has correct class", Test.controlsEnv.contextClass === "environment");
  Test.Assert("Controls environment has correct type", Test.controlsEnv.type === "controlsEnv");
  
  Test.AssertNotNullOrUndefined("Binary gate initialised correctly", Test.binaryGateEnv);
  Test.Assert("Binary gate has correct class", Test.binaryGateEnv.contextClass === "environment");
  Test.Assert("Binary gate has correct type", Test.binaryGateEnv.type === "binaryGateEnv");
  
});

Test.Add("Connect environments", function () {
  
  // Create interfaces
  Test.controlsEnv.controlsInputInterfaceID = Test.controlsEnv.createInterface(1, true, Test.controlscallback);
  Test.controlsEnv.controlsOutputInterfaceID = Test.controlsEnv.createInterface(3, false);
  
  Test.binaryGateEnv.binaryGateOutputInterfaceID = Test.binaryGateEnv.createInterface(1, false);
  Test.binaryGateEnv.binaryGateInputInterfaceID = Test.binaryGateEnv.createInterface(3, true, Test.gatecallback);
  
  // Connect interfaces
  var result1 = Test.controlsEnv.connectToInterfacingContext("programmatic", Test.controlsEnv.controlsOutputInterfaceID, Test.binaryGateEnv, Test.binaryGateEnv.binaryGateInputInterfaceID);
  var result2 = Test.binaryGateEnv.connectToInterfacingContext("programmatic", Test.binaryGateEnv.binaryGateOutputInterfaceID, Test.controlsEnv, Test.controlsEnv.controlsInputInterfaceID);
  
  Test.Assert("Interface ids are not equal", Test.binaryGateEnv.binaryGateOutputInterfaceID !== Test.binaryGateEnv.binaryGateInputInterfaceID);
  
  var bgout = Test.binaryGateEnv.getInterfaceByID(Test.binaryGateEnv.binaryGateOutputInterfaceID);
  var bgin = Test.binaryGateEnv.getInterfaceByID(Test.binaryGateEnv.binaryGateInputInterfaceID);
  var cout = Test.controlsEnv.getInterfaceByID(Test.controlsEnv.controlsOutputInterfaceID);
  var cin = Test.controlsEnv.getInterfaceByID(Test.controlsEnv.controlsInputInterfaceID);
  
  Test.Assert("BG Output interface is set to be an output interface ", bgout.isinput === false);
  Test.Assert("BG Input interface is set to be an input interface ", bgin.isinput === true);
  Test.Assert("C Output interface is set to be an output interface ", cout.isinput === false);
  Test.Assert("C Input interface is set to be an input interface ", cin.isinput === true);
  
  Test.Assert("Connection result between controls and binary gate was a success", result1 === "success");
  Test.Assert("Connection result between binary gate and controls was a success", result2 === "success");
  
});

Test.Add("Send data and check results", function () {
  
  Test.controlsEnv.iteration = -1;
  
  Test.controlsEnv.nextCorrectResult = function () {
    Test.controlsEnv.iteration += 1;
    if (Test.controlsEnv.iteration >= 0 && Test.controlsEnv.iteration <= 2) {
      return 0;
    } else if (Test.controlsEnv.iteration === 3) {
      return 1;
    }
  };
  
  Test.controlsEnv.setLeft(0);
  Test.controlsEnv.setRight(0);
  Test.controlsEnv.execute();
  
  Test.controlsEnv.setLeft(1);
  Test.controlsEnv.setRight(0);
  Test.controlsEnv.execute();
  
  Test.controlsEnv.setLeft(0);
  Test.controlsEnv.setRight(1);
  Test.controlsEnv.execute();
  
  Test.controlsEnv.setLeft(1);
  Test.controlsEnv.setRight(1);
  Test.controlsEnv.execute();
  
});
  
Test.run();



