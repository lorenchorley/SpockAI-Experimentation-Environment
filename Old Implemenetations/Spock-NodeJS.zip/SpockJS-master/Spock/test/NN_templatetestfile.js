template = {
  FC : {
    condition : function () {
      return true;
    }
  },
};

module.exports = template;
