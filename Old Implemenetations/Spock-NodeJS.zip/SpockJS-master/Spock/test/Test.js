var Test = {};

tests = {};
assertfailures = [];

Test.Assert = function (message, test) {
  if (!test) {
    assertfailures[assertfailures.length] = message;
  }
};
Test.AssertDefined = function (message, obj) {
  Test.Assert(message, obj !== undefined);
};
Test.AssertUndefined = function (message, obj) {
  Test.Assert(message, obj === undefined);
};
Test.AssertNull = function (message, obj) {
  Test.Assert(message, obj === null);
};
Test.AssertNotNull = function (message, obj) {
  Test.Assert(message, obj !== null);
};
Test.AssertNotNullOrUndefined = function (message, obj) {
  Test.Assert(message, obj !== null && obj !== undefined);
};
Test.AsyncAssert = function (msgid, message, test) {
  if (!test) {
    console.log("(" + msgid + ") Asynchronous assert failed: " + message);
  } else {
    console.log("(" + msgid + ") Recieved valid asynchronous message: " + message);
  }
};

Test.BeforeTest = function () {};
Test.AfterTest = function () {};
Test.BeforeTestSuite = function () {};
Test.AfterTestSuite = function () {};

Test.Add = function (testname, testfunction) {
  if (typeof(testfunction) === "function") {
    tests[testname] = testfunction;
  } else {
    console.log("Failed to add test " + testname + ". Unexpected value.");
  }
};
Test.run = function () {
  var succeeded = 0;
  var failed = 0;
  
  function RunCheckedFunction(f) {
    if (typeof(f) === 'function') {
      f();
    }
  };
  
  RunCheckedFunction(Test.BeforeTestSuite);
  
  for (var t in tests) {
    RunCheckedFunction(Test.BeforeTest);
  
    var result = tests[t]();
    if ((result === undefined || result === 0) && assertfailures.length === 0) {
      succeeded++;
    } else {
      failed++;
      console.log("Test \"" + t + "\" failed:");
      if (result !== undefined && result !== 0) {
        console.log("  Test returned \"" + result + "\"");
      }
      if (assertfailures.length !== 0) {
        for (var i = 0; i < assertfailures.length; i++) {
          console.log("  Assertion \"" + assertfailures[i] + "\" failed.");
        }
        assertfailures = [];
      }
      console.log("");
    }
    
    RunCheckedFunction(Test.AfterTest);
  }
  
  RunCheckedFunction(Test.AfterTestSuite);
  
  if (failed > 0) {
    console.log('' + failed + " test(s) failed. " + succeeded + " test(s) succeeded.");
  } else {
    console.log("All " + succeeded + " test(s) succeeded.");
  }
  
};

module.exports = Test;
