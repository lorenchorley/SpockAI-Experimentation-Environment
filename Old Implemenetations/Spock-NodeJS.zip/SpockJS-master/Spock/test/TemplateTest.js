var LC = require("../");
var Test = require("./Test");

Test.BeforeTestSuite = function () {
  
};

Test.AfterTestSuite = function () {
  
};

Test.Add("Templates module loaded correctly into LC namespace", function () {
  Test.AssertDefined("Templates namespace is defined", LC.Templates);
  Test.AssertDefined("Templates combine function is defined", LC.Templates.combine);
  Test.AssertDefined("Templates 'Basic' template is defined", LC.Templates.Basic);
});

Test.Add("Templates combine function works as expected", function () {
  var t1 = {
    FC : {
      test1 : 'test string1'
    }
  };
  
  var t2 = {
    FC : {
      test2 : 'test string2'
    }
  };
  
  var tests = LC.Templates.combine(t1, t2);
  
  Test.AssertDefined("Combined test template is defined", tests);
  Test.AssertDefined("Combined test template is defined with FC component", tests.FC);
  Test.Assert("Combined test template has both functions", tests.FC.test1 === 'test string1' && tests.FC.test2 === 'test string2');
  
});

Test.Add("Templates basic template is correct", function () {
  Test.AssertDefined("Templates 'Basic' template has DP_Prefix (DP.PrefixSignal) loaded", LC.Templates.Basic.DP.PrefixSignal);
});

Test.Add("Templates basic template is correct when loaded again via loadFromArray", function () {
  
  LC.Templates.loadFromArray('Basic2', ['DP_Prefix']);

  Test.AssertDefined("'Basic' reloaded has DP_Prefix (DP.PrefixSignal) loaded", LC.Templates.Basic2.DP.PrefixSignal);
  
});


Test.run();
