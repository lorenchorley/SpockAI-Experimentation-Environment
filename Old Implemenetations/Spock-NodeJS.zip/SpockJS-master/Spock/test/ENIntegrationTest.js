var LC = require("../"),
    Test = require("./Test");

Test.BeforeTestSuite = function () {
  
  // Set up network
  // Set up test environment
  
};

Test.AfterTestSuite = function () {
  
  // set to null
  
};

Test.Add("Set up interfaces and connect them", function () {
  
};

Test.Add("Start them and observe", function () {
  
};

Test.run();



