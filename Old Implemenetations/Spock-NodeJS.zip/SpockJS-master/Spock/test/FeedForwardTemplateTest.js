var LC = require("../");
var Test = require("./Test");

Test.BeforeTestSuite = function () {
  var fftemplate = LC.Templates.FeedForward;
  
  Test.net = LC.NN.newNeuralNetwork(9999);
  Test.ranges = Test.net.addNodesByPattern("FeedForward", fftemplate, {
    layerSize : 3,
    layerQuantity : 4
  });
  
  Test.net2 = LC.NN.newNeuralNetwork(9999);
  Test.ranges2 = Test.net.addNodesByPattern("FeedForward", fftemplate, {
    arrayLayers : [2,3,4]
  });
  
};

Test.AfterTestSuite = function () {
  
};

Test.Add("Set up by size and layers correctly", function () {

  Test.AssertNotNullOrUndefined("Ranges is set", Test.ranges);
  Test.AssertNotNullOrUndefined("Start is set", Test.ranges.start);
  Test.AssertNotNullOrUndefined("End is set", Test.ranges.end);
  
  Test.Assert("Start is set correctly", Test.ranges.start.start === "1" && Test.ranges.start.end === "3");
  Test.Assert("End is set correctly", Test.ranges.end.start === "10" && Test.ranges.end.end === "12");
  
  for (var i = 1; i <= 3; i++) {
    var nodei = Test.net.getNodeByID(i);
    for (var j = 4; j <= 6; j++) {
      Test.AssertDefined("Node " + i + " is connected to node " + j, nodei.STORE.getConnection(j));
    }
  }
  
  for (var i = 4; i <= 6; i++) {
    var nodei = Test.net.getNodeByID(i);
    for (var j = 7; j <= 9; j++) {
      Test.AssertDefined("Node " + i + " is connected to node " + j, nodei.STORE.getConnection(j));
    }
  }
  
  for (var i = 7; i <= 9; i++) {
    var nodei = Test.net.getNodeByID(i);
    for (var j = 10; j <= 12; j++) {
      Test.AssertDefined("Node " + i + " is connected to node " + j, nodei.STORE.getConnection(j));
    }
  }
  
});

Test.Add("Set up by array correctly", function () {
  
  
  
});

Test.run();
