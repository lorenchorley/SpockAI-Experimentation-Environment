var Network = {};

Network.init = function (gns) {
  Spock = gns;
  Network.initialised = true;
};

Network.nodes = {};
Network.connections = {};
Network.signals = {};
Network.networks = {};

/*
 * Name space definitions:
 * 
 * locked: Function cannot be modified
 * event hook: Adds new function to a function queue that is run everytime the event is played
 * subsidary: A function that is sort of replacable via a secondary function that starts with a _
 * replacable: A function that represents specific functionality but is immediately replacable
 * 
 */
Network.nodes.nameSpace = {
  FC : { /* Firing Condition */
    getStatus : 'locked',
    setStatus : 'locked',
    condition : 'replacable'
  },
  TS : { /* Target Selection */
    select : 'subsidary',
    onSelect : 'event hook'
  },
  DP : { /* Data Processing */
    process : 'locked',
    onProcess : 'event hook'
  },
  TC : { /* Transmission Content */
    select : 'subsidary',
    onSelect : 'event hook'
  },
  LC : { /* Life Cycle */
    onBirth : 'event hook',
    onDeath : 'event hook',
    onReplicate : 'event hook',
    onClone : 'event hook',
    onSpawn : 'event hook'
  },
  EM : { /* Energy Management */
    onSignalRecieved : 'event hook',
    onSignalProcessed : 'event hook',
    onSignalSent : 'event hook'
  },
  MM : { /* Metric Management */
    
  },
  IN : { /* Input Process */
    accept : 'locked',
    storeSignal : 'replacable'
  },
  OUT : { /* Output Process */
    loop : 'locked',
    scheduleLoop : 'replacable'
  },
  STORE : { /* Store Process */
    addSignal : 'subsidary',
    removeSignal : 'locked',
    chooseSignal : 'replacable',
    addConnection : 'subsidary',
    removeConnection : 'subsidary',
    getConnection : 'locked',
    getConnections : 'locked',
    onAddSignal : 'event hook',
    onRemoveSignal : 'event hook',
    onAddConnection : 'event hook',
    onRemoveConnection : 'event hook'
  },
  PROP : { /* Property Process */
    get : 'locked',
    set : 'locked',
    remove : 'locked',
    onGetProperty : 'event hook',
    onSetProperty : 'event hook',
    onRemoveProperty : 'event hook'
  }
};
Network.connections.nameSpace = {

};
Network.signals.nameSpace = {

};


/* 
 * Node functions 
 */

/* Firing Condition */
Network.nodes.newFC = function (parent) {
  var that = {};
  that.parent = parent;
  that.isFiring = false;
  that.getStatus = function () {
    Spock.Tools.logFunction("FC.getStatus");
    var result = that.condition();
    if (result !== that.isFiring) {
      that.setStatus(result);
    }
    return result;
  };
  that.setStatus = function (status) {
    Spock.Tools.logFunction("FC.setStatus", status);
    if (typeof(status) === 'boolean') {
      that.isFiring = status;
    } else {
      Tools.logError('FC.setStatus: FC.condition returned a faulty result');
    }
  };
  that.condition = function () {
    Spock.Tools.logFunction("FC.condition");
    return true; 
  };
  return that;
};

/* Target Selection */
Network.nodes.newTS = function (parent) {
  var that = {};
  that.parent = parent;
  that.select = function () {
    Spock.Tools.logFunction("TS.select");
    
    var target = that._select(that.parent);
    
    if (target !== null) {
      Tools.runActions(that.parent, that, 'onSelect', target);
    }
    
    return target;
  };
  that._select = function (node) {
    var nodeid;
    for (var n in node.STORE.getConnections()) { nodeid = n; break; }
    return n;
  }
  return that;
};

/* Data Processing */
Network.nodes.newDP = function (parent) {
  var that = {};
  that.parent = parent;
  that.process = function (signal) {
    Spock.Tools.logFunction("DP.process", signal.toString());
    
    if (signal !== null) {
      Tools.runActions(that.parent, that, 'onProcess', signal);
    }
    
    that.parent.EM.onSignalProcessed(signal);
    return signal;
  };
  return that;
};

/* Transmission Content */
Network.nodes.newTC = function (parent) {
  var that = {};
  that.parent = parent;
  that.select = function () {
    Spock.Tools.logFunction("TC.select");
    
    var signal = that._select(that.parent);
    
    if (signal !== null) {
      Tools.runActions(that.parent, that, 'onSelect', signal);
    }
    
    return signal;
  };
  that._select = function () {
    return that.parent.STORE.removeSignal();
  }
  return that;
};

/* Energy Management */
Network.nodes.newEM = function (parent) {
  var that = {};
  that.parent = parent;
  that.energy = 0;
  that.onSignalRecieved = function (signal, sendingNodeID) {
    Spock.Tools.logFunction("EM.onSignalRecieved", signal.toString(), sendingNodeID);
    
    if (signal !== null) {
      Tools.runActions(that.parent, that, 'onSignalRecieved', {signal : signal, sendingNodeID : sendingNodeID});
    } else {
      Tools.logError('Received null signal!');
    }
  };
  that.onSignalProcessed = function (signal) {
    Spock.Tools.logFunction("EM.onSignalProcessed", signal.toString());
    
    Tools.runActions(that.parent, that, 'onSignalProcessed', signal);
    
  };
  that.onSignalSent = function (signal, target) {
    Spock.Tools.logFunction("EM.onSignalSent", signal.toString(), target);
    
    Tools.runActions(that.parent, that, 'onSignalSent', {signal : signal, target : target});
    
  };
  return that;
};

/* Life Cycle */
Network.nodes.newLC = function (parent) {
  var that = {};
  that.parent = parent;
  that.onBirth = function () {
    Spock.Tools.logFunction("LC.onBirth");
    
    Tools.runActions(that.parent, that, 'onBirth', {});
    
    that.parent.OUT.scheduleLoop();
    
  };
  that.onDeath = function () {
    Spock.Tools.logFunction("LC.onDeath");
    
    Tools.runActions(that.parent, that, 'onDeath', {});
  };
  that.onReplicate = function () {
    Spock.Tools.logFunction("LC.onReplicate");
    
    Tools.runActions(that.parent, that, 'onReplicate', {});
    
    that.parent.OUT.scheduleLoop();
    
  };
  that.onClone = function () {
    Spock.Tools.logFunction("LC.onClone");
    
    Tools.runActions(that.parent, that, 'onClone', {});
    
    that.parent.OUT.scheduleLoop();
    
  };
  that.onSpawn = function () {
    Spock.Tools.logFunction("LC.onSpawn");
    
    Tools.runActions(that.parent, that, 'onSpawn', {});
    
    that.parent.OUT.scheduleLoop();
    
  };
  return that;
};

/* Metric management */
Network.nodes.newMM = function (parent) {
  var that = {};
  that.parent = parent;
  return that;
};

/* In Process */
Network.nodes.newIN = function (parent) {
  var that = {};
  that.parent = parent;
  that.accept = function (signal, sendingNodeID) {
    Spock.Tools.logFunction("accept", signal.toString(), sendingNodeID);
    
    // Inform EM module that a signal has been received
    that.parent.EM.onSignalRecieved(signal, sendingNodeID);
    
    // Process signal
    var processedSignal = that.parent.DP.process(signal);
    
    // Inform EM module that the signal has been processes
    that.parent.EM.onSignalProcessed(processedSignal);
    
    // Store signal
    that.storeSignal(processedSignal, sendingNodeID);
    
  };
  that.storeSignal = function (processedSignal, sendingNodeID) {
    that.parent.STORE.addSignal(processedSignal);
  };
  return that;
};

/* Out Process */
Network.nodes.newOUT = function (parent) {
  var that = {};
  that.parent = parent;
  that.loopScheduled = false;
  that.loop = function () {
    Spock.Tools.logFunction("OUT.loop");
    
    that.loopScheduled = false;
    
    // Ask FC to check that the firing condition is true
    if (!that.parent.FC.getStatus()) {
      Spock.Tools.logProgress("OUT loop found FC not set, exiting loop");
      return;
    }
    
    // Ask TS to select a target
    var target = that.parent.TS.select();
    
    // Check that the target was selected
    if (target === null || target === undefined) {
      Spock.Tools.logProgress("OUT loop found target empty, exiting loop");
      return;
    }
    
    // Get target object
    target = that.parent.network.getComponentByID(target);
    
    // TODO Error checking in case the node doesn't exist (died, in another network, etc)
    
    // Ask TC to select a signal from the current node
    var signal = that.parent.TC.select();
    
    // Check that the signal was selected
    if (signal === null || signal === undefined) {
      Spock.Tools.logProgress("OUT loop found signal empty, exiting loop");
      return;
    }
    
    // Schedule sending the signal to the target
    Tools.scheduleFunction(function () {
      Spock.Tools.logProgress('Sending signal to target ' + target.getid());
      
      // Send signal via connection
      Network.connections.sendSignalViaConnection(signal, target.getid(), that.parent.network, that.parent.getid());
      
      // Inform EM module that the signal 
      that.parent.EM.onSignalSent(signal, target);
    });
    
    // Schedule this loop again if the firing condition is set
    if (that.parent.FC.getStatus()) {
      that.scheduleLoop();
    }
  };
  that.scheduleLoop = function () {
    if (that.loopScheduled !== true) {
      Tools.scheduleFunction(that.loop); // TODO Consider finding a better solution
      that.loopScheduled = true;
    }
  };
  return that;
};

/* Storage Process */
Network.nodes.newSTORE = function (parent) {
  var that = {};
  that.parent = parent;
  that.connections = {};
  that.addSignal = function (signal) {
    Spock.Tools.logFunction("STORE.addSignal", signal.toString());
    
    that._addSignal(that.parent, signal);
    
    if (signal !== null) {
      Tools.runActions(that.parent, that, 'onAddSignal', signal.toString());
    }
    
    that.parent.OUT.scheduleLoop();
    
  };
  that._addSignal = function (node, signal) {
    that.signal = signal;
  };
  that.removeSignal = function () {
    Spock.Tools.logFunction("STORE.removeSignal");
    Spock.Tools.logFunction("STORE.chooseSignal");
    
    var signal = that.chooseSignal(that.parent);
    
    if (signal !== null && signal !== undefined) {
      Tools.runActions(that.parent, that, 'onRemoveSignal', signal.toString());
    }
    
    return signal;
  };
  that.chooseSignal = function (node) {
    var s = that.signal;
    that.signal = undefined;
    return s;
  };
  that.addConnection = function (nodeID) {
    Spock.Tools.logFunction("STORE.addConnection", nodeID);
    
    that._addConnection(that.parent, nodeID);
    
    Tools.runActions(that.parent, that, 'onAddConnection', nodeID);
    
    that.parent.OUT.scheduleLoop();
    
  };
  that._addConnection = function (node, nodeID) {
    node.STORE.connections[nodeID] = {};
  };
  that.removeConnection = function (nodeID) {
    Spock.Tools.logFunction("STORE.removeConnection", nodeID);
    
    that._removeConnection(that.parent, nodeID);
    
    Tools.runActions(that.parent, that, 'onRemoveConnection', nodeID);
  };
  that._removeConnection = function (node, nodeID) {
    node.STORE.connections[nodeID] = undefined;
  };
  that.getConnection = function (nodeID) {
    Spock.Tools.logFunction("STORE.getConnection", nodeID);
    
    return that.connections[nodeID];
  };
  that.getConnections = function () {
    Spock.Tools.logFunction("STORE.getConnections");
    
    return that.connections;
  };
  return that;
};

/* Property Process */
Network.nodes.newPROP = function (parent) {
  var that = {};
  that.parent = parent;
  that.props = {};
  that.get = function (prop) {
    Spock.Tools.logFunction("PROP.get", prop);
    
    Tools.runActions(that.parent, that, 'onGetProperty', prop);
    return that.props[prop];
  };
  that.set = function (prop, value) {
    Spock.Tools.logFunction("PROP.set", prop, value);
    
    Tools.runActions(that.parent, that, 'onSetProperty', {prop : prop, value : value});
    that.props[prop] = value;
  };
  that.remove = function (prop) {
    Spock.Tools.logFunction("PROP.remove", prop);
    
    Tools.runActions(that.parent, that, 'onRemoveProperty', prop);
    that.props[prop] = undefined;
  };
  return that;
};

Network.nodes.newNode = function (template, network) {
  Spock.Tools.logFunction("Network.nodes.newNode", template, network);
  
  var n = {};
  
  // Set up each module of the node
  for (var m in Network.nodes.nameSpace) {
    n[m] = Network.nodes['new' + m](n);
  }
  
  // Set node ID
  n.PROP.set('id', network.getUID());
  
  // Set shortcut functions
  n.accept = n.IN.accept;
  n.componentClass = 'n';
  n.getid = function () {
    return n.PROP.get('id');
  }
  
  // Apply template
  Network.nodes.addTemplateFunctionsToNode(template, n);
  
  Tools.runActions(n, n.LC, 'onBirth', {}); 
  
  return n;
};

Network.nodes.addTemplateFunctionsToNode = function(template, node) {
  Spock.Tools.logFunction("Network.nodes.addTemplateFunctionsToNode", template, node);
  
  for (var m in template) { // Iterate through all modules present in the template
    var tempmod = template[m];
    var nodemod = node[m]; // Find the corresponding module in the node
    if (nodemod !== undefined) { // If it exists, TODO do something if it doesn't
      for (var f in tempmod) { // Iterate through all the functions present in the template under the module m
        var ns_restriction = Network.nodes.nameSpace[m][f];
        if (ns_restriction === 'event hook') { // if it's a hook for an event, add the function to the appropriate array
          
          var actionArray = nodemod[f + 'Actions'];
          if (actionArray === undefined) {
            actionArray = new Array();
            nodemod[f + 'Actions'] = actionArray;
          }
          actionArray[actionArray.length] = tempmod[f];
          
        } else if (ns_restriction === 'locked') { // If it's a locked function, declare and ignore it
          console.log(m + '.' + f + ' is a locked function and therefore will not be modified.');
          
        } else if (ns_restriction === 'subsidary') { // Replaces _function instead of function
          nodemod['_' + f] = tempmod[f];
          
        } else if (ns_restriction === 'replacable') { // Replaces the function without question
          
          nodemod[f] = tempmod[f];
          
        } else { // Otherwise just add it to the module replacing any function that was already there
          if (nodemod[f] !== undefined) {
            console.log('Replacing already existant function ' + f + ' in module ' + m);
          }
          nodemod[f] = tempmod[f];
        }
        
      }
      
    } else {
      if (Network.nodes.nameSpace[m] !== undefined) {
        console.log('Module "' + m + '" could not be found in node. Node may be malformed.');
        console.log(node);
      } else {
        console.log('Module "' + m + '" in template is not a standard module. Module was ignored.');
      }
    }
  }
};


/* 
 * Signal functions 
 */

//TODO
Network.signals.newSignal = function (type, args) {
  Spock.Tools.logFunction("Network.signals.newSignal", type, args);
  
  var that = {};
  if (type === 'string') {
    that.content = args.string;
    that.toString = function () {
      return that.content;
    };
  } else if (type === 'binary') {
    if (args.value === true || args.value === '1') {
      that.content = true;
    } else if (args.value === false || args.value === '0') {
      that.content = false;
    } else {
      Tools.logError('Network.signals.newSignal: Unknown binary value: ' + args.value);
    }
    that.toString = function () {
      if (that.content) {
        return '1';
      } else {
        return '0';
      }
    };
  } else {
    Tools.logError('Network.signals.newSignal: Unknown signal type');
  }
};
Network.signals.newStringSignal = function (string) {
  return Network.signals.newSignal('string', {string : string});
};
Network.signals.newBinarySignal = function (value) {
  return Network.signals.newSignal('binary', {value : value});
}

/* Connection functions */

//TODO
Network.connections.newConnection = function (network, id, functions) {
  Spock.Tools.logFunction("Network.connections.newConnection", network, id, functions);
  
  var c = {};
  c.id = id;
  c.network = network;
  c.functions = functions;
  c.nodes = {};
  c.interfaces = {};
  c.componentClass = 'c';
  c.getid = function () {
    return c.id;
  };
  
  return c;
}

Network.connections.sendSignalViaConnection = function (signal, connectionID, network, senderNodeID, force_default) {
  Spock.Tools.logFunction("Network.connections.sendSignalViaConnection", signal, connectionID, network, senderNodeID);
  
  if (force_default !== true && force_default !== false) {
    force_default = false;
  }
  
  var connection = network.getComponentByID(connectionID);
  
  // Use custom functions if linked
  if (!force_default && connection.functions !== undefined && connection.functions.sendSignalViaConnection !== undefined) {
    connection.functions.sendSignalViaConnection(signal, connectionID, network, senderNodeID);
  } else {
    var nodes = connection.nodes;
    for (var n in nodes) {
      if (nodes[n] !== true && n !== senderNodeID) {
        network.getComponentByID(n).accept(signal);
      }
    }
    var interfaces = connection.interfaces;
    for (var i in interfaces) {
      for (var ch in interfaces[i]) {
        if (interfaces[i][ch] !== true) {
          Spock.Common.sendMessageViaInterface(network, signal, i, ch);
        }
      }
    }
  }
}

Network.connections.connectNodeToConnection = function (network, connectionID, nodeID, isInput, force_default) {
  Spock.Tools.logFunction("Network.connections.connectNodeToConnection", network, connectionID, nodeID, isInput);
  
  if (force_default !== true && force_default !== false) {
    force_default = false;
  }
  
  var connection = network.getComponentByID(connectionID);
  
  // Use custom functions if linked
  if (!force_default && connection.functions !== undefined && connection.functions.connectNodeToConnection !== undefined) {
    connection.functions.connectNodeToConnection(connection, nodeID, isInput);
  } else {
    connection.nodes[nodeID] = isInput;
    var node = network.getComponentByID(nodeID);
    if (isInput && node.componentClass === "n") {
      node.STORE.addConnection(connectionID);
    }
  }
}

Network.connections.connectInterfaceToConnection = function (network, connectionID, intID, isInput, channel, force_default) {
  Spock.Tools.logFunction("Network.connections.connectInterfaceToConnection", network, connectionID, intID, isInput, channel);
  
  if (force_default !== true && force_default !== false) {
    force_default = false;
  }
  
  var connection = network.getComponentByID(connectionID);
  
  // Use custom functions if linked
  if (!force_default && connection.functions !== undefined && connection.functions.connectInterfaceToConnection !== undefined) {
    connection.functions.connectInterfaceToConnection(connection, intID);
  } else {
    if (connection.interfaces[intID] === undefined) {
      connection.interfaces[intID] = {};
    }
    connection.interfaces[intID][channel] = isInput;
  }
}

Network.connections.disconnectNodeFromConnection = function (connectionID, nodeID, force_default) {
  Spock.Tools.logFunction("Network.connections.disconnectNodeFromConnection", connectionID, intID);
  
  if (force_default !== true && force_default !== false) {
    force_default = false;
  }
  
  var connection = network.getComponentByID(connectionID);
  
  // Use custom functions if linked
  if (!force_default && connection.functions !== undefined && connection.functions.disconnectNodeFromConnection !== undefined) {
    connection.functions.disconnectNodeFromConnection(connection, intID);
  } else {
    
  }
}

Network.connections.disconnectInterfaceFromConnection = function (connectionID, intID, force_default) {
  Spock.Tools.logFunction("Network.connections.disconnectInterfaceFromConnection", connectionID, intID);
  
  if (force_default !== true && force_default !== false) {
    force_default = false;
  }
  
  var connection = network.getComponentByID(connectionID);
  
  // Use custom functions if linked
  if (!force_default && connection.functions !== undefined && connection.functions.disconnectInterfaceFromConnection !== undefined) {
    connection.functions.disconnectInterfaceFromConnection(connection, intID);
  } else {
    
  }
}


/* 
 * Network functions 
 */

Network.networks.newNeuralNetwork = function (port) {
  
  var net = {};
  net.components = {};
  net.contextClass = "network";
  net.lastUID = 0;
  net.getUID = function () {
    Spock.Tools.logFunction("NetworkInstance.getUID");
    
    net.lastUID++;
    return net.lastUID;
  }
  
  Spock.Common.addInterfacingCapability(net, port);
  net.interfaceVerifier = function () {
    Spock.Tools.logFunction("NetworkInstance.interfaceVerifier");
    // TODO
    return true;
  };
  
  net.addNode = function (template) {
    Spock.Tools.logFunction("NetworkInstance.addNode", template);
    
    var node = Network.nodes.newNode(template, net);
    net.components[node.getid()] = node;
    node.network = net;
    return node;
  };
  
  net.addNodes = function (quantity, template) {
    Spock.Tools.logFunction("NetworkInstance.addNodes", quantity, template);
    
    var range = {};
    var node = null;
    for (var i = 0; i < quantity; i++) {
      node = net.addNode(template);
      if (i === 0) {
        range.start = node.getid();
      }
    }
    range.end = node.getid();
    return range;
  };
  
  net.addNodesByPattern = function (pattern, template, options) {
    Spock.Tools.logFunction("NetworkInstance.addNodesByPattern", pattern, template, options);
    
    var p = Network.networks.patterns[pattern];
    if (p !== undefined) {
      // insert default options
      for (var o in p.optionDefaults) {
        if (options[o] === undefined) {
          options[o] = p.optionDefaults[o];
        }
      }
      return p.execute(template, options, net);
    } else {
      return "Failure: Unknown pattern";
    }
  };
  
  net.getComponents = function () {
    Spock.Tools.logFunction("NetworkInstance.getComponents");
    return net.components;
  };
  
  net.getComponentByID = function (id) {
    Spock.Tools.logFunction("NetworkInstance.getComponentByID", id);
    return net.components[id];
  };
  
  net.newConnection = function () {
    Spock.Tools.logFunction("NetworkInstance.newConnection");
    
    var id = net.getUID();
    var connection = Network.connections.newConnection(net, id, net.connectionFunctions);
    net.components[id] = connection;
    return connection;
  };
  
  // Replace this to customise the functions of connections
  net.connectionFunctions = undefined;
  
  return net;
};

// Preprogrammed patterns for creating configurations of nodes within a network
Network.networks.patterns = {
  FeedForward : {
    optionDefaults : {
      layerSize : null,
      layerQuantity : null,
      arrayLayers : null
    },
    execute : function (template, options, network) {
      // If layerSize and layerQuantity are numbers
      if (options.layerSize !== null && options.layerQuantity !== null && !isNaN(options.layerSize) && !isNaN(options.layerQuantity)) {
        var currentLayer = null;
        var previousLayer = null;
        var ranges = {};
        for (var n = 0; n < options.layerQuantity; n++) {
          previousLayer = currentLayer;
          currentLayer = network.addNodes(options.layerSize, template);
          if (n === 0) { // First layer
            ranges.start = currentLayer;
          } else { // When not the first layer
            // For every node in the previous layer, connect it to every node in the current layer
            for (var pn = Number(previousLayer.start); pn <= Number(previousLayer.end); pn++) {
              for (var cn = Number(currentLayer.start); cn <= Number(currentLayer.end); cn++) {
                var connectionID = network.connections.newConnection().getid();
                Network.connections.connectNodeToConnection(network, connectionID, pn, true);
                Network.connections.connectNodeToConnection(network, connectionID, cn, false);
              }
            }
          }
          if (n === options.layerQuantity - 1) { // Last layer
            ranges.end = currentLayer;
          }
        }
        return ranges;
      } else if (options.arrayLayers !== null && Object.prototype.toString.call(options.arrayLayers) === '[object Array]') { // Otherwise if arrayLayers is set to an array
        return "Failure: unsupported option";
      } else {
        return "Failure: Inconsistent options";
      }
    }
  },
  SingleNode : null, // TODO
  FullyConnectedWeb : null // TODO
};
Network.networks.patternExecutionWrapper = function () {

};

// Cannot save interface connections
Network.networks.saveNeuralNetwork = function (path, network) {
  //TODO load everything necessary into a json object, and store that
  var savable = {};
  savable.port = network.interfacingPort;
  //savable.nodes
  //savable.nodes.templateType
  //savable.templateTypes
  //savable.interfaces
};

Network.networks.loadNeuralNetwork = function (path, port) {
  
};

Network.networks.printSummary = function (network) {
  //TODO
  var numberOfNodes = 0;
  var numberOfConnections = 0;
  
  for (var n in network.getComponents()) {
    numberOfNodes++;
  }
  
  console.log('');
  console.log('Network summary');
  console.log('Port: ' + network.interfacingPort);
  console.log('Number of nodes: ' + numberOfNodes);
  console.log('Number of connections: ' + numberOfConnections);
  console.log('');
};

if (typeof Spock === 'undefined') { // NodeJS
  var Spock = {};
  module.exports = Network;
} else { // Javascript
  Spock.Network = Network;
}
