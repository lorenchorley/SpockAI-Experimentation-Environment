var Templates = {};



Templates.modules = {};
Templates.modules.index = ['DP_Prefix',
                           'TESTING_EventNotifications',
                           'PROP_Genetic',
                           'TS_WeightedSelection',
                           'TS_RandomSelection',
                           'OUT_SlowRescheduling',
                           'STORE_SignalQueue',
                           'FC_EM_ConservationOfEnergy',
                           'LC_OverloadDivision',
                           'TC_QueuedSelection'
                           ];


Templates.Testing = ['DP_Prefix',
                     'TESTING_EventNotifications'];
Templates.FeedForward = ['TC_QueuedSelection',
                         'OUT_SlowRescheduling'];



Templates.init = function (gns) {
  Spock = gns;
    
  // Load modules in module object
  for (var m in Templates.modules.index) {
    Templates.loadModule(Templates.modules.index[m], 'node');
  }
  
  var retries = 0;
  
  if (Spock.runtime !== 'nodejs') {
    function waitUntilModulesAreLoaded() {
      for (var m in Templates.modules.index) {
        if (Templates.modules[Templates.modules.index[m]] === undefined) {
          retries++;
          if (retries > Spock.loadData.retryLimit) {
            console.log('Templates loading function reached retry limit while loading ' + Templates.modules.index[m]);
            return;
          }
          setTimeout(waitUntilModulesAreLoaded, Spock.loadData.retryInterval);
          return;
        }
      }
      
      // Ensures that each module has been loaded before saying that Spock.Templates is initialised
      Templates.initialised = true;
    }
    
    setTimeout(waitUntilModulesAreLoaded, Spock.loadData.retryInterval);
  }
  
  
};

Templates.getModuleCopy = function (modulename) {
  if (typeof Templates.modules[modulename] !== 'undefined') {  
    return Tools.cloneObject(Templates.modules[modulename]);
  } else {
    console.log('Templates.getModuleCopy: could not find module, returning null.');
    return null;
  }
};

Templates.combine = function (t1, t2) {
  if (t1 === null || t2 === null || t1 === undefined || t2 === undefined) {
    console.log('Templates.combine: error, invalid input(s).');
    return;
  }
  var modules = ["FC","TS","DP","TC","EM","LC","IN","OUT","STORE","PROP"];
  var finaltemplate = {};
  for (var m in modules) {
    if (t1[modules[m]] !== undefined && t2[modules[m]] !== undefined) {
      finaltemplate[modules[m]] = t1[modules[m]];
      for (var f in t2[modules[m]]) {
        if (finaltemplate[modules[m]][f] === undefined) {
          finaltemplate[modules[m]][f] = t2[modules[m]][f];
        } else {
          console.log("failure: function namespace overlap");
          console.log("  " + modules[m].f);
          return "failure: function namespace overlap";
        }
      }
    } else if (t1[modules[m]] !== undefined) {
      finaltemplate[modules[m]] = t1[modules[m]];
    } else if (t2[modules[m]] !== undefined) {
      finaltemplate[modules[m]] = t2[modules[m]];
    }
  }
  return finaltemplate;
};

Templates.loadModule = function (modulename, type) {
  var temp = {};
  
  if (type !== "node" && type !== "environment" && type !== "connection" && type !== "signal") {
    Spock.Tools.logError('Templates.loadModule: Invalid module type ' + type);
    return;
  }
  
  if (Spock.runtime === 'nodejs') {
    temp = require(Spock.pathname + '/templates/' + type + '/' + modulename);
    Templates.modules[modulename] = temp;
  } else {
    Spock.loadScript(Spock.pathname + '../Spock/templates/' + type + '/' + modulename + '.js');
  }
};


if (typeof Spock === 'undefined') { // NodeJS
  var Spock = {};
  module.exports = Templates;
} else { // Javascript
  Spock.Templates = Templates;
}
