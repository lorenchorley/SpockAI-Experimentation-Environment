OUT_SlowRescheduling = {
  OUT : {
    scheduleLoop : function () {
      setTimeout(that.loop, 2000);
    }
  }
};

if (typeof Spock === 'undefined') { // NodeJS
  module.exports = OUT_SlowRescheduling;
} else {
  Spock.Templates.modules.OUT_SlowRescheduling = OUT_SlowRescheduling;
}
