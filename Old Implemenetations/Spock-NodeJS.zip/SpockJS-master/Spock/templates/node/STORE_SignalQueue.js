STORE_SignalQueue = {
  STORE : {
    queuehead : null,
    queuetail : null,
    addSignal : function (node, signal) {
      Spock.Tools.logFunction("STORE_SignalQueue.storeSignal");
      var tmp = node.STORE.queuetail;
      
      node.STORE.queuetail = {
        signal : signal,
        next : null
      }
      
      if (tmp !== null) {
        tmp.next = node.STORE.queuetail;
      } else {
        tmp = node.STORE.queuetail;
      }
      
      if (node.STORE.queuehead === null) {
        node.STORE.queuehead = tmp;
      }
      
    },
    chooseSignal : function (node) {
      Spock.Tools.logFunction("STORE_SignalQueue.chooseSignal");
      var s = node.STORE;
      if (s.queuehead !== null) {
        var signal = s.queuehead.signal;
        if (s.queuehead === s.queuetail) {
          s.queuehead = null;
          s.queuetail = null;
        } else {
          s.queuehead = s.queuehead.next;
        }
        return signal;
      } else {
        return null;
      }
    }
  }
};

if (typeof Spock === 'undefined') { // NodeJS
  module.exports = STORE_SignalQueue;
} else {
  Spock.Templates.modules.STORE_SignalQueue = STORE_SignalQueue;
}
