TS_FeedForwardSelectionAndFiring = {
  FC : {
    condition : function () {
      return
    }
  },
  TS : {
    onSelect : function () {
      
    },
    counter : function () {
      return 
    }
  }
};

if (typeof Spock === 'undefined') { // NodeJS
  module.exports = TS_FeedForwardSelectionAndFiring;
} else {
  Spock.Templates.modules.TS_FeedForwardSelectionAndFiring = TS_FeedForwardSelectionAndFiring;
}
