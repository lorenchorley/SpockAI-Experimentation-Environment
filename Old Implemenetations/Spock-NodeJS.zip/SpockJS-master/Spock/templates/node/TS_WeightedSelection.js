TS_WeightedSelection = {
  TS : {
    onSelect : function () {
      var target = null;
      var weightsum = 0;
      
      var connections = that.parent.STORE.getConnections(); 
      
      for (var i in connections) {
        if (connections[i].weight === undefined) {
          connections[i].weight = 1; // TODO set appropriately
        }
        weightsum += connections[i].weight;
      } 
      
      var r = Math.floor((Math.random()*weightsum)+1);
      
      for (var i in that.parent.STORE.getConnections()) {
        weightsum += that.parent.STORE.getConnections()[i].weight;
        if (weightsum >= r) {
          target = i;
          break;
        }
      }
      
      Spock.Tools.logProgress("Selecting " + target);
      
      return target;
    },
    
    weightingfunction : function (nodeID) {
      
    }
  }
};

if (typeof Spock === 'undefined') { // NodeJS
  module.exports = TS_WeightedSelection;
} else {
  Spock.Templates.modules.TS_WeightedSelection = TS_WeightedSelection;
}
