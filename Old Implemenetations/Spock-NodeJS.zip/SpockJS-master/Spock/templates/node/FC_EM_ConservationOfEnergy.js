FC_EM_ConservationOfEnergy = {
  FC : {
    condition : function () {
      return true;
    }
  },
  EM : {
    onSignalRecieved : function (signal) {
      
    },
    onSignalSent : function (signal) {
      
    }
  }
};

if (typeof Spock === 'undefined') { // NodeJS
  module.exports = FC_EM_ConservationOfEnergy;
} else {
  Spock.Templates.modules.FC_EM_ConservationOfEnergy = FC_EM_ConservationOfEnergy;
}
