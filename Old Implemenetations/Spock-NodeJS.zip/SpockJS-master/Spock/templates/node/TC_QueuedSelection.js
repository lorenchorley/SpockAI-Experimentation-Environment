TC_QueuedSelection = {
  TC : {
    select : function () {
      //Already done
    }
  }
};

if (typeof Spock === 'undefined') { // NodeJS
  module.exports = TC_QueuedSelection;
} else {
  Spock.Templates.modules.TC_QueuedSelection = TC_QueuedSelection;
}
