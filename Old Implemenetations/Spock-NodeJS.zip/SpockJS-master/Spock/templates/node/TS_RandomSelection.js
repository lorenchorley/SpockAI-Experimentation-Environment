TS_RandomSelection = {
  TS : {
    select : function (node) {
      var target = null;
      var count = 0;
      
      var connections = node.STORE.getConnections(); 
      
      for (var i in connections) {
        count++;
      }
      
      var r = Math.floor((Math.random()*count)+1);
      
      count = 0;
      for (var i in connections) {
        count++;
        if (r === count) {
          target = i
          break;
        }
      }
      
      Spock.Tools.logProgress("Selecting " + target);
      
      return target;
      
    }
  }
};

if (typeof Spock === 'undefined') { // NodeJS
  module.exports = TS_RandomSelection;
} else {
  Spock.Templates.modules.TS_RandomSelection = TS_RandomSelection;
}
