var Template_Modules = {};
Template_Modules.setGlobalNamespace = function (gns) {Spock = gns;}

Template_Modules.DP_Prefix = require('./DP_Prefix');



if (typeof Spock === 'undefined') { // NodeJS
  var Spock = {};
  module.exports = Template_Modules;
} else { // Javascript
  Spock.Template_Modules = Template_Modules;
}
