TESTING_EventNotifications = {
  TS : {
    onSelect : function (node, target) {
      console.log('EventNotifications : node('+node.PROP.props['id']+').TS.onSelect('+target+')');
    }
  },
  DP : {
    onProcess : function (node, signal) {
      console.log('EventNotifications : node('+node.PROP.props['id']+').DP.onProcess('+signal.toString()+')');
    }
  },
  TC : {
    onSelect : function (node, signal) {
      console.log('EventNotifications : node('+node.PROP.props['id']+').TC.onSelect('+signal.toString()+')');
    }
  },
  EM : {
    onSignalRecieved : function (node, signal) {
      console.log('EventNotifications : node('+node.PROP.props['id']+').EM.onSignalRecieved('+signal.toString()+')');
    },
    onSignalProcess : function (node, signal) {
      console.log('EventNotifications : node('+node.PROP.props['id']+').EM.onSignalProcess('+signal.toString()+')');
    },
    onSignalSent : function (node, args) {
      console.log('EventNotifications : node('+node.PROP.props['id']+').EM.onSignalSent('+args.signal+', '+args.target+')');
    }
  },
  LC : {
    onBirth : function (node) {
      console.log('EventNotifications : node('+node.PROP.props['id']+').LC.onBirth()');
    },
    onDeath : function (node) {
      console.log('EventNotifications : node('+node.PROP.props['id']+').LC.onDeath()');
    },
    onReplicate : function (node) {
      console.log('EventNotifications : node('+node.PROP.props['id']+').LC.onReplicate()');
    },
    onClone : function (node) {
      console.log('EventNotifications : node('+node.PROP.props['id']+').LC.onClone()');
    },
    onSpawn : function (node) {
      console.log('EventNotifications : node('+node.PROP.props['id']+').LC.onSpawn()');
    }
  },
  STORE : {
    onAddSignal : function (node, signal) {
      console.log('EventNotifications : node('+node.PROP.props['id']+').STORE.onAddSignal('+signal.toString()+')');
    },
    onRemoveSignal : function (node, signal) {
      console.log('EventNotifications : node('+node.PROP.props['id']+').STORE.onRemoveSignal('+signal.toString()+')');
    },
    onAddConnection : function (node, nodeID) {
      console.log('EventNotifications : node('+node.PROP.props['id']+').STORE.onAddConnection('+nodeID+')');
    },
    onRemoveConnection : function (node, nodeID) {
      console.log('EventNotifications : node('+node.PROP.props['id']+').STORE.onRemoveConnection('+nodeID+')');
    }
  },
  PROP : {
    onGetProperty : function (node, prop) {
      console.log('EventNotifications : node('+node.PROP.props['id']+').PROP.onGetProperty('+prop+')');
    },
    onSetProperty : function (node, args) {
      console.log('EventNotifications : node('+node.PROP.props['id']+').PROP.onSetProperty('+args.prop+', '+args.value+')');
    },
    onRemoveProperty : function (node, prop) {
      console.log('EventNotifications : node('+node.PROP.props['id']+').PROP.onRemoveProperty('+prop+')');
    }
  }
};

if (typeof Spock === 'undefined') { // NodeJS
  module.exports = TESTING_EventNotifications;
} else {
  Spock.Templates.modules.TESTING_EventNotifications = TESTING_EventNotifications;
}
