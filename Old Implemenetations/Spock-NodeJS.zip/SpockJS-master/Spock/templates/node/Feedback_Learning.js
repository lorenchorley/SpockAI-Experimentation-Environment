Feedback_Learning = {
  TS : {
    onSelect : function (node) {
      
    }
  },
  DP : {
    onProcess : function (node, singal) {
      if (signal.backward === true) {
        //
      }
    }
  },
  IN : {
    storeSignal : function (processedSignal, sendingNodeID) {
      
    }
  },
  STORE : {
    feedbackConnections : {}
  }
};

if (typeof Spock === 'undefined') { // NodeJS
  module.exports = Feedback_Learning;
} else {
  Spock.Templates.modules.Feedback_Learning = Feedback_Learning;
}
