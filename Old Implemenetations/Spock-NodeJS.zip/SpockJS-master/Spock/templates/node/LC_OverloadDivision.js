LC_OverloadDivision = {
  FC : function () {},
  TS : function () {},
  DP : function () {},
  TC : function () {},
  LC : function () {},
  EM : function () {},
  IN : function () {},
  OUT : function () {},
  STORE : function () {},
  PROP : function () {}
};

if (typeof Spock === 'undefined') { // NodeJS
  module.exports = LC_OverloadDivision;
} else {
  Spock.Templates.modules.LC_OverloadDivision = LC_OverloadDivision;
}
