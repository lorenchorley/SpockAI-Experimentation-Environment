DP_Prefix = {
  DP : {
    onProcess : function (node, signal) {
      signal = 'processed' + signal;
      
      return signal;
    }
  }
};

if (typeof Spock === 'undefined') { // NodeJS
  module.exports = DP_Prefix;
} else {
  Spock.Templates.modules.DP_Prefix = DP_Prefix;
}
