PROP_Genetic = {
  PROP : function () {}
};

if (typeof Spock === 'undefined') { // NodeJS
  module.exports = PROP_Genetic;
} else {
  Spock.Templates.modules.PROP_Genetic = PROP_Genetic;
}
