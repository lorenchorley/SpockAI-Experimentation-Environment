var Tools = {};

Tools.init = function (gns) {
  Spock = gns;
  Tools.initialised = true;
};

Tools.runActions = function(node, module, hook, args) {
  Spock.Tools.logFunction("runActions", hook);
  var actions = module[hook + 'Actions'];
  if (actions !== undefined) {
    for (var a in actions) {
      actions[a](node, args);
    }
  }
};

//Network related
Tools.getLocalAddress = function () {
  function _localAddress() {
    var os=require('os');
    var ifaces=os.networkInterfaces();
    var addrs = {};
    var ifacename, lo = '', ext = '';
    for (var dev in ifaces) {
      var alias=0;
      ifaces[dev].forEach(function (details) {
        if (details.family=='IPv4') {
          ifacename = dev+(alias?':'+alias:'');
          if (ifacename === 'lo') {
            lo = details.address;
          } else {
            ext = details.address;
          }
          addrs[dev+(alias?':'+alias:'')] = details.address;
          ++alias;
        }
      });
    }
    if (ext === '') {
      if (lo === '') {
        // We've got a problem
      } else {
        ext = lo;
      }
    }
    return ext;
  }
  
  return _localAddress();
};

Tools.openSimpleMessageChannel = function (targeturl) {
  
  return {
    send : function (message, callback) {}
  };
};

Tools.simpleMessageSendAndRecieve = function (message, targeturl, callback) {
  
  // send message to targeturl
  // return unable to send message on failure
  
  // when reponse recieved, call callback(reponse);
  
};

Tools.simpleMessageServer = function (port, callback) {
  
  var that = {};
  
  // setup web server
  // return fallure string if port is taken
  // when message recieved, send reponse = callback(message);
  
  that.shutdown = function () {
    
  };
  
  return that;
};

// general
Tools.cloneObjectByPrototype = function (o) {
  function F() {}
  F.prototype = o;
  return new F();
};

Tools.cloneObject = function (obj) {
    if (null == obj || "object" != typeof obj) return obj;
    var copy = obj.constructor();
    for (var attr in obj) {
        if (obj.hasOwnProperty(attr)) copy[attr] = obj[attr];
    }
    return copy;
}

// diagnostics
Tools.printObjectMethods = function (object, maxdepth, ignorelist, hasowncheck, depth, prefix) {
  if (hasowncheck === undefined) {
    hasowncheck = true;
  }
  if (maxdepth === undefined) {
    maxdepth = 1;
  }
  if (depth === undefined) {
    depth = 0;
  }
  if (depth === 0) {
    prefix = "";
  } else {
    prefix += "  ";
  }
  if (ignorelist === undefined) {
    ignorelist = [];
  }
  for (var o in object) {
    if (!hasowncheck || object.hasOwnProperty(o)) {
      if (!(typeof(object[o]) === 'object') && !(typeof(object[o]) === 'function')) {
        console.log(prefix + o + ' : ' + object[o]);
      }
    }
  }
  for (var o in object) {
    if (!hasowncheck || object.hasOwnProperty(o)) {
      if (typeof(object[o]) === 'function') {
        console.log(prefix + o + '()');
      }
    }
  }
  for (var o in object) {
    if (!hasowncheck || object.hasOwnProperty(o)) {
      if (typeof(object[o]) === 'object') {
        for (var i = 0; i < ignorelist.length; i++) {
          if (ignorelist[i] !== o) {
            console.log(prefix + o + " {");
            if (depth !== maxdepth) {
              Spock.Tools.printObjectMethods(object[o], maxdepth, ignorelist, hasowncheck, depth + 1, prefix);
            } else {
              console.log(prefix + "-");
            }
            console.log(prefix + "}");
          } else {
            console.log(prefix + o);
          }
        }
      }
    }
  }
};

Tools.scheduleDelay = 1;

Tools.scheduleFunction = function (func) {
  setTimeout(func, Tools.scheduleDelay);
};

//Logging
Tools.logEvent = function (event) {
  console.log("");
  console.log("(event) " + event);
  console.log("");
};

Tools.enableWarningLogging = true;

Tools.logWarning = function (msg) {
  if (Spock.Tools.enableWarningLogging) {
    console.log("(warning) " + msg);
  }
};

Tools.enableFunctionLogging = false;

Tools.logFunction = function () {
  if (Spock.Tools.enableFunctionLogging) {
    var argsStr = "";
    for(var i = 1; i < arguments.length; i++) {
      if (argsStr !== "") {
        argsStr += ", ";
      }
      argsStr += arguments[i];
    }
    console.log("(function call) " + arguments[0] + "(" + argsStr + ")");
  }
};

Tools.enableProgressLogging = false;

Tools.logProgress = function (message) {
  if (Spock.Tools.enableProgressLogging) {
    console.log("(code) " + message);
  }
};

Tools.logError = function (message) {
  console.log("(error) " + message);
  
};


if (typeof Spock === 'undefined') { // NodeJS
  var Spock = {};
  module.exports = Tools;
} else { // Javascript
  Spock.Tools = Tools;
}
