var Environment = {};

Environment.init = function (gns) {
  Spock = gns;
  Environment.initialised = true;
};

Environment.newEnvironment = function (port, type) {

  var e = {};
  e.components = {};
  e.contextClass = "environment";
  e.type = type;
  e.lastUID = 0;
  e.getUID = function () {
    Spock.Tools.logFunction("EnvironmentInstance.getUID");
    
    e.lastUID++;
    return e.lastUID;
  }
  
  e.getComponents = function () {
    Spock.Tools.logFunction("EnvironmentInstance.getComponents");
    return e.components;
  };
  
  Spock.Common.addInterfacingCapability(e, port);
  
  return e;
};

Environment.loadContext = function (port, path) {

};

Environment.saveContext = function (path) {

};

Environment.printSummary = function (env) {
  //TODO
};

if (typeof Spock === 'undefined') { // NodeJS
  var Spock = {};
  module.exports = Environment;
} else { // Javascript
  Spock.Environment = Environment;
}
