package spock.network.ejb.support;

import java.util.Map;

/**
 *
 * @author Loren Chorley
 */
public class NetworkDetails {
    
    protected Boolean isPaused;
    protected Boolean isStopped;
    protected Map<String, String> observables;

    public NetworkDetails(Boolean isPaused, Boolean isStopped, Map<String, String> observables) {
        this.isPaused = isPaused;
        this.isStopped = isStopped;
        this.observables = observables;
    }

    /**
     * Get the value of isPaused
     *
     * @return the value of isPaused
     */
    public Boolean getIsPaused() {
        return isPaused;
    }

    /**
     * Get the value of isStopped
     *
     * @return the value of isStopped
     */
    public Boolean getIsStopped() {
        return isStopped;
    }
    
    /**
     * Get the value of observables
     *
     * @return the value of observables
     */
    public Map<String, String> getObservables() {
        return observables;
    }
    
}
