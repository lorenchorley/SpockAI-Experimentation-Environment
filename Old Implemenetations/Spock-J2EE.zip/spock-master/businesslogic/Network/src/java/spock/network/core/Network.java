package spock.network.core;

import spock.network.ejb.support.NetworkNodeTemplate;
import spock.common.interfaces.SpockObservable;
import spock.common.interfaces.SpockObservableLong;
import spock.common.interfaces.SpockRunnable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import spock.network.core.exceptions.InvalidNetworkInterfaceException;
import spock.network.core.exceptions.InvalidNetworkNodeException;
import spock.network.ejb.support.NetworkDetails;
import tools.errorChecking.Log;

/**
 * Represents one network simulation. Manages nodes and network observables
 * as well as giving access to pause and resume functionality and calculating
 * the average number of network node activations per second.
 * 
 * @author Loren Chorley
 */
public class Network extends Thread implements SpockRunnable {
    private static final Logger logger = Logger.getLogger("spock.network.core.Network");
    
    private boolean isPaused = false;
    private boolean isStopped = false;
    private String name;
    
    private ArrayList<NetworkNode> nodes;
    // Add property methods with validation
    private ArrayList<NetworkInterface> interfaces;
    private HashMap<String, SpockObservable> observables;
    private NetworkNodeTemplate defaultNodeTemplate;

    public Network(String name) {

        // Initialise primary network objects
        nodes = new ArrayList<NetworkNode>();
        interfaces = new ArrayList<NetworkInterface>();
        observables = new HashMap<String, SpockObservable>();

        this.name = name;
        
        // Initialise interface variables
        setNetworkObservable(new SpockObservableLong("Number of nodes", 0L));
        setNetworkObservable(new SpockObservableLong("Node activations this second", 0L));
        setNetworkObservable(new SpockObservableLong("Average activations per second", 0L));

        observables.get("Average activations per second").setLogging(true);
        observables.get("Number of nodes").setLogging(true);
        
    }

    public String getNetworkName() {
        return name;
    }

    public ArrayList<NetworkInterface> getInterfaces() {
        return interfaces;
    }

    public ArrayList<NetworkNode> getNodes() {
        return nodes;
    }

    public HashMap<String, SpockObservable> getObservables() {
        return observables;
    }
    
    public void addNode(NetworkNode node) throws InvalidNetworkNodeException {
        if (node == null)
            throw new InvalidNetworkNodeException();
        
        nodes.add(node);
    }
    
    public void addInterface(NetworkInterface networkinterface) throws InvalidNetworkInterfaceException {
        if (networkinterface == null)
            throw new InvalidNetworkInterfaceException();
        
        interfaces.add(networkinterface);
    }
    
    public final void setNetworkObservable(SpockObservable networkObservable) {
        observables.put(networkObservable.getName(), networkObservable);
    }

    public NetworkNodeTemplate getDefaultNodeTemplate() {
        return defaultNodeTemplate;
    }

    public void setDefaultNodeTemplate(NetworkNodeTemplate defaultNodeTemplate) {
        this.defaultNodeTemplate = defaultNodeTemplate;
    }
    
    @Override
    public void run() {
        assert(networkSize() > 0) : "Starting network of positive size";

        Log.writeForThreadCreation("Network");
        assert(this.isAlive()) : "Network thread started";

        for (NetworkNode n : nodes)
            n.startActivity();

        ((SpockObservableLong) observables.get("Number of nodes")).setValue(networkSize());

        long average_sum = 0;
        long seconds_passed = 0;
        
        // Calculate the average node activations per second
        while (!isStopped) {
            
            if (isPaused) {
                // TODO figure out how to block here
            }
            
            try {
                sleep(1000);
            } catch (InterruptedException ex) {
                logger.log(Level.INFO,
                           "Network thread interrupted while sleeping, yawn...",
                           new Object[] {  });
            }
            
            if (seconds_passed >= 5) {
                ((SpockObservableLong) observables.get("Average activations per second")).setValue(average_sum / 5);
                average_sum = 0;
                seconds_passed = 0;
            } else {
                average_sum += ((SpockObservableLong) observables.get("Node activations this second")).getValue();
                seconds_passed++;
            }
            
        }
        
    }

    public long networkSize() {
        return nodes.size();
    }

    public long getUniqueNodeID() {
        return 0;
    }
    
    @Override
    public void startActivity() {
        start();
    }
    
    @Override
    public void pauseActivity() {
        isPaused = true;
        for (NetworkNode n : nodes)
            n.pauseActivity();
    }

    @Override
    public void resumeActivity() {
        isPaused = false;
        for (NetworkNode n : nodes)
            n.resumeActivity();
    }
    
    @Override
    public void stopActivity() {
        isStopped = true;
        for (NetworkNode n : nodes)
            n.stopActivity();
    }

    @Override
    public boolean hasStopped() {
        for (NetworkNode n : nodes) {
            if (!n.hasStopped())
                return false;
        }
        return true;
    }
    
    public NetworkDetails getNetworkDetails() {
        //return new NetworkDetails(isPaused, isStopped, observables);
        return null;
    }
    
}
