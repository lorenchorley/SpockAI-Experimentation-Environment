package spock.network.ejb.exceptions;

import java.rmi.RemoteException;

/**
 *
 * @author Loren Chorley
 */
public class InvalidNetwork extends RemoteException {
    
}
