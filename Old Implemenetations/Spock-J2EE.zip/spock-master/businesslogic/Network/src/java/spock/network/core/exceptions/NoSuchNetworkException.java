package spock.network.core.exceptions;

/**
 *
 * @author Loren Chorley
 */
public class NoSuchNetworkException extends Exception {
    
}
