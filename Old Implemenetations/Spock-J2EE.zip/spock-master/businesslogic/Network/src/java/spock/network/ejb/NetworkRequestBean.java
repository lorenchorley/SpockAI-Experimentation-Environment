package spock.network.ejb;

import java.rmi.RemoteException;
import java.util.Collection;
import javax.ejb.Stateless;
import javax.ejb.EJB;
import spock.network.core.exceptions.InvalidNetworkInterfaceException;
import spock.network.core.exceptions.InvalidNetworkNodeException;
import spock.network.ejb.support.NetworkInitialisation;
import spock.network.core.exceptions.InvalidNetworkException;
import spock.network.core.exceptions.InvalidNetworkInitialisationException;
import spock.network.ejb.support.NetworkDetails;
import spock.network.ejb.support.NetworkInitialisationInterface;

/**
 *
 * @author Loren Chorley
 */
@Stateless
public class NetworkRequestBean implements NetworkRequest {
    
    @EJB
    public NetworkManagementBean mgmt; 
    
    @Override
    public String returnTestString() {
        return "Spock Network test string.";
    }

    @Override
    public void initialiseNewNetwork(NetworkInitialisationInterface initialisation) throws RemoteException, ClassNotFoundException, InstantiationException, IllegalAccessException, InvalidNetworkNodeException, InvalidNetworkInterfaceException, InvalidNetworkInitialisationException {
        if (!(initialisation instanceof NetworkInitialisation))
            throw new InvalidNetworkInitialisationException();
        
        mgmt.InitialiseNetwork((NetworkInitialisation) initialisation);
    }

    @Override
    public void startNetwork(String name) throws InvalidNetworkException {
        if (!mgmt.networks.containsKey(name))
            throw new InvalidNetworkException();
            
        mgmt.networks.get(name).startActivity();
    }

    @Override
    public void pauseNetwork(String name) throws InvalidNetworkException {
        if (!mgmt.networks.containsKey(name))
            throw new InvalidNetworkException();
            
        mgmt.networks.get(name).pauseActivity();
    }

    @Override
    public void resumeNetwork(String name) throws InvalidNetworkException {
        if (!mgmt.networks.containsKey(name))
            throw new InvalidNetworkException();

        mgmt.networks.get(name).resumeActivity();
    }

    @Override
    public void stopNetwork(String name) throws InvalidNetworkException {
        if (!mgmt.networks.containsKey(name))
            throw new InvalidNetworkException();
            
        mgmt.networks.get(name).stopActivity();
    }

    @Override
    public NetworkDetails getNetworkDetails(String name) throws InvalidNetworkException {
        if (!mgmt.networks.containsKey(name))
            throw new InvalidNetworkException();
            
        return mgmt.networks.get(name).getNetworkDetails();
    }

    @Override
    public Collection<String> listNetworks() {
        return mgmt.networks.keySet();
    }

}
