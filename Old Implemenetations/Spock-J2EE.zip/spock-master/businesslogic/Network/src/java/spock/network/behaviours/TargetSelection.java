package spock.network.behaviours;

import spock.common.signals.NetworkSignal;
import spock.network.core.NetworkNode;

/**
 * @author Loren Chorley
 */
public abstract class TargetSelection extends NetworkBehaviour<TargetSelection> {
    
    @Override
    public void replaceInNode(NetworkNode node, TargetSelection behaviour) {
        node.targetSelection = behaviour;
    }
    
    public abstract NetworkNode selectTarget(NetworkSignal signal);

}
