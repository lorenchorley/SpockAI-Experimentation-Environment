package spock.network.ejb.support;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import spock.network.behaviours.*;
import spock.network.core.Network;
import spock.network.core.NetworkNode;

/**
 * Allows for the creation of an arbitrary number of nodes with the same behaviour
 * @author Loren Chorley
 */
public class NetworkNodeTemplate implements Serializable {
    private static final Logger logger = Logger.getLogger("spock.network.core.NetworkNodeTemplate");
    private boolean logged = false;
    
    private String name;
    private Map<String, String> classPaths;

    //TODO Add load from url functionality
    
    /**
     * 
     * @param classInputProcess
     * @param classOutputProcess
     * @param classStorageProcess
     * @param classNodeProperties
     * @param classFiringCondition
     * @param classTargetSelection
     * @param classEnergyEconomics
     * @param classLifeCycle
     * @param classDataProcessing
     * @param classTransmissionContent 
     */
    public NetworkNodeTemplate(String name,
                               String classInputProcess,
                               String classOutputProcess,
                               String classStorageProcess,
                               String classNodeProperties, 
                               String classFiringCondition, 
                               String classTargetSelection, 
                               String classEnergyEconomics, 
                               String classLifeCycle, 
                               String classDataProcessing, 
                               String classTransmissionContent) {

        assert((name != null) && ("".equals(name)) &&
               (classInputProcess != null) && 
               (classOutputProcess != null) && 
               (classStorageProcess != null) && 
               (classFiringCondition != null) && 
               (classTargetSelection != null) && 
               (classNodeProperties != null) && 
               (classEnergyEconomics != null) && 
               (classDataProcessing != null) && 
               (classLifeCycle != null) && 
               (classTransmissionContent != null))
                : "Non-null classes were passed to NetworkNodeTemplate constructor";

        this.name = name;
        
        classPaths = new HashMap<String, String>();
        
        classPaths.put("InputProcess", classInputProcess);
        classPaths.put("OutputProcess", classOutputProcess);
        classPaths.put("StorageProcess", classStorageProcess);
        classPaths.put("NodeProperties", classNodeProperties);
        classPaths.put("FiringCondition", classFiringCondition);
        classPaths.put("TargetSelection", classTargetSelection);
        classPaths.put("EnergyEconomics", classEnergyEconomics);
        classPaths.put("LifeCycle", classLifeCycle);
        classPaths.put("DataProcessing", classDataProcessing);
        classPaths.put("TransmissionContent", classTransmissionContent);
        
    }

    /**
     * Get the name of the template
     * @return the name of the template
     */
    public String getName() {
        return name;
    }
    
    /**
     * 
     * @param network
     * @return
     * @throws ClassNotFoundException
     * @throws InstantiationException
     * @throws IllegalAccessException 
     */
    public NetworkNode newInstance(Network network) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
        NetworkNode n = new NetworkNode(network,
                                       (InputProcess) newNetworkBehaviour("InputProcess"),
                                       (OutputProcess) newNetworkBehaviour("OutputProcess"),
                                       (StorageProcess) newNetworkBehaviour("StorageProcess"),
                                       (NodeProperties) newNetworkBehaviour("NodeProperties"),                
                                       (FiringCondition) newNetworkBehaviour("FiringCondition"), 
                                       (TargetSelection) newNetworkBehaviour("TargetSelection"), 
                                       (EnergyEconomics) newNetworkBehaviour("EnergyEconomics"), 
                                       (LifeCycle) newNetworkBehaviour("LifeCycle"), 
                                       (DataProcessing) newNetworkBehaviour("DataProcessing"), 
                                       (TransmissionContent) newNetworkBehaviour("TransmissionContent"));
        
        // Only log output once
        logged = true;
        
        return n;
    }
    
    /**
     * 
     * @param type
     * @return
     * @throws ClassNotFoundException
     * @throws InstantiationException
     * @throws IllegalAccessException 
     */
    private NetworkBehaviour newNetworkBehaviour(String type) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
        String subpath;
        Class nbClass;
        NetworkBehaviour nb;
            
        // If class path not specified, use default class
        subpath = classPaths.get(type);
        if ("".equals(subpath)) {
            subpath = type;
        }
        
        if (!logged) {
            logger.log(Level.INFO,
                       "NetworkNodeTemplate: loading class {0}",
                       new Object[] { "spock.network.behaviours." + subpath });
        }
            
        nbClass = Class.forName("spock.network.behaviours." + subpath);
        nb = (NetworkBehaviour) nbClass.newInstance();

        return nb;
    }
    
}
