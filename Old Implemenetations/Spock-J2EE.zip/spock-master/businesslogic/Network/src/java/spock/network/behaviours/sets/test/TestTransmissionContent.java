package spock.network.behaviours.sets.test;

import spock.network.behaviours.TransmissionContent;
import java.util.logging.Level;
import java.util.logging.Logger;
import spock.common.signals.NetworkSignal;

/**
 *
 * @author Loren Chorley
 */
public class TestTransmissionContent extends TransmissionContent {
    private static final Logger logger = Logger.getLogger("spock.network.behaviours.sets.test.TestTransmissionContent");

    @Override
    public NetworkSignal selectContent() {
        NetworkSignal ns = parentNode.storageProcess.retrieveSignal();
        logger.log(Level.INFO,
                   "TestTransmissionContent.selectContent: {0}",
                   new Object[] { ns.getData().toString() });
        return ns;
    }

    @Override
    public boolean signalsRemain() {
        logger.log(Level.INFO,
                   "TestTransmissionContent.signalsRemain: {0}",
                   new Object[] { parentNode.storageProcess.hasSignals() ? "true" : "false" });
        return parentNode.storageProcess.hasSignals();
    }

    @Override
    public TransmissionContent replicate(TransmissionContent parentBehaviour) {
        logger.log(Level.INFO,
                   "TestTransmissionContent.replicate",
                   new Object[] {  });
        return new TestTransmissionContent();
    }

    @Override
    public void activityProcess() {
        logger.log(Level.INFO,
                   "TestTransmissionContent.activityProcess",
                   new Object[] {  });
        stopActivity();
    }
    
}
