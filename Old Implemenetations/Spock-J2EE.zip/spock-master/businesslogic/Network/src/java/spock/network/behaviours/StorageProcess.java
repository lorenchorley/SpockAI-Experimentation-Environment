package spock.network.behaviours;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.Queue;
import java.util.logging.Level;
import java.util.logging.Logger;
import spock.common.signals.NetworkSignal;
import spock.network.core.NetworkNode;
import tools.errorChecking.Log;

/**
 * Storage of data and other nodes that are connected to this one
 * 
 * @author Loren Chorley
 */
public class StorageProcess extends NetworkBehaviour<StorageProcess> {

    protected Queue<NetworkSignal> signals;
    public Collection<NetworkNode> targetNodes;

    @Override
    public StorageProcess replicate(StorageProcess parentBehaviour) {
        return new StorageProcess();
    }

    @Override
    public void replaceInNode(NetworkNode node, StorageProcess behaviour) {
        node.storageProcess = behaviour;
    }

    public StorageProcess() {
        signals = new LinkedList<NetworkSignal>();
        targetNodes = new ArrayList<NetworkNode>();
    }

    public void storeSignal(NetworkSignal signal) {
        synchronized (this) {
            signals.add(signal);

            Log.writeForMechanisms("StorageProcess: storing data: " + signal.toString());

            notifyAll();
        }
        parentNode.firingCondition.refresh(); // Not sure about this
    }

    public NetworkSignal retrieveSignal() {
        synchronized (this) {
            while (signals.size() == 0) {
                try {
                    wait();
                } catch (InterruptedException ex) { }
            }

            Log.writeForMechanisms("StorageProcess: retreiving data:" + signals.peek().toString());

            return signals.remove();
        }
    }

    public boolean hasSignals() {
        return signals.size() > 0;
    }

    @Override
    public void activityProcess() {
        stopActivity();
    }

}
