package spock.network.behaviours.independent;

import java.util.Random;
import spock.network.behaviours.NodeProperties;

/**
 * @author Loren Chorley
 */
public class GeneticSequenceNodeProperties extends NodeProperties {
	
    public GeneticSequenceNodeProperties() {
        // Move to genetic properties
        requestProperty("Mutation rate", Double.class, 0.0, new GeneFunctions() {

            @Override
            public Object mutate(Object originalValue, double mutationRate) {
                return originalValue;
            }

            @Override
            public Object getUpperBound() {
                return 1.0;
            }

            @Override
            public Object getLowerBound() {
                return 0.0;
            }

            @Override
            public int compare(Object thisValue, Object otherValue) {
                if (Double.parseDouble(thisValue.toString()) == Double.parseDouble(otherValue.toString()))
                    return 0;
                else
                    return Double.parseDouble(thisValue.toString()) > Double.parseDouble(otherValue.toString()) ? 1 : -1;
            }

        });
    }
    
	protected GeneticSequenceNodeProperties mutate(double mutationRate) {
            Random r = new Random();
            try {
                GeneticSequenceNodeProperties gs = this.getClass().newInstance();
                for (String id : properties.keySet()) {
                    if (r.nextDouble() <= mutationRate)
                        gs.requestProperty(id, properties.get(id).datatype, properties.get(id).fns.mutate(properties.get(id).value, mutationRate), properties.get(id).fns);
                    else
                        gs.requestProperty(id, properties.get(id).datatype, properties.get(id).value, properties.get(id).fns);
                    // TODO add something that implements the mutation rate
                }
                return gs;
            } catch (InstantiationException e) {
                e.printStackTrace();
                System.exit(-1);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
                System.exit(-1);
            }
            return null;
	}
	
	protected GeneticSequenceNodeProperties splice(GeneticSequenceNodeProperties geneticSequence) {
            // TODO
            return null;
	}
	
}
