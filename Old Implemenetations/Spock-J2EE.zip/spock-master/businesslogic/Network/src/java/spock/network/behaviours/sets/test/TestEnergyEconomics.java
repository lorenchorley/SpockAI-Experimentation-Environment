package spock.network.behaviours.sets.test;

import spock.network.behaviours.EnergyEconomics;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Loren Chorley
 */
public class TestEnergyEconomics extends EnergyEconomics {
    private static final Logger logger = Logger.getLogger("spock.network.behaviours.sets.test.TestEnergyEconomics");

    @Override
    public EnergyEconomics replicate(EnergyEconomics parentBehaviour) {
        logger.log(Level.INFO,
                   "TestEnergyEconomics.replicate",
                   new Object[] {  });
        return new TestEnergyEconomics();
    }

    @Override
    public void activityProcess() {
        logger.log(Level.INFO,
                   "TestEnergyEconomics.activityProcess",
                   new Object[] {  });
        stopActivity();
    }
    
}
