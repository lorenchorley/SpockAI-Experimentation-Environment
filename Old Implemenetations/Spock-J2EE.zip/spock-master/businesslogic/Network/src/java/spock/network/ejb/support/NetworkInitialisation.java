package spock.network.ejb.support;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import spock.network.core.exceptions.ConnectionAlreadyExistException;
import spock.network.core.exceptions.InvalidInterfaceNameException;
import spock.network.core.exceptions.InvalidNetworkInitialisationNameException;
import spock.network.core.exceptions.InvalidNodeTemplateNameException;
import spock.network.core.exceptions.InvalidNodeNameException;

/**
 * An instance contains a list of instructions that are necessary and sufficient
 * for initialising a network simulation. It is serialisable so that instances 
 * may be constructed and sent across a network.
 * 
 * In a NetworkInitialisation object, you may record a name or ID, a set of 
 * NetworkNode behaviours or templates, a list of nodes to create according
 * to the templates, a list of diectional connections between nodes, and a
 * list of NetworkInterfaces, their connections and a type.
 * 
 * @author Loren Chorley
 */
public class NetworkInitialisation implements NetworkInitialisationInterface {
    
    protected String name = "default_network_name";
    protected Map<String, NetworkNodeTemplate> nodeTemplates;    
    protected Map<String, String> nodes;
    protected Map<String, Collection<String>> nodeConnections;
    protected Map<String, Collection<String>> networkInterfaces;
    protected Map<String, Boolean> networkInterfaceTypes;
    protected String defaultNodeTemplate = null;
    
    public NetworkInitialisation() {
        nodeTemplates = new HashMap<String, NetworkNodeTemplate>();
        nodes = new HashMap<String, String>();
        nodeConnections = new HashMap<String, Collection<String>>();
        networkInterfaces = new HashMap<String, Collection<String>>();
        networkInterfaceTypes = new HashMap<String, Boolean>();
    }
    
    /**
     * 
     * @return 
     */
    @Override
    public boolean isValid() {
        if (defaultNodeTemplate == null) 
            return false;
        if (nodes.size() == 0)
            return false;
        
        
        return true;
    }
    
    /**
     * Get the value of name
     *
     * @return The value of name
     */
    @Override
    public String getName() {
        return name;
    }

    /**
     * 
     * Set the value of name
     *
     * @param name The new value of name
     * @throws InvalidNetworkInitialisationNameException If the name is null or empty
     */
    public void setName(String name) throws InvalidNetworkInitialisationNameException {
        if (name == null || name.isEmpty()) {
            throw new InvalidNetworkInitialisationNameException();
        }
                
        this.name = name;
    }

    /**
     * Get the value of templates
     *
     * @return the value of templates
     */
    public Map<String, NetworkNodeTemplate> getNodeTemplates() {
        return nodeTemplates;
    }

    /**
     * Add template to the collection of of templates
     *
     * @param template The new template to add
     * @throws InvalidNodeTemplateNameException If the template name already exists
     */
    public void addNodeTemplate(NetworkNodeTemplate template) throws InvalidNodeTemplateNameException {
        if (nodeTemplates.containsKey(template.getName())) {
            throw new InvalidNodeTemplateNameException();
        }
        
        nodeTemplates.put(template.getName(), template);
        
    }

    /**
     * Get the node set
     *
     * @return The node set
     */
    public Map<String, String> getNodes() {
        return nodes;
    }

    /**
     * Add a node with an associated set of templates
     *
     * @param nodeName The name of the node
     * @param templateName The name of the template set to associate with the node
     * @throws InvalidNodeTemplateNameException If the template name already exists
     * @throws InvalidNodeNameException if either the node name has already been used or it is "type" which is a reserved name
     */
    public void addNode(String nodeName, String templateName) throws InvalidNodeTemplateNameException, InvalidNodeNameException {
        if (!nodeTemplates.containsKey(templateName)) {
            throw new InvalidNodeTemplateNameException();
        }
        if (nodeTemplates.containsKey(nodeName) || "type".equals(nodeName)) {
            throw new InvalidNodeNameException();
        }
        
        nodes.put(nodeName, templateName);
        
    }

    /**
     * Get the node connections
     *
     * @return The node connections
     */
    public Map<String, Collection<String>> getNodeConnections() {
        return nodeConnections;
    }

    /**
     * Records a connection between two previously entered node names
     * 
     * @param sendingNode The node that sends data to the other
     * @param receivingNode The node that receives data from the other
     * @param bothWays If true, adds the connections in the reverse order as well.
     * @throws InvalidNodeNameException If either of the nodes have not been added yet.
     * @throws ConnectionAlreadyExistException If the connection already exists
     */
    public void addNodeConnection(String sendingNode, String receivingNode, boolean bothWays) throws InvalidNodeNameException, ConnectionAlreadyExistException {
        if (!nodes.containsKey(sendingNode) || !nodes.containsKey(receivingNode)) {
            throw new InvalidNodeNameException();
        }
        
        Collection<String> receivingNodes;
        
        if (nodeConnections.containsKey(sendingNode)) {
            receivingNodes = nodeConnections.get(sendingNode);
        } else {
            receivingNodes = new ArrayList<String>();
            nodeConnections.put(sendingNode, receivingNodes);
        }
        
        // Only add the connection if it doesn't already exist
        if (!receivingNodes.contains(receivingNode)) {
            receivingNodes.add(receivingNode);
        } else {
            throw new ConnectionAlreadyExistException();
        }
        
        if (bothWays)
            addNodeConnection(receivingNode, sendingNode, false);
        
    }
    
    /**
     * Get the network interfaces
     *
     * @return The network interfaces
     */
    public Map<String, Collection<String>> getNetworkInterfaces() {
        return networkInterfaces;
    }

    /**
     * Get the network interface types
     *
     * @return The network interface types
     */
    public Map<String, Boolean> getNetworkInterfaceTypes() {
        return networkInterfaceTypes;
    }
    
    /**
     * Add a network interface
     *
     * @param interfaceName The name of the interface
     * @param interfaceNodes A collection of node names that the interface connects to
     * @param type The type of network interface: INPUT_INTERFACE or OUTPUT_INTERFACE
     * @throws InvalidInterfaceNameException If the interface already exists
     * @throws InvalidNodeNameException If a node name does not already exist
     */
    public void addNetworkInterfaces(String interfaceName, Collection<String> interfaceNodes, boolean type) throws InvalidInterfaceNameException, InvalidNodeNameException {
        if (networkInterfaces.containsKey(interfaceName)) {
            throw new InvalidInterfaceNameException();
        }
        for (String node : interfaceNodes) {
            if (!nodes.containsKey(node))
                throw new InvalidNodeNameException();
        }
        
        networkInterfaces.put(interfaceName, interfaceNodes);
        networkInterfaceTypes.put(interfaceName, type);
        
    }

    public String getDefaultNodeTemplate() {
        return defaultNodeTemplate;
    }

    public void setDefaultNodeTemplate(String defaultNodeTemplate) throws InvalidNodeTemplateNameException {
        if (!nodeTemplates.containsKey(defaultNodeTemplate))
            throw new InvalidNodeTemplateNameException();
        
        this.defaultNodeTemplate = defaultNodeTemplate;
    }
    
}
