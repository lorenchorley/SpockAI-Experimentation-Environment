package spock.network.ejb.exceptions;

/**
 *
 * @author Loren Chorley
 */
public class InvalidNetworkInitialisationNameException extends Exception {
    
}
