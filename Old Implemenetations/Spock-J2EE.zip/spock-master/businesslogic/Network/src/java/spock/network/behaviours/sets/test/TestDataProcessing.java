package spock.network.behaviours.sets.test;

import java.util.logging.Level;
import java.util.logging.Logger;
import spock.common.signals.NetworkSignal;
import spock.network.behaviours.DataProcessing;

/**
 *
 * @author Loren Chorley
 */
public class TestDataProcessing extends DataProcessing {
    private static final Logger logger = Logger.getLogger("spock.network.behaviours.sets.test.TestDataProcessing");
    
    @Override
    public NetworkSignal processData(NetworkSignal data) {
        logger.log(Level.INFO,
                   "TestDataProcessing.processData: {0}",
                   new Object[] { data.getData().toString() });
        return data;
    }

    @Override
    public DataProcessing replicate(DataProcessing parentBehaviour) {
        logger.log(Level.INFO,
                   "TestDataProcessing.replicate",
                   new Object[] {  });
        return new TestDataProcessing();
    }

    @Override
    public void activityProcess() {
        logger.log(Level.INFO,
                   "TestDataProcessing.activityProcess",
                   new Object[] {  });
        stopActivity();
    }
    
}
