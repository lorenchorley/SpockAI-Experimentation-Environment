package spock.network.ejb.exceptions;

/**
 *
 * @author Loren Chorley
 */
public class ConnectionAlreadyExistException extends Exception {
    
}
