package spock.network.ejb.exceptions;

/**
 *
 * @author Loren Chorley
 */
public class NoSuchNetworkException extends Exception {
    
}
