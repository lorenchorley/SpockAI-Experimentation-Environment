package spock.network.core;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Loren Chorley
 */
public class NetworkObservable<E> {
    private static final Logger logger = Logger.getLogger("spock.network.core.NetworkObservable");
    
    private String name;
    protected E value;    
    protected boolean logging = false;

    public NetworkObservable(String name, E initial_value) {
        this.name = name;
        this.value = initial_value;
    }

    /**
     * Get the name of the network observable
     *
     * @return The name of the network observable
     */
    public String getName() {
        return name;
    }
    
    /**
     * Get the value of the network observable
     *
     * @return the value of the network observable
     */
    public E getValue() {
        return value;
    }

    /**
     * Get the value of the network observable as a string
     *
     * @return the value of the network observablein a string
     */
    public String getValueAsString() {
        return value.toString();
    }
    
    /**
     * Set the value of the network observable
     *
     * @param the new value of the network observable
     */
    public void setValue(E value) {
        this.value = value;
        if (logging)
            logger.log(Level.INFO,
                       "Observerable {0} changed to {1}",
                       new Object[] { name, value });
    }

    /**
     * Get whether to log updates to this observable
     *
     * @return the value of logging
     */
    public boolean isLogging() {
        return logging;
    }

    /**
     * Set whether to log updates to this observable
     *
     * @param Logging new value of logging
     */
    public void setLogging(boolean logging) {
        this.logging = logging;
    }

    
}
