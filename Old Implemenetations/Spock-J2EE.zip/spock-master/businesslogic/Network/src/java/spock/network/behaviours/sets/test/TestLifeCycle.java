package spock.network.behaviours.sets.test;

import spock.network.behaviours.LifeCycle;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Loren Chorley
 */
public class TestLifeCycle extends LifeCycle {
    private static final Logger logger = Logger.getLogger("spock.network.behaviours.sets.test.TestLifeCycle");

    @Override
    public LifeCycle replicate(LifeCycle parentBehaviour) {
        logger.log(Level.INFO,
                   "TestLifeCycle.replicate",
                   new Object[] {  });
        return new TestLifeCycle();
    }

    @Override
    public void activityProcess() {
        logger.log(Level.INFO,
                   "TestLifeCycle.activityProcess",
                   new Object[] {  });
        stopActivity();
    }
    
}
