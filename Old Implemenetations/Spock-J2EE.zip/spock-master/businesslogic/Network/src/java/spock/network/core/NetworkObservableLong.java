package spock.network.core;

/**
 *
 * @author Loren Chorley
 */
public class NetworkObservableLong extends NetworkObservable<Long> {
    
    public NetworkObservableLong(String name, Long initial_value) {
        super(name, initial_value);
    }

    public void add(Long number) {
        value += number;
    }
    
    public void subtract(Long number) {
        value -= number;
    }
}
