package spock.network.behaviours.independent;

import spock.network.behaviours.FiringCondition;

/**
 *
 * @author Loren Chorley
 */
public class FastFiringCondition extends FiringCondition {

    public FastFiringCondition() {
        setReady();
    }

    @Override
    public FiringCondition replicate(FiringCondition parentBehaviour) {
        return new FastFiringCondition(); // Experiment with not changing it
    }

    @Override
    public void refresh() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void activityProcess() {
        isStopped = true;
    }

    
}
