package spock.network.behaviours.sets.test;

import java.util.logging.Level;
import java.util.logging.Logger;
import spock.network.behaviours.FiringCondition;

/**
 *
 * @author Loren Chorley
 */
public class TestFiringCondition extends FiringCondition {
    private static final Logger logger = Logger.getLogger("spock.network.behaviours.sets.test.TestFiringCondition");
    
    @Override
    public void refresh() {
        logger.log(Level.INFO,
                   "TestFiringCondition.refresh",
                   new Object[] {  });
    }

    @Override
    public FiringCondition replicate(FiringCondition parentBehaviour) {
        logger.log(Level.INFO,
                   "TestFiringCondition.replicate",
                   new Object[] {  });
        return new TestFiringCondition();
    }

    @Override
    public void activityProcess() {
        logger.log(Level.INFO,
                   "TestFiringCondition.activityProcess",
                   new Object[] {  });
        stopActivity();
    }
    
}
