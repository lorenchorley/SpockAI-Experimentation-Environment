package spock.network.core;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Stateful;
import spock.common.exceptions.IncompatibleInterfacesException;
import spock.common.exceptions.InterfaceAlreadyConnectedException;
import spock.common.exceptions.InterfaceNotConnectedException;
import spock.common.exceptions.InvalidSenderIndexException;
import spock.common.exceptions.InvalidSignalException;
import spock.common.interfaces.Node;
import spock.common.interfaces.SpockInterface;
import spock.common.signals.NetworkSignal;

public class NetworkInterface implements SpockInterface {
    private static final Logger logger = Logger.getLogger("spock.network.core.NetworkInterface");
    
    private ArrayList<NetworkNode> networkNodes;
    private Network network;
    private Boolean interfaceType;
    private int numberOfNodes;
    private SpockInterface connectedInterface;
    private Map<Long, Integer> nodeMapping;
    private long id;

    public NetworkInterface() {
        networkNodes = new ArrayList<NetworkNode>();
        nodeMapping = new HashMap<Long, Integer>();
    }

    public NetworkInterface(ArrayList<NetworkNode> networkNodes, Network network, boolean interfaceType, int numberOfNodes) {
        this.networkNodes = networkNodes;
        this.network = network;
        this.interfaceType = interfaceType;
        this.numberOfNodes = numberOfNodes;
    }

    @Override
    public long getID() {
        return id;
    }

    public void setID(long id) {
        this.id = id;
    }

    public Map<Long, Integer> getNodeMapping() {
        return nodeMapping;
    }

    @Override
    public boolean interfaceType() {
        return interfaceType;
    }

    @Override
    public boolean isConnected() {
        return connectedInterface != null;
    }

    @Override
    public int getNumberOfNodes() {
        return numberOfNodes;
    }

    @Override
    public void acceptConnection(SpockInterface spockInterface) throws InterfaceAlreadyConnectedException, IncompatibleInterfacesException {
        if (isConnected())
            throw new InterfaceAlreadyConnectedException();
        
        if (spockInterface.getNumberOfNodes() != this.getNumberOfNodes() ||
               spockInterface.interfaceType() == this.interfaceType())
            throw new IncompatibleInterfacesException();
        
        connectedInterface = spockInterface;
        
        logger.log(Level.INFO,
                   "Network interface {0} connected to {1}",
                   new Object[] { getID(), spockInterface.getID() });

    }

    @Override
    public void disconnect() {
        connectedInterface = null;
    }

    @Override
    public void acceptSignal(NetworkSignal signal, Node sender) throws InterfaceNotConnectedException, InvalidSenderIndexException, InvalidSignalException {
        if (!isConnected())
            throw new InterfaceNotConnectedException();
        
        if (sender.getID() < 0 || sender.getID() >= numberOfNodes)
            throw new InvalidSenderIndexException();
        
        if (signal == null)
            throw new InvalidSignalException();
        
        // Develop an id mapping as it is needed
        if (!nodeMapping.containsKey(sender.getID())) {
            for (NetworkNode node : networkNodes) {
                if (!nodeMapping.containsValue(networkNodes.indexOf(node))) {
                    nodeMapping.put(sender.getID(), networkNodes.indexOf(node));
                    logger.log(Level.INFO,
                               "Network interface {0} assigned {1} to {2} ({3})",
                               new Object[] { getID(), sender.getID(), node.getID(), networkNodes.indexOf(node) });
                    break;
                }
            }
        }
        
        networkNodes.get(nodeMapping.get(sender.getID())).acceptSignal(signal, null);
    }

    public Boolean getInterfaceType() {
        return interfaceType;
    }

    public void setInterfaceType(Boolean interfaceType) {
        this.interfaceType = interfaceType;
    }

    public Network getNetwork() {
        return network;
    }

    public void setNetwork(Network network) {
        this.network = network;
    }

    public ArrayList<NetworkNode> getNetworkNodes() {
        return networkNodes;
    }

    public void setNetworkNodes(ArrayList<NetworkNode> networkNodes) {
        this.networkNodes = networkNodes;
    }

    @Override
    public SpockInterface getConnectedInterface() {
        return connectedInterface;
    }

    @Override
    public String getIDString() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
