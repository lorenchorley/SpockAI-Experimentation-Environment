package spock.network.behaviours;

import spock.common.signals.NetworkSignal;
import spock.network.core.NetworkNode;

/**
 * @author Loren Chorley
 */
public abstract class TransmissionContent extends NetworkBehaviour<TransmissionContent> {

    @Override
    public void replaceInNode(NetworkNode node, TransmissionContent behaviour) {
        node.transmissionContent = behaviour;
    }
    
    public abstract NetworkSignal selectContent();
    public abstract boolean signalsRemain();

}
