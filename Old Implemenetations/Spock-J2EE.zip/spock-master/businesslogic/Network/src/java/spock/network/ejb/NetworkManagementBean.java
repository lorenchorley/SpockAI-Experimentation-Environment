package spock.network.ejb;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import spock.common.exceptions.IncompatibleInterfacesException;
import spock.common.exceptions.InterfaceAlreadyConnectedException;
import spock.common.interfaces.SpockInterface;
import spock.network.core.Network;
import spock.network.core.NetworkInterface;
import spock.network.core.NetworkNode;
import spock.network.ejb.support.NetworkNodeTemplate;
import spock.network.core.exceptions.InvalidNetworkInterfaceException;
import spock.network.core.exceptions.InvalidNetworkNodeException;
import spock.network.core.exceptions.ConnectionAlreadyExistException;
import spock.network.core.exceptions.InvalidInterfaceNameException;
import spock.network.core.exceptions.InvalidNetworkInitialisationNameException;
import spock.network.core.exceptions.InvalidNodeNameException;
import spock.network.core.exceptions.InvalidNodeTemplateNameException;
import spock.network.core.exceptions.NoSuchNetworkException;
import spock.network.ejb.support.NetworkInitialisation;

/**
 *
 * @author Loren Chorley
 */
@Singleton
@Startup
public class NetworkManagementBean {
    private static final Logger logger = Logger.getLogger("spock.network.ejb.NetworkManagementBean");
    
    public Map<String, Network> networks;
    
    public NetworkManagementBean() {
        networks = new HashMap<String, Network>();
    }
    
    public void connectInterfaceToNetwork(SpockInterface spockInterface, String networkName) throws RemoteException, NoSuchNetworkException, InterfaceAlreadyConnectedException, IncompatibleInterfacesException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        if (!networks.containsKey(networkName))
            throw new NoSuchNetworkException();
        
        Network network = networks.get(networkName);
        
        // Check for existing interface, otherwise create new one
        SpockInterface localInterface = null;
        
        for (SpockInterface si : network.getInterfaces()) {
            if (!si.isConnected() && si.interfaceType() != spockInterface.interfaceType()) {
                localInterface = si;
                break;
            }
        }
        
        if (localInterface == null) {
            ArrayList<NetworkNode> newNodes = new ArrayList<NetworkNode>();
            for (int i=0;i<spockInterface.getNumberOfNodes();i++)
                newNodes.add(network.getDefaultNodeTemplate().newInstance(network));            
            localInterface = new NetworkInterface(newNodes, network, !spockInterface.interfaceType(), spockInterface.getNumberOfNodes());
        }
        
        // Connect the chosen interfaces
        localInterface.acceptConnection(spockInterface);
        spockInterface.acceptConnection(localInterface);
        
    }
    
    public void disconnectInterfaces(SpockInterface spockInterface) {
        if (spockInterface.isConnected() && spockInterface.getConnectedInterface().isConnected()) {
            
            logger.log(Level.INFO,
                       "Disconnecting interfaces {0} and {1}",
                       new Object[] { spockInterface.getID(), spockInterface.getConnectedInterface().getID() });
            
            spockInterface.getConnectedInterface().disconnect();
            spockInterface.disconnect();
            
        }
    }
    
    public Network InitialiseNetwork(NetworkInitialisation ni) throws RemoteException, ClassNotFoundException, InstantiationException, IllegalAccessException, InvalidNetworkNodeException, InvalidNetworkInterfaceException {
        if (ni == null || !ni.isValid())
            return null;
        
        Network network = new Network(ni.getName());
        HashMap<String, NetworkNode> nodes = new HashMap<String, NetworkNode>();
        
        String behaviourName;
        NetworkNode node;
        NetworkNodeTemplate template;
        Collection<String> receivingNodes;
        Collection<String> interfaceNodeNames;
        NetworkInterface networkInterface;
        Collection<NetworkNode> interfaceNodes;
        boolean interfaceType;
        
        logger.log(Level.INFO,
                       "Initialising network {0}",
                       new Object[] { network.getNetworkName() });
        
        // Add nodes to network
        for (String nodeName : ni.getNodes().keySet()) {
            behaviourName = ni.getNodes().get(nodeName);
            template = ni.getNodeTemplates().get(behaviourName);
            node = template.newInstance(network);
            network.addNode(node);
            
            // Record locally so that names are preserved and connections can be made appropriately
            nodes.put(nodeName, node);
            
            logger.log(Level.INFO,
                       "Added node {0}",
                       new Object[] { nodeName });
        
        }
        
        node = null;
        
        // Make connections between nodes
        for (String sendingNodeName : ni.getNodeConnections().keySet()) {
            receivingNodes = ni.getNodeConnections().get(sendingNodeName);
            for (String receivingNodeName : receivingNodes) {
                node = nodes.get(receivingNodeName);
                nodes.get(sendingNodeName).storageProcess.targetNodes.add(node);
                
                logger.log(Level.INFO,
                       "Connected node {0} to {1}",
                       new Object[] { sendingNodeName, receivingNodeName });
        
            }
        }
        
        node = null;
        
        // Add network interface
        for (String interfaceName : ni.getNetworkInterfaces().keySet()) {
            interfaceNodeNames = ni.getNetworkInterfaces().get(interfaceName);
            interfaceNodes = new ArrayList<NetworkNode>();
            for (String interfaceNodeName : interfaceNodeNames) {
                node = nodes.get(interfaceNodeName);
                interfaceNodes.add(node);
                
                logger.log(Level.INFO,
                       "Adding node {0} to interface {1}",
                       new Object[] { interfaceNodeName, interfaceName });
                
            }
            interfaceType = ni.getNetworkInterfaceTypes().get(interfaceName);
            networkInterface = new NetworkInterface((ArrayList<NetworkNode>) interfaceNodes, network, interfaceType, interfaceNodes.size());
            network.addInterface(networkInterface);
            
            logger.log(Level.INFO,
                       "Added interface {0}",
                       new Object[] { interfaceName });
        
            
        }
        
        networks.put(network.getNetworkName(), network);
        
        logger.log(Level.INFO,
                       "Successfully created network {0}",
                       new Object[] { network.getNetworkName() });
        
        return network;
        
    }
    
    @PostConstruct
    public void Setup() throws InvalidNetworkInitialisationNameException, 
                                InvalidNodeTemplateNameException, 
                                InvalidNodeNameException, 
                                InvalidInterfaceNameException, 
                                ConnectionAlreadyExistException, 
                                RemoteException, 
                                ClassNotFoundException, 
                                InstantiationException, 
                                IllegalAccessException, 
                                InvalidNetworkNodeException, 
                                InvalidNetworkInterfaceException, 
                                NoSuchNetworkException, 
                                InterfaceAlreadyConnectedException, 
                                IncompatibleInterfacesException {
        // Testing code
        
        logger.log(Level.INFO,
                       "Starting testing code",
                       new Object[] {  });
        
        
        NetworkInitialisation ni = new NetworkInitialisation();
        
        ni.setName("Test network 1");
        
        NetworkNodeTemplate template = new NetworkNodeTemplate("standard", 
                                                               "", 
                                                               "", 
                                                               "", 
                                                               "", 
                                                               "sets.test.TestFiringCondition", 
                                                               "sets.test.TestTargetSelection", 
                                                               "sets.test.TestEnergyEconomics", 
                                                               "sets.test.TestLifeCycle", 
                                                               "sets.test.TestDataProcessing", 
                                                               "sets.test.TestTransmissionContent");
        ni.addNodeTemplate(template);
        
        ni.addNode("node1", "standard");
        ni.addNode("node2", "standard");
        ni.addNode("node3", "standard");
        
        ni.addNodeConnection("node1", "node2", true);
        ni.addNodeConnection("node1", "node3", false);
        ni.addNodeConnection("node3", "node2", false);
        
        Collection<String> nodes;
        
        nodes = new ArrayList<String>();
        nodes.add("node1");
        nodes.add("node3");
        
        ni.addNetworkInterfaces("input", nodes, SpockInterface.INPUT_INTERFACE);
        
        nodes.remove("node1");
        nodes.add("node2");
        
        ni.addNetworkInterfaces("output", nodes, SpockInterface.OUTPUT_INTERFACE);
        
        Network network = this.InitialiseNetwork(ni);
        
        network.startActivity();
        
        
        
        ni = new NetworkInitialisation();
        
        ni.setName("Test network 2");
        
        ni.addNodeTemplate(template);
        
        ni.addNode("node1", "standard");
        ni.addNode("node2", "standard");
        ni.addNode("node3", "standard");
        
        ni.addNodeConnection("node1", "node2", true);
        ni.addNodeConnection("node1", "node3", false);
        ni.addNodeConnection("node3", "node2", false);
        
        nodes = new ArrayList<String>();
        nodes.add("node1");
        
        ni.addNetworkInterfaces("input", nodes, SpockInterface.INPUT_INTERFACE);
        
        nodes.remove("node1");
        nodes.add("node2");
        
        ni.addNetworkInterfaces("output", nodes, SpockInterface.OUTPUT_INTERFACE);
        
        network = this.InitialiseNetwork(ni);
        
        network.startActivity();
        
        this.connectInterfaceToNetwork(network.getInterfaces().get(0), "Test network 1");
        
    }
    
}
