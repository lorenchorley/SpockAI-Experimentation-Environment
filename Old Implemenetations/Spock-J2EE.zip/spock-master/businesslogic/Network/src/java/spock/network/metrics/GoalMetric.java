package spock.network.metrics;

/**
 * GoalMetric metric - a way of measuring how close you are to a desirable situation.
 * @author Loren Chorley
 */
public interface GoalMetric {
	
	
}
