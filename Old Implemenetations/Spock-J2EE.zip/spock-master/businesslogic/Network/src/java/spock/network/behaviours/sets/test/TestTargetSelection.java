package spock.network.behaviours.sets.test;

import spock.network.behaviours.TargetSelection;
import spock.network.core.NetworkNode;
import java.util.logging.Level;
import java.util.logging.Logger;
import spock.common.signals.NetworkSignal;

/**
 *
 * @author Loren Chorley
 */
public class TestTargetSelection extends TargetSelection {
    private static final Logger logger = Logger.getLogger("spock.network.behaviours.sets.test.TestTargetSelection");

    @Override
    public NetworkNode selectTarget(NetworkSignal signal) {
        NetworkNode n = null;
        String id = "none";
        
        if (parentNode.storageProcess.targetNodes.iterator().hasNext()) {
            n = parentNode.storageProcess.targetNodes.iterator().next();
            id = String.valueOf(n.getID());
        }
        
        logger.log(Level.INFO,
                   "TestTargetSelection.selectTarget: signal {0}, target {1}",
                   new Object[] { signal, id });
        
        return n;
    }

    @Override
    public TargetSelection replicate(TargetSelection parentBehaviour) {
        logger.log(Level.INFO,
                   "TestTargetSelection.replicate",
                   new Object[] {  });
        return new TestTargetSelection();
    }

    @Override
    public void activityProcess() {
        logger.log(Level.INFO,
                   "TestTargetSelection.activityProcess",
                   new Object[] {  });
        stopActivity();
    }
    
}
