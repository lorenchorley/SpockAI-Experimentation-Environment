package spock.network.ejb;

import java.rmi.RemoteException;
import java.util.Collection;
import javax.ejb.Remote;
import spock.network.core.exceptions.InvalidNetworkException;
import spock.network.core.exceptions.InvalidNetworkInitialisationException;
import spock.network.core.exceptions.InvalidNetworkInterfaceException;
import spock.network.core.exceptions.InvalidNetworkNodeException;
import spock.network.ejb.support.NetworkDetails;
import spock.network.ejb.support.NetworkInitialisationInterface;

/**
 * 
 * 
 * @author Loren Chorley
 */
@Remote
public interface NetworkRequest {
    public String returnTestString();
    public void initialiseNewNetwork(NetworkInitialisationInterface initialisation) throws RemoteException, ClassNotFoundException, InstantiationException, IllegalAccessException, InvalidNetworkNodeException, InvalidNetworkInterfaceException, InvalidNetworkInitialisationException;
    public void startNetwork(String name) throws InvalidNetworkException;
    public void pauseNetwork(String name) throws InvalidNetworkException;
    public void resumeNetwork(String name) throws InvalidNetworkException;
    public void stopNetwork(String name) throws InvalidNetworkException;
    public NetworkDetails getNetworkDetails(String name) throws InvalidNetworkException;
    public Collection<String> listNetworks();
}
