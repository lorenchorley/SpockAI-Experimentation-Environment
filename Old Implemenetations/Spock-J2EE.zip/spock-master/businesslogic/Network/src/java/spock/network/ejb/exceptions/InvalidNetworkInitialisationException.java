package spock.network.ejb.exceptions;

/**
 *
 * @author Loren Chorley
 */
public class InvalidNetworkInitialisationException extends Exception {
    
    
    
}
