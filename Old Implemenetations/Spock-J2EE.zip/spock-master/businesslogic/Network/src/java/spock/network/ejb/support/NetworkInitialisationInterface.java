package spock.network.ejb.support;

/**
 *
 * @author Loren Chorley
 */
public interface NetworkInitialisationInterface {

    /**
     * Get the value of name
     *
     * @return The value of name
     */
    public String getName();

    /**
     *
     * @return
     */
    public boolean isValid();
    
}
