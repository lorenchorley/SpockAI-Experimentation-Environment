package spock.network.core;

import java.io.Serializable;

/**
 * An instance contains a list of instructions that are necessary and sufficient
 * for initialising a network simulation. It is serialisable so that instances 
 * may be constructed and sent across a network.
 * 
 * @author Loren Chorley
 */
public class NetworkInitialisation implements Serializable {
    
    // initial node creation and their behaviours
         // define necessary node templates
         // define how many to make
         // define initial connections
    // initial network interfaces
    // network observables?
    
}
