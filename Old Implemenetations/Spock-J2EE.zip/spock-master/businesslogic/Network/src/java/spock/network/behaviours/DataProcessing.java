package spock.network.behaviours;

import spock.common.signals.NetworkSignal;
import spock.network.core.NetworkNode;

/**
 * @author Loren Chorley
 */
public abstract class DataProcessing extends NetworkBehaviour<DataProcessing> {

    @Override
    public void replaceInNode(NetworkNode node, DataProcessing behaviour) {
        node.dataProcessing = behaviour;
    }
    
    public abstract NetworkSignal processData(NetworkSignal data); // Make sure that it's a different object that gets returned

}
