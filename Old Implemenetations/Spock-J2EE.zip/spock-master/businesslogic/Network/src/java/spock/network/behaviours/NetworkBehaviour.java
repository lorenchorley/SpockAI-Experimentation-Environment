package spock.network.behaviours;

import java.util.logging.Level;
import java.util.logging.Logger;
import spock.common.interfaces.SpockRunnable;
import spock.network.core.NetworkNode;

/*
 * 
 */
public abstract class NetworkBehaviour<T> implements Runnable, SpockRunnable { //Ideally T is a class of type NetworkBehaviour
    
    private boolean threadEnabled = false;
    private boolean threadWantsToStart = false; // Remembers if an attempt to start the thread was made
    protected boolean isPaused = false;
    protected boolean isStopped = false;
    protected boolean hasStopped = false;
    private Thread thread;
    protected NetworkNode parentNode;
    //TODO synchronise on a variable for pausing, not on the class as this can also be used for other purposes
    
    /*
     * Starts the thread or lets it start later when it becomes enabled
     */
    @Override
    public void startActivity() {
        if (threadEnabled) {
            thread = new Thread(this);
            thread.start();
        } else {
            threadWantsToStart = true;
        }
    }

    /*
     * 
     */
    public void setThreadEnabled(boolean threadEnabled) {
        this.threadEnabled = threadEnabled;
        if (threadEnabled && threadWantsToStart) {
            thread = new Thread(this);
            thread.start();
        }
    }

    /*
     * 
     */
    public boolean isThreadEnabled() {
        return threadEnabled;
    }
    
    // Maybe not needed
    /*
     * 
     */
    public boolean hasThreadStarted() {
        return (thread != null) ? true : false;
    }
    
    /*
     * 
     */
    public void setParentNode(NetworkNode parentNode) { 
        this.parentNode = parentNode;
    }

    /**
     * Allows for concurrent replication of this behaviour
     */
    private class replicatorThread extends Thread {
            
        @SuppressWarnings("unused") 
        T behaviour;
        NetworkNode node;
        
        public replicatorThread(T behaviour, NetworkNode node) { 
            this.behaviour = behaviour;
            this.node = node;
        }

        @Override 
        public void run() { 
            replaceInNode(node, replicate(behaviour));
        }
        
    }
    
    /*
     * Start the node replication process
     */
    public void replicateFunction(T behaviour, NetworkNode node) {
        (new replicatorThread(behaviour, node)).start(); 
    }
    
    /*
     * Ideally find a way to do away with this function
     * Perhaps with a Class function
     * At the moment this must be implemented and reimplemented by every single class that extends NetworkBehaviour
     */
    public abstract T replicate(T parentBehaviour);
    
    /*
     * Node replicaton callback function.
     */
    public abstract void replaceInNode(NetworkNode node, T behaviour);
    
    @Override
    public void run() {
        
        while (!isStopped) {
        
            synchronized (this) {
                while (isPaused) {
                    try {
                        //Figure out how to pause reliably
                        wait();
                    } catch (InterruptedException ex) {
                        Logger.getLogger(NetworkBehaviour.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
                
            activityProcess();
        
        }
        
        hasStopped = true;
    }
    
    /**
     * Repeated while not paused or stopped
     */
    public abstract void activityProcess();

    @Override
    public void pauseActivity() {
        synchronized (this) {
            isPaused = true;
        }
    }

    @Override
    public void resumeActivity() {
        synchronized (this) {
            isPaused = false;
            notifyAll();
        }
    }
    
    @Override
    public void stopActivity() {
        isStopped = true;
    }
    
    @Override
    public boolean hasStopped() {
        return hasStopped;
    }
    
}
