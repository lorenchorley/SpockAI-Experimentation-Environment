package spock.network.ejb.exceptions;

/**
 *
 * @author Loren Chorley
 */
public class InvalidNetworkException extends Exception {
    
}
