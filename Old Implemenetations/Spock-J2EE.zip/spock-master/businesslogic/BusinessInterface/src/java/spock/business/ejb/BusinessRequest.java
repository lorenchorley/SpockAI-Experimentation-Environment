package spock.business.ejb;

import javax.ejb.Remote;

/**
 *
 * @author Loren Chorley
 */
@Remote
public interface BusinessRequest {
    public String returnTestString();
}
