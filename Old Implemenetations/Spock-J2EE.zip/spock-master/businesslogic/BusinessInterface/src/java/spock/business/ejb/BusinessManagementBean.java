package spock.business.ejb;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import spock.network.ejb.NetworkRequest;

/**
 *
 * @author Loren Chorley
 */
@Singleton
@Startup
public class BusinessManagementBean {
    private static final Logger logger = Logger.getLogger("spock.business.ejb.BusinessManagementBean");
    
    //@EJB
    //private EnvironmentRequest er;
    
    @EJB
    private NetworkRequest nr;
    
    public BusinessManagementBean() {
        
    }
    
    @PostConstruct
    public void Setup() {
        // Testing code
        
        logger.log(Level.INFO,
                   "First network: {0}",
                   new Object[] { nr.listNetworks().iterator().next() });
            
        
    }
    
}
