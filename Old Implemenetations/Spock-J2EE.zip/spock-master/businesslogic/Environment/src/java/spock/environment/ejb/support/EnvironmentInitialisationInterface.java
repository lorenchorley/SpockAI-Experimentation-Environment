package spock.environment.ejb.support;

/**
 *
 * @author Loren Chorley
 */
public interface EnvironmentInitialisationInterface {

    /**
     * Get the value of name
     *
     * @return The value of name
     */
    public String getName();

    /**
     *
     * @return
     */
    public boolean isValid();
    
}
