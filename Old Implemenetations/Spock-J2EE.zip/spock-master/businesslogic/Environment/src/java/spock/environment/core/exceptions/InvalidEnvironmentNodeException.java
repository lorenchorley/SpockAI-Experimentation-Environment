package spock.environment.core.exceptions;

/**
 *
 * @author Loren Chorley
 */
public class InvalidEnvironmentNodeException extends Exception {

}
