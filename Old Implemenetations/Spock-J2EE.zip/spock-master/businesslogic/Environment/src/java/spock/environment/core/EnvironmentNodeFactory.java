package spock.environment.core;

/**
 *
 * @author Loren Chorley
 */
public class EnvironmentNodeFactory {

    private long nextID;
    
    public EnvironmentNodeFactory(long baseID) {
        nextID = baseID;
    }
    
    public synchronized EnvironmentNode newInstance() {
        return new EnvironmentNode(nextID++);
    }
    
}
