package spock.environment.ejb;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import spock.common.exceptions.IncompatibleInterfacesException;
import spock.common.exceptions.InterfaceAlreadyConnectedException;
import spock.common.interfaces.SpockInterface;
import spock.environment.core.Environment;
import spock.environment.core.EnvironmentInterface;
import spock.environment.core.EnvironmentLoader;
import spock.environment.core.EnvironmentNode;
import spock.environment.core.EnvironmentNodeFactory;
import spock.environment.core.exceptions.InvalidEnvironmentInitialisationNameException;
import spock.environment.core.exceptions.InvalidEnvironmentInterfaceException;
import spock.environment.core.exceptions.InvalidInterfaceNameException;
import spock.environment.core.exceptions.InvalidNodeNameException;
import spock.environment.core.exceptions.NoSuchEnvironmentException;
import spock.environment.ejb.support.EnvironmentInitialisation;

/**
 *
 * @author Loren Chorley
 */
@Singleton
@Startup
public class EnvironmentManagementBean {
    private static final Logger logger = Logger.getLogger("spock.environment.ejb.EnvironmentManagementBean");
    
    public Map<String, Environment> environments;
    
    public EnvironmentManagementBean() {
        environments = new HashMap<String, Environment>();
    }
    
    public void connectInterfaceToEnvironment(SpockInterface spockInterface, String environmentName) throws RemoteException, NoSuchEnvironmentException, InterfaceAlreadyConnectedException, IncompatibleInterfacesException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        if (!environments.containsKey(environmentName))
            throw new NoSuchEnvironmentException(environmentName);
        
        Environment environment = environments.get(environmentName);
        EnvironmentNodeFactory factory = environment.getNodeFactory();
        
        // Check for existing interface, otherwise create new one
        SpockInterface localInterface = null;
        
        for (SpockInterface si : environment.getInterfaces()) {
            if (!si.isConnected() && si.interfaceType() != spockInterface.interfaceType()) {
                localInterface = si;
                break;
            }
        }
        
        if (localInterface == null) {
            ArrayList<EnvironmentNode> newNodes = new ArrayList<EnvironmentNode>();
            for (int i=0;i<spockInterface.getNumberOfNodes();i++)
                newNodes.add(factory.newInstance());
            localInterface = new EnvironmentInterface(newNodes, environment, !spockInterface.interfaceType(), spockInterface.getNumberOfNodes());
        }
        
        // Connect the chosen interfaces
        localInterface.acceptConnection(spockInterface);
        spockInterface.acceptConnection(localInterface);
        
    }
    
    public void disconnectInterfaces(SpockInterface spockInterface) {
        if (spockInterface.isConnected() && spockInterface.getConnectedInterface().isConnected()) {
            
            logger.log(Level.INFO,
                       "Disconnecting interfaces {0} and {1}",
                       new Object[] { spockInterface.getIDString(), spockInterface.getConnectedInterface().getIDString() });
            
            spockInterface.getConnectedInterface().disconnect();
            spockInterface.disconnect();
            
        }
    }
    
    public Environment InitialiseEnvironment(EnvironmentInitialisation ei) throws RemoteException, ClassNotFoundException, InstantiationException, IllegalAccessException, InvalidEnvironmentInterfaceException {
        if (ei == null || !ei.isValid())
            return null;
        
        EnvironmentLoader loader = new EnvironmentLoader(ei.getSubPath());
        Environment environment = loader.newInstance();
        HashMap<String, EnvironmentNode> nodes = new HashMap<String, EnvironmentNode>();
        
        EnvironmentNode node;
        Integer interfaceSize;
        EnvironmentInterface environmentInterface;
        Collection<EnvironmentNode> interfaceNodes;
        boolean interfaceType;
        EnvironmentNodeFactory factory = environment.getNodeFactory();
        
        environment.setEnvironmentName(ei.getName());
        
        logger.log(Level.INFO,
                       "Initialising environment {0}",
                       new Object[] { environment.getEnvironmentName() });
        
        // Add environment interfaces
        for (String interfaceName : ei.getEnvironmentInterfaces().keySet()) {
            interfaceSize = ei.getEnvironmentInterfaces().get(interfaceName);
            interfaceNodes = new ArrayList<EnvironmentNode>();
            
            for (int i=0;i<interfaceSize;i++) {
                node = factory.newInstance();
                interfaceNodes.add(node);
                //nodes.put(node.getID(), node);
                
                logger.log(Level.INFO,
                       "Adding node {0} to interface {1}",
                       new Object[] { node.getID(), interfaceName });
                
            }
            
            interfaceType = ei.getEnvironmentInterfaceTypes().get(interfaceName);
            environmentInterface = new EnvironmentInterface((ArrayList<EnvironmentNode>) interfaceNodes, environment, interfaceType, interfaceNodes.size());
            environmentInterface.setIDString(interfaceName);
            environment.addInterface(environmentInterface);
            
            logger.log(Level.INFO,
                       "Added interface {0}",
                       new Object[] { interfaceName });
        
            
        }
        
        // Add nodes to environment object
        
        environments.put(environment.getEnvironmentName(), environment);
        
        logger.log(Level.INFO,
                       "Successfully created environment {0}",
                       new Object[] { environment.getEnvironmentName() });
        
        return environment;
        
    }
    
    @PostConstruct
    public void Setup() throws InvalidEnvironmentInitialisationNameException, InvalidInterfaceNameException, InvalidNodeNameException, RemoteException, ClassNotFoundException, InstantiationException, IllegalAccessException, InvalidEnvironmentInterfaceException, NoSuchEnvironmentException, InterfaceAlreadyConnectedException, IncompatibleInterfacesException {
        // Testing code
        
        logger.log(Level.INFO,
                       "Starting testing code",
                       new Object[] {  });
        
        
        EnvironmentInitialisation ei = new EnvironmentInitialisation();
        
        ei.setName("Testing environment 1");
        
        ei.setSubPath("TestEnvironment");
        
        ei.addEnvironmentInterfaces("Int1_Input", 3, SpockInterface.INPUT_INTERFACE);
        ei.addEnvironmentInterfaces("Int2_Output", 2, SpockInterface.OUTPUT_INTERFACE);
        ei.addEnvironmentInterfaces("Int3_Output", 3, SpockInterface.OUTPUT_INTERFACE);
        ei.addEnvironmentInterfaces("Int4_Input", 2, SpockInterface.INPUT_INTERFACE);
        
        Environment e = this.InitialiseEnvironment(ei);
        
        
        
        EnvironmentInterface eint = e.getInterfaces().get(0);
        
        this.connectInterfaceToEnvironment(eint, "Testing environment 1");
        
        
    }
    
}
