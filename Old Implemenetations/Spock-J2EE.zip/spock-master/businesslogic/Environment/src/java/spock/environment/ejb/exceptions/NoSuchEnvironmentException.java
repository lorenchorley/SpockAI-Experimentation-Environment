package spock.environment.ejb.exceptions;

/**
 *
 * @author Loren Chorley
 */
public class NoSuchEnvironmentException extends Exception {

}
