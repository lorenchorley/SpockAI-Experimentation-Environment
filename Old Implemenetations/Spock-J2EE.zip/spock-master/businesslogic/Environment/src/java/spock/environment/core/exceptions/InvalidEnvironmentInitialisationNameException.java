package spock.environment.core.exceptions;

/**
 *
 * @author Loren Chorley
 */
public class InvalidEnvironmentInitialisationNameException extends Exception {
    
}
