package spock.environment.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import spock.common.exceptions.IncompatibleInterfacesException;
import spock.common.exceptions.InterfaceAlreadyConnectedException;
import spock.common.exceptions.InterfaceNotConnectedException;
import spock.common.exceptions.InvalidSenderIndexException;
import spock.common.exceptions.InvalidSignalException;
import spock.common.interfaces.Node;
import spock.common.interfaces.SpockInterface;
import spock.common.signals.NetworkSignal;

public class EnvironmentInterface implements SpockInterface {
    private static final Logger logger = Logger.getLogger("spock.environment.core.EnvironmentInterface");
    
    private ArrayList<EnvironmentNode> environmentNodes;
    private Environment environment;
    private Boolean interfaceType;
    private int numberOfNodes;
    private SpockInterface connectedInterface;
    private Map<Long, Integer> nodeMapping;
    private long id;
    private String idString = "";

    public EnvironmentInterface() {
        environmentNodes = new ArrayList<EnvironmentNode>();
        nodeMapping = new HashMap<Long, Integer>();
    }

    public EnvironmentInterface(ArrayList<EnvironmentNode> environmentNodes, Environment environment, boolean interfaceType, int numberOfNodes) {
        this.environmentNodes = environmentNodes;
        this.environment = environment;
        this.interfaceType = interfaceType;
        this.numberOfNodes = numberOfNodes;
    }

    @Override
    public long getID() {
        return id;
    }

    public void setID(long id) {
        this.id = id;
    }

    @Override
    public String getIDString() {
        return idString;
    }

    public void setIDString(String idString) {
        this.idString = idString;
    }

    public Map<Long, Integer> getNodeMapping() {
        return nodeMapping;
    }

    @Override
    public boolean interfaceType() {
        return interfaceType;
    }

    @Override
    public boolean isConnected() {
        return connectedInterface != null;
    }

    @Override
    public int getNumberOfNodes() {
        return numberOfNodes;
    }

    @Override
    public void acceptConnection(SpockInterface spockInterface) throws InterfaceAlreadyConnectedException, IncompatibleInterfacesException {
        if (isConnected())
            throw new InterfaceAlreadyConnectedException();
        
        if (spockInterface.getNumberOfNodes() != this.getNumberOfNodes() ||
               spockInterface.interfaceType() == this.interfaceType())
            throw new IncompatibleInterfacesException();
        
        connectedInterface = spockInterface;
        
        logger.log(Level.INFO,
                   "Environment interface {0} connected to {1}",
                   new Object[] { getIDString(), spockInterface.getIDString() });

    }

    @Override
    public void disconnect() {
        connectedInterface = null;
    }

    @Override
    public void acceptSignal(NetworkSignal signal, Node sender) throws InterfaceNotConnectedException, InvalidSenderIndexException, InvalidSignalException {
        if (!isConnected())
            throw new InterfaceNotConnectedException();
        
        if (sender.getID() < 0 || sender.getID() >= numberOfNodes)
            throw new InvalidSenderIndexException();
        
        if (signal == null)
            throw new InvalidSignalException();
        
        // Develop an id mapping as it is needed
        if (!nodeMapping.containsKey(sender.getID())) {
            for (EnvironmentNode node : environmentNodes) {
                if (!nodeMapping.containsValue(environmentNodes.indexOf(node))) {
                    nodeMapping.put(sender.getID(), environmentNodes.indexOf(node));
                    logger.log(Level.INFO,
                               "Environment interface {0} assigned {1} to {2} ({3})",
                               new Object[] { getID(), sender.getID(), node.getID(), environmentNodes.indexOf(node) });
                    break;
                }
            }
        }
        
        environmentNodes.get(nodeMapping.get(sender.getID())).acceptSignal(signal, null);
    }

    public Boolean getInterfaceType() {
        return interfaceType;
    }

    public void setInterfaceType(Boolean interfaceType) {
        this.interfaceType = interfaceType;
    }

    public Environment getEnvironment() {
        return environment;
    }

    public void setEnvironment(Environment environment) {
        this.environment = environment;
    }

    public ArrayList<EnvironmentNode> getEnvironmentNodes() {
        return environmentNodes;
    }

    public void setEnvironmentNodes(ArrayList<EnvironmentNode> environmentNodes) {
        this.environmentNodes = environmentNodes;
    }

    @Override
    public SpockInterface getConnectedInterface() {
        return connectedInterface;
    }

}
