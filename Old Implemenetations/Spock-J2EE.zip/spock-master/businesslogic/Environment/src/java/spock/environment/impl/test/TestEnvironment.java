package spock.environment.impl.test;

import java.util.logging.Level;
import java.util.logging.Logger;
import spock.environment.core.Environment;

/**
 *
 * @author Loren Chorley
 */
public class TestEnvironment extends Environment {
    private static final Logger logger = Logger.getLogger("spock.environment.impl.TestEnvironment");

    public TestEnvironment() {
        
        logger.log(Level.INFO,
                   "Started TestEnvironment!",
                   new Object[] {  });
        
    }
    
}
