package spock.environment.core;

import spock.common.exceptions.InterfaceNotConnectedException;
import spock.common.exceptions.InvalidSenderIndexException;
import spock.common.exceptions.InvalidSignalException;
import spock.common.interfaces.Node;
import spock.common.interfaces.SpockRunnable;
import spock.common.signals.NetworkSignal;

/**
 *
 * @author Loren Chorley
 */
public class EnvironmentNode implements Node, SpockRunnable {

    private long id;
    
    public EnvironmentNode(long id) {
        this.id = id;
    }

    @Override
    public long getID() {
        return id;
    }
    
    @Override
    public void acceptSignal(NetworkSignal signal, Node sender) throws InterfaceNotConnectedException, InvalidSenderIndexException, InvalidSignalException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void startActivity() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void stopActivity() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean hasStopped() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void pauseActivity() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void resumeActivity() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
}
