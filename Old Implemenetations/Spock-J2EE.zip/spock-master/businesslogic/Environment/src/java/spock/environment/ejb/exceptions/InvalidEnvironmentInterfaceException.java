package spock.environment.ejb.exceptions;

/**
 *
 * @author Loren Chorley
 */
public class InvalidEnvironmentInterfaceException extends Exception {

}
