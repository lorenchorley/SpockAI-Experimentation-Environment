package spock.environment.core;

import spock.environment.core.exceptions.InvalidEnvironmentInterfaceException;
import spock.environment.core.exceptions.InvalidEnvironmentNodeException;
import spock.common.interfaces.SpockObservable;
import spock.common.interfaces.SpockObservableLong;
import spock.common.interfaces.SpockRunnable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import spock.environment.ejb.support.EnvironmentDetails;
import tools.errorChecking.Log;

/**
 * Represents one environment simulation. Manages nodes and environment observables
 * as well as giving access to pause and resume functionality and calculating
 * the average number of environment node activations per second.
 * 
 * @author Loren Chorley
 */
public class Environment extends Thread implements SpockRunnable {
    private static final Logger logger = Logger.getLogger("spock.environment.core.Environment");
    
    private boolean isPaused = false;
    private boolean isStopped = false;
    private String name = null;
    
    private ArrayList<EnvironmentNode> nodes;
    // Add property methods with validation
    private ArrayList<EnvironmentInterface> interfaces;
    private HashMap<String, SpockObservable> observables;
    
    private EnvironmentNodeFactory factory;

    public Environment() {

        // Initialise primary environment objects
        nodes = new ArrayList<EnvironmentNode>();
        interfaces = new ArrayList<EnvironmentInterface>();
        observables = new HashMap<String, SpockObservable>();

        factory = new EnvironmentNodeFactory(0);
        
        // Initialise interface variables
        setEnvironmentObservable(new SpockObservableLong("Number of nodes", 0L));
        setEnvironmentObservable(new SpockObservableLong("Node activations this second", 0L));
        setEnvironmentObservable(new SpockObservableLong("Average activations per second", 0L));

        observables.get("Average activations per second").setLogging(true);
        observables.get("Number of nodes").setLogging(true);
        
    }

    public EnvironmentNodeFactory getNodeFactory() {
        return factory;
    }

    public String getEnvironmentName() {
        return name;
    }

    public void setEnvironmentName(String name) {
        if (this.name == null)
            this.name = name;
    }
    
    public ArrayList<EnvironmentInterface> getInterfaces() {
        return interfaces;
    }

    public ArrayList<EnvironmentNode> getNodes() {
        return nodes;
    }

    public HashMap<String, SpockObservable> getObservables() {
        return observables;
    }
    
    public void addNode(EnvironmentNode node) throws InvalidEnvironmentNodeException {
        if (node == null)
            throw new InvalidEnvironmentNodeException();
        
        nodes.add(node);
    }
    
    public void addInterface(EnvironmentInterface environmentinterface) throws InvalidEnvironmentInterfaceException {
        if (environmentinterface == null)
            throw new InvalidEnvironmentInterfaceException();
        
        interfaces.add(environmentinterface);
    }
    
    public final void setEnvironmentObservable(SpockObservable environmentObservable) {
        observables.put(environmentObservable.getName(), environmentObservable);
    }
    
    @Override
    public void run() {
        assert(environmentSize() > 0) : "Starting environment of positive size";

        Log.writeForThreadCreation("Environment");
        assert(this.isAlive()) : "Environment thread started";

        for (EnvironmentNode n : nodes)
            n.startActivity();

        ((SpockObservableLong) observables.get("Number of nodes")).setValue(environmentSize());

        long average_sum = 0;
        long seconds_passed = 0;
        
        // Calculate the average node activations per second
        while (!isStopped) {
            
            if (isPaused) {
                // TODO figure out how to block here
            }
            
            try {
                sleep(1000);
            } catch (InterruptedException ex) {
                logger.log(Level.INFO,
                           "Environment thread interrupted while sleeping, yawn...",
                           new Object[] {  });
            }
            
            if (seconds_passed >= 5) {
                ((SpockObservableLong) observables.get("Average activations per second")).setValue(average_sum / 5);
                average_sum = 0;
                seconds_passed = 0;
            } else {
                average_sum += ((SpockObservableLong) observables.get("Node activations this second")).getValue();
                seconds_passed++;
            }
            
        }
        
    }

    public long environmentSize() {
        return nodes.size();
    }

    public long getUniqueNodeID() {
        return 0;
    }
    
    @Override
    public void startActivity() {
        start();
    }
    
    @Override
    public void pauseActivity() {
        isPaused = true;
    }

    @Override
    public void resumeActivity() {
        isPaused = false;
    }
    
    @Override
    public void stopActivity() {
        isStopped = true;
    }

    @Override
    public boolean hasStopped() {
        return isStopped;
    }
    
    public EnvironmentDetails getEnvironmentDetails() {
        //return new EnvironmentDetails(isPaused, isStopped, observables);
        return null;
    }
    
}
