package spock.environment.ejb.support;

import spock.environment.core.exceptions.InvalidEnvironmentInitialisationNameException;
import spock.environment.core.exceptions.InvalidNodeNameException;
import spock.environment.core.exceptions.InvalidInterfaceNameException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * An instance contains a list of instructions that are necessary and sufficient
 * for initialising a environment simulation. It is serialisable so that instances 
 * may be constructed and sent across a environment.
 * 
 * In a EnvironmentInitialisation object, you may record a name or ID, a set of 
 * EnvironmentNode behaviours or templates, a list of nodes to create according
 * to the templates, a list of diectional connections between nodes, and a
 * list of EnvironmentInterfaces, their connections and a type.
 * 
 * @author Loren Chorley
 */
public class EnvironmentInitialisation implements Serializable, EnvironmentInitialisationInterface {
    
    protected String name = "default_environment_name";  
    protected Map<String, Integer> environmentInterfaces;
    protected Map<String, Boolean> environmentInterfaceTypes;
    protected String subPath;

    public EnvironmentInitialisation() {
        environmentInterfaces = new HashMap<String, Integer>();
        environmentInterfaceTypes = new HashMap<String, Boolean>();
    }
    
    /**
     * 
     * @return 
     */
    @Override
    public boolean isValid() {
        
        return true;
    }
    
    /**
     * Get the value of name
     *
     * @return The value of name
     */
    @Override
    public String getName() {
        return name;
    }

    /**
     * 
     * Set the value of name
     *
     * @param name The new value of name
     * @throws InvalidEnvironmentInitialisationNameException If the name is null or empty
     */
    public void setName(String name) throws InvalidEnvironmentInitialisationNameException {
        if (name == null || name.isEmpty()) {
            throw new InvalidEnvironmentInitialisationNameException();
        }
                
        this.name = name;
    }
    
    /**
     * Get the value of subPath
     *
     * @return the value of subPath
     */
    public String getSubPath() {
        return subPath;
    }

    /**
     * Set the value of subPath
     *
     * @param subPath new value of subPath
     */
    public void setSubPath(String subPath) {
        this.subPath = subPath;
    }

    /**
     * Get the environment interfaces
     *
     * @return The environment interfaces
     */
    public Map<String, Integer> getEnvironmentInterfaces() {
        return environmentInterfaces;
    }

    /**
     * Get the environment interface types
     *
     * @return The environment interface types
     */
    public Map<String, Boolean> getEnvironmentInterfaceTypes() {
        return environmentInterfaceTypes;
    }
    
    /**
     * Add a environment interface
     *
     * @param interfaceName The name of the interface
     * @param interfaceNodes A collection of node names that the interface connects to
     * @param type The type of environment interface: INPUT_INTERFACE or OUTPUT_INTERFACE
     * @throws InvalidInterfaceNameException If the interface already exists
     * @throws InvalidNodeNameException If a node name does not already exist
     */
    public void addEnvironmentInterfaces(String interfaceName, int numberOfNodes, boolean type) throws InvalidInterfaceNameException, InvalidNodeNameException {
        if (environmentInterfaces.containsKey(interfaceName)) {
            throw new InvalidInterfaceNameException();
        }
        
        if (numberOfNodes <= 0) {
            // exception
        }
        
        environmentInterfaces.put(interfaceName, numberOfNodes);
        environmentInterfaceTypes.put(interfaceName, type);
        
    }

}
