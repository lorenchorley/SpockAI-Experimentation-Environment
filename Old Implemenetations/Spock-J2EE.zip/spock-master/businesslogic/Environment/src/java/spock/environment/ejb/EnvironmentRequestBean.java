package spock.environment.ejb;

import java.rmi.RemoteException;
import java.util.Collection;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import spock.environment.core.exceptions.InvalidEnvironmentException;
import spock.environment.core.exceptions.InvalidEnvironmentInitialisationException;
import spock.environment.core.exceptions.InvalidEnvironmentInterfaceException;
import spock.environment.core.exceptions.InvalidEnvironmentNodeException;
import spock.environment.ejb.support.EnvironmentDetails;
import spock.environment.ejb.support.EnvironmentInitialisation;
import spock.environment.ejb.support.EnvironmentInitialisationInterface;
/**
 *
 * @author Loren Chorley
 */
@Stateless
public class EnvironmentRequestBean implements EnvironmentRequest {
    
    @EJB
    public EnvironmentManagementBean mgmt; 
    
    @Override
    public String returnTestString() {
        return "Spock Environment test string.";
    }

    @Override
    public void initialiseNewEnvironment(EnvironmentInitialisationInterface initialisation) throws RemoteException, ClassNotFoundException, InstantiationException, IllegalAccessException, InvalidEnvironmentNodeException, InvalidEnvironmentInterfaceException, InvalidEnvironmentInitialisationException {
        if (!(initialisation instanceof EnvironmentInitialisation))
            throw new InvalidEnvironmentInitialisationException();
        
        mgmt.InitialiseEnvironment((EnvironmentInitialisation) initialisation);

    }

    @Override
    public void startEnvironment(String name) throws InvalidEnvironmentException {
        if (!mgmt.environments.containsKey(name))
            throw new InvalidEnvironmentException();
            
        mgmt.environments.get(name).startActivity();
    }

    @Override
    public void pauseEnvironment(String name) throws InvalidEnvironmentException {
        if (!mgmt.environments.containsKey(name))
            throw new InvalidEnvironmentException();
            
        mgmt.environments.get(name).pauseActivity();
    }

    @Override
    public void resumeEnvironment(String name) throws InvalidEnvironmentException {
        if (!mgmt.environments.containsKey(name))
            throw new InvalidEnvironmentException();
            
        mgmt.environments.get(name).resumeActivity();
    }

    @Override
    public void stopEnvironment(String name) throws InvalidEnvironmentException {
        if (!mgmt.environments.containsKey(name))
            throw new InvalidEnvironmentException();
            
        mgmt.environments.get(name).stopActivity();
    }

    @Override
    public EnvironmentDetails getEnvironmentDetails(String name) throws InvalidEnvironmentException {
        if (!mgmt.environments.containsKey(name))
            throw new InvalidEnvironmentException();
            
        return mgmt.environments.get(name).getEnvironmentDetails();
    }

    @Override
    public Collection<String> listEnvironments() {
        return mgmt.environments.keySet();
    }
    
}
