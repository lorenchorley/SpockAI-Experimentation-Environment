package spock.environment.core.exceptions;

/**
 *
 * @author Loren Chorley
 */
public class NoSuchEnvironmentException extends Exception {

    protected String path;

    public String getPath() {
        return path;
    }

    public NoSuchEnvironmentException(String path) {
        this.path = path;
    }

}
