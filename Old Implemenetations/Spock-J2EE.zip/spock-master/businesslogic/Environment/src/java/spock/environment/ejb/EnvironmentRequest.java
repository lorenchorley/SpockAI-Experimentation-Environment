package spock.environment.ejb;

import java.rmi.RemoteException;
import java.util.Collection;
import javax.ejb.Remote;
import spock.environment.core.exceptions.*;
import spock.environment.ejb.support.EnvironmentDetails;
import spock.environment.ejb.support.EnvironmentInitialisationInterface;

/**
 * 
 * 
 * @author Loren Chorley
 */
@Remote
public interface EnvironmentRequest {
    public String returnTestString();
    public void initialiseNewEnvironment(EnvironmentInitialisationInterface initialisation) throws RemoteException, ClassNotFoundException, InstantiationException, IllegalAccessException, InvalidEnvironmentNodeException, InvalidEnvironmentInterfaceException, InvalidEnvironmentInitialisationException;
    public void startEnvironment(String name) throws InvalidEnvironmentException;
    public void pauseEnvironment(String name) throws InvalidEnvironmentException;
    public void resumeEnvironment(String name) throws InvalidEnvironmentException;
    public void stopEnvironment(String name) throws InvalidEnvironmentException;
    public EnvironmentDetails getEnvironmentDetails(String name) throws InvalidEnvironmentException;
    public Collection<String> listEnvironments();
}
