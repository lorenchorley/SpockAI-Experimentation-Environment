package spock.environment.core;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Loren Chorley
 */
public class EnvironmentLoader {
    private static final Logger logger = Logger.getLogger("spock.environment.core.EnvironmentLoader");

    protected String subpath;

    public EnvironmentLoader(String subpath) {
        if (subpath != null)
            subpath = "";
        
        this.subpath = subpath;
    }

    /**
     * Get the value of subpath
     *
     * @return the value of subpath
     */
    public String getSubpath() {
        if (subpath == null || "".equals(subpath))
            return "spock.environment.core.Environment";
        
        return "spock.environment.impl." + subpath;
    }

    public Environment newInstance() throws ClassNotFoundException, InstantiationException, IllegalAccessException {
        Class eClass;
        Environment e;
        
        logger.log(Level.INFO,
                       "EnvironmentLoader: loading class {0}",
                       new Object[] { getSubpath() });
        
        eClass = Class.forName(getSubpath());
        e = (Environment) eClass.newInstance();
        
        return e;
    }
    
}
