package spock.common.interfaces;

import spock.common.exceptions.IncompatibleInterfacesException;
import spock.common.exceptions.InterfaceAlreadyConnectedException;
import spock.common.exceptions.InterfaceNotConnectedException;
import spock.common.exceptions.InvalidSenderIndexException;
import spock.common.exceptions.InvalidSignalException;
import spock.common.signals.NetworkSignal;

/**
 *
 * @author Loren Chorley
 */
public interface SpockInterface extends Node {
    
    public static final boolean OUTPUT_INTERFACE = false;
    public static final boolean INPUT_INTERFACE = true;
    
    public String getIDString();
    public boolean interfaceType();
    public boolean isConnected();
    public SpockInterface getConnectedInterface();
    public int getNumberOfNodes();
    public void acceptConnection(SpockInterface spockInterface) throws InterfaceAlreadyConnectedException, IncompatibleInterfacesException;
    public void disconnect();
}
