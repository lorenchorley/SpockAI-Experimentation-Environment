package spock.common.interfaces;

/**
 *
 * @author Loren Chorley
 */
public class SpockObservableLong extends SpockObservable<Long> {
    
    public SpockObservableLong(String name, Long initial_value) {
        super(name, initial_value);
    }

    public void add(Long number) {
        value += number;
    }
    
    public void subtract(Long number) {
        value -= number;
    }
}
