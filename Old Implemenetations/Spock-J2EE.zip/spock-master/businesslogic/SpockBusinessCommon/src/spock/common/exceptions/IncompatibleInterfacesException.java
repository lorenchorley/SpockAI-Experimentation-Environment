package spock.common.exceptions;

/**
 *
 * @author Loren Chorley
 */
public class IncompatibleInterfacesException extends Exception {
    
}
