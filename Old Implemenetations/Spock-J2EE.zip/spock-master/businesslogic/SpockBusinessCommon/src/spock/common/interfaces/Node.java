package spock.common.interfaces;

import spock.common.exceptions.InterfaceNotConnectedException;
import spock.common.exceptions.InvalidSenderIndexException;
import spock.common.exceptions.InvalidSignalException;
import spock.common.signals.NetworkSignal;

/**
 *
 * @author Loren Chorley
 */
public interface Node {
    public long getID();
    public void acceptSignal(NetworkSignal signal, Node sender) throws InterfaceNotConnectedException, InvalidSenderIndexException, InvalidSignalException;
}
