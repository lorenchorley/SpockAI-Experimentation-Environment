package spock.common.tools.dynamicLoading;

import java.io.FileNotFoundException;

/**
 * @author Loren Chorley
 */
public class HotLoader {
	
	public Class loadClass(String path) throws FileNotFoundException {
		
		//TODO
		return null;
	}
	
}
