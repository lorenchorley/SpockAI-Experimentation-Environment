package spock.common.interfaces;

/**
 * Allows for module-wide control of activity in threaded objects.
 * 
 * @author Loren Chorley
 */
public interface SpockRunnable {
    
    /**
     * Start object and all sub-objects.
     */
    public void startActivity();
    
    /**
     * Stop object and all sub-objects.
     */
    public void stopActivity();
    
    /**
     * Reports whether an activity has completed stopping all it's processes
     * @return whether the activity has stopped.
     */
    public boolean hasStopped();
    
    /*
     * Pause object and all sub-objects.
     */
    public void pauseActivity();
    
    /*
     * Resume object and all sub-objects.
     */
    public void resumeActivity();
    
}
