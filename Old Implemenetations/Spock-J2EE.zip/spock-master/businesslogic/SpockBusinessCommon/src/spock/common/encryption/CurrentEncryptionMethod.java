package spock.common.encryption;

/**
 *
 * @author Loren Chorley
 */
public class CurrentEncryptionMethod implements EncryptionMethod {
    
    private EncryptionMethod currentMethod;
    
    public CurrentEncryptionMethod() {
        currentMethod = new MD5Sum();
    }
    
    @Override
    public String encrypt(String phrase) {
        return currentMethod.encrypt(phrase);
    }
    
}
