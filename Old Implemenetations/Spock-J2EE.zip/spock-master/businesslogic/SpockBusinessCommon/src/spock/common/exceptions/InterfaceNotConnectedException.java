package spock.common.exceptions;

/**
 *
 * @author Loren Chorley
 */
public class InterfaceNotConnectedException extends Exception {
    
}
