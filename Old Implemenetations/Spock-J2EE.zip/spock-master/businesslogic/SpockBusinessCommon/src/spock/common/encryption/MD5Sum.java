package spock.common.encryption;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 *
 * @author Loren Chorley
 */
public class MD5Sum implements EncryptionMethod {

    /**
     * Encrypts the given string via md5
     * Not the best encryption possible, but this is to at least set up the 
     * functionality of password encryption. Then any encryption mode can be
     * employed easily by adding a new EncryptionMethod.
     * @param str string to be converted
     * @return returns a hex string
     */
    @Override
    public String encrypt(String phrase) {
        String result = "";
        
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] bytesOfMessage = phrase.getBytes("UTF-8");
            byte[] encryptedPassword = md.digest(bytesOfMessage);
            
            result = new BigInteger(1, encryptedPassword).toString(16);
            
        } catch (UnsupportedEncodingException ex) {
        } catch (NoSuchAlgorithmException ex) {
        } finally {
            return result;
        }
    }
    
}
