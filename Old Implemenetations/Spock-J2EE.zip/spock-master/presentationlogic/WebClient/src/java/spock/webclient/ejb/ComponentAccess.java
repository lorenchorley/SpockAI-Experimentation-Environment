package spock.webclient.ejb;

import java.io.Serializable;
import java.net.MalformedURLException;
import java.rmi.RemoteException;
import javax.annotation.PostConstruct;
import javax.faces.bean.SessionScoped;
import javax.inject.Named;
import spock.business.ejb.BusinessInterfaceRequest;
import spock.dataaccess.ejb.interfaces.DataRequest;
import spock.environment.ejb.EnvironmentRequest;
import spock.network.ejb.NetworkRequest;
import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.faces.application.ConfigurableNavigationHandler;
import javax.faces.application.FacesMessage;
import javax.faces.application.NavigationHandler;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import spock.common.encryption.CurrentEncryptionMethod;
import spock.common.encryption.EncryptionMethod;

/**
 * 
 * @author Loren Chorley
 */
@ManagedBean(name="components")
@SessionScoped
public class ComponentAccess implements Serializable {

    @EJB
    private DataRequest data;
    
    @EJB
    private NetworkRequest network;
    
    @EJB
    private EnvironmentRequest environment;
    
    @EJB
    private BusinessInterfaceRequest business;

    public EncryptionMethod encryptionMethod;
    protected String username;
    protected String password;
    
    public ComponentAccess() {
        encryptionMethod = new CurrentEncryptionMethod();
    }
    
    public BusinessInterfaceRequest getBusinessComponent() {
        return business;
    }

    public DataRequest getDataComponent() {
        return data;
    }

    public EnvironmentRequest getEnvironmentComponent() {
        return environment;
    }

    public NetworkRequest getNetworkComponent() {
        return network;
    }
    
    @PostConstruct
    public void Setup() throws RemoteException {
        // dev auto login
        username = "admin";
        password = "admin";
        login();
    }
    
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
    
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Log into the data access component.
     */
    public String login() throws RemoteException {
        
        if (data == null) {
            return "data == null";
        }

        if (data.login(username, encryptionMethod.encrypt(password))) {
            password = "";
            
            FacesContext facesContext = FacesContext.getCurrentInstance();
            NavigationHandler navigationHandler = facesContext.getApplication().getNavigationHandler();
            navigationHandler.handleNavigation(facesContext, null, "Home");
            
            return "/dojo/Home";
        } else {
            password = "";
            
            return "Failed to authenticate " + username + " " + password;
        }
        
    }
    
    public void logout() throws RemoteException {
        data.logout();
    }
    
    /**
     * @return if this bean is still logged into the data access component
     */
    public boolean isLoggedIn() throws RemoteException {
        return data.userVerified();
    }

    public String getLoggedInUser() throws RemoteException {
        if (data.userVerified()) {
            return data.getLoggedInUser();
        } else {
            return "User is not logged in.";
        }
    }
    
    public void verificationRedirect() throws RemoteException, MalformedURLException {
        // If not logged in, redirect to login page
        if (!isLoggedIn()) {
            FacesContext facesContext = FacesContext.getCurrentInstance();
            NavigationHandler navigationHandler = facesContext.getApplication().getNavigationHandler();
            navigationHandler.handleNavigation(facesContext, null, "login");
        }
    }
    
}
