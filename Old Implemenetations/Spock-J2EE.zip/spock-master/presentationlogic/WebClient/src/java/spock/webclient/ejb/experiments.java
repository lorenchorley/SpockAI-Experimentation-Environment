package spock.webclient.ejb;

import java.util.ArrayList;
import java.util.Collection;
import javax.ejb.EJBException;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.RequestScoped;
import spock.dataaccess.ejb.interfaces.entities.Experiment;

/**
 *
 * @author Loren Chorley
 */
@ManagedBean
@RequestScoped
public class experiments {
    
    @ManagedProperty(value="#{components}") 
    private ComponentAccess components;

    public void setComponents(ComponentAccess components) {
        this.components = components;
    }
    
    public Collection<Experiment> getExperimentList() {
        try {
            
            Collection<Experiment> rtn = new ArrayList<Experiment>();
            
            if (!components.isLoggedIn()) {
                rtn = null;
            } else {
                rtn = components.getDataComponent().Experiment().retrieveEntity(null);
            }
            
            return rtn;
        } catch (Exception ex) {
            throw new EJBException("experiments.getExperiments() threw: " + ex.getMessage() + " (" + ex.toString() + ")");
        }
    }
    
}
