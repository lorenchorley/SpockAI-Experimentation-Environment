package spock.webclient.ejb;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Properties;
import javax.ejb.EJBException;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.RequestScoped;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import spock.dataaccess.ejb.interfaces.entities.Experiment;
import spock.dataaccess.ejb.interfaces.entities.Network;
import spock.dataaccess.entities.ExperimentEntity;
import spock.network.ejb.NetworkRequest;

/**
 *
 * @author Loren Chorley
 */
@ManagedBean
@RequestScoped
public class config implements Serializable {

    protected String title = "Spock Web Client";
    
    @ManagedProperty(value="#{components}") 
    private ComponentAccess components;

    public void setComponents(ComponentAccess components) {
        this.components = components;
    }
    
    /**
     * Get the value of title
     * @return the title of the web project
     */
    public String getTitle() {
        return title;
    }
    
    public Collection<String> getTestStrings() throws RemoteException {
        
        Collection<String> rtn = new ArrayList<String>();
        rtn.add(components.getDataComponent().returnTestString());
        rtn.add(components.getEnvironmentComponent().returnTestString());
        rtn.add(components.getNetworkComponent().returnTestString());
        rtn.add(components.getBusinessComponent().returnTestString());
        return rtn;
    }
    
    public Collection<String> getContent() throws RemoteException {
        try {
            String tmp = "";
            Collection<String> rtn = new ArrayList<String>();
            
            if (components == null) {
                rtn.add("components == null");
                return rtn;
            } else {
                rtn.add("ComponentAccess injected correctly");
            }
            
            rtn.add("Logged in? " + ((components.isLoggedIn()) ? "Yes." : "No."));
            
            
            /*User user = components.getDataComponent().User().retrieveEntity("admin").get(0);
            
            rtn.add("admin user: " + user.getUsername() + ", " + user.getPassword() + ", " + user.getAccessRights());
            
            rtn.add("User count: " + components.getDataComponent().User().countEntities());*/
            
            
            
            return rtn;
        } catch (Exception ex) {
            throw new EJBException("config.getContent() threw: " + ex.getMessage() + " (" + ex.toString() + ")");
        }
    }

    public String addNewEntry() throws RemoteException {
        
        if (components == null) {
            throw new EJBException("components is null");
        }

        if (components.isLoggedIn()) {

            List<Experiment> x = components.getDataComponent().Experiment().retrieveEntity("Exp1");
            List<Network> n = components.getDataComponent().Network().retrieveEntity("New Network");

            components.getDataComponent().Experiment().Networks().setEntityWithinCollection(x.get(0), n.get(0));

            return "done";

        } else {
            return "not done";
        }
            
            
    }
    
    public String getNetworkTestStringViaManualContext() throws NamingException {
        
        Properties props = new Properties();
        props.setProperty("java.naming.factory.initial", "com.sun.enterprise.naming.SerialInitContextFactory");
        props.setProperty("java.naming.factory.url.pkgs", "com.sun.enterprise.naming");
        props.setProperty("java.naming.factory.state", "com.sun.corba.ee.impl.presentation.rmi.JNDIStateFactoryImpl");

        // optional.  Defaults to localhost.  Only needed if web server is running
        // on a different host than the appserver   
        props.setProperty("org.omg.CORBA.ORBInitialHost", "127.0.0.1");
        // optional.  Defaults to 3700.  Only needed if target orb port is not 3700.
        props.setProperty("org.omg.CORBA.ORBInitialPort", "3700");

        InitialContext ic = new InitialContext(props);
        NetworkRequest n = (NetworkRequest)ic.lookup("java:global/SpockNetwork/NetworkRequestBean!spock.network.ejb.NetworkRequest");

        return n.returnTestString();
        
    }
    
    public String getResponseNewExperiment() throws RemoteException {
        try {
            
            // Return no message on page load
            if (ExperimentName == null) {
                ExperimentName = "";
                return "";
            }
            
            if (ExperimentName.equals("")) {
                return "You must enter a name for the new experiment.";
            }
            
            if (!components.isLoggedIn()) {
                return "Not logged in.";
            }
            
            ExperimentEntity ee;
            ee = new ExperimentEntity();
            
            ee.setId(ExperimentName);
            ee.setIsActive(Boolean.TRUE);
            
            components.getDataComponent().Experiment().setEntity(ee);
            
            return "Successfully created new experiment.";
            
        } catch (Exception ex) {
            throw new EJBException("config.getResponseNewExperiment() threw: " + ex.getMessage() + " (" + ex.toString() + ")");
        }
    }
    
    public String getResponseDeleteExperiment() throws RemoteException {
        try {
            
            // Return no message on page load
            if (ExperimentName == null) {
                ExperimentName = "";
                return "";
            }
            
            
            if (ExperimentName.equals("")) {
                return "You must enter a name for the new experiment.";
            }
            
            // Login
            if (!components.isLoggedIn()) {
                return "Not logged in.";
            }
            
            components.getDataComponent().Experiment().removeEntityByID(ExperimentName);
            
            return "Successfully created new experiment.";
            
        } catch (Exception ex) {
            throw new EJBException("config.getResponseDeleteExperiment() threw: " + ex.getMessage() + " (" + ex.toString() + ")");
        }
    }
    
    protected String ExperimentName = null;

    public String getNewExperiment() {
        return ExperimentName;
    }

    public void setNewExperiment(String NewExperiment) {
        this.ExperimentName = NewExperiment;
    }

    
    
    
}
