/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package spock.webclient.ejb;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.RequestScoped;
import javax.inject.Named;
import spock.dataaccess.ejb.interfaces.entities.Experiment;

/**
 *
 * @author Loren
 */
@Named
@RequestScoped
public class sections implements Serializable {

    @ManagedProperty(value="#{components}") 
    private ComponentAccess components;
    
    Collection<String> sections;
    Collection<String> listControls;
    Collection<String> itemControls;
    
    @PostConstruct
    public void setup() {
        sections = new ArrayList<String>();
        listControls = new ArrayList<String>();
        itemControls = new ArrayList<String>();
        
        sections.add("Experiments");
        sections.add("Environments");
        sections.add("Networks");
        sections.add("Servers");
        sections.add("Database");
        sections.add("Tests");
        sections.add("Settings");
        
        listControls.add("Create new");
        listControls.add("Refresh list");
        listControls.add("Display list");
        
        itemControls.add("Status");
        itemControls.add("Edit");
        itemControls.add("Delete");
        itemControls.add("Start");
        itemControls.add("Stop");
    }
    
    public Collection<String> getSectionNames() {
        return sections;
    }
    
    public Collection<String> getListControlsNames() {
        return listControls;
    }
    
    public Collection<String> getItemControlsNames() {
        return itemControls;
    }
    
    public Collection dataList(String type) throws RemoteException {
        Collection rtn;
        if (components == null || !components.isLoggedIn()) {
            rtn = new ArrayList();
        } else if (type.equals("Experiments")) {
            rtn = components.getDataComponent().Experiment().retrieveEntity(null);
        } else if (type.equals("Environments")) {
            rtn = new ArrayList();
        } else if (type.equals("Networks")) {
            rtn = new ArrayList();
        } else if (type.equals("Servers")) {
            rtn = new ArrayList();
        } else if (type.equals("Database")) {
            rtn = new ArrayList();
        } else if (type.equals("Tests")) {
            rtn = new ArrayList();
        } else if (type.equals("Settings")) {
            rtn = new ArrayList();
        } else {
            rtn = new ArrayList();
        }
        return rtn;
    }
    
    
}
