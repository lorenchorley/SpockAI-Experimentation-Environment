package spock.webclient.ejb;

import spock.dataaccess.ejb.interfaces.entities.EntityPropertyAccess;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.ejb.EJBException;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;
import spock.dataaccess.entities.ConfigurationEntity;
import spock.dataaccess.entities.EnvironmentEntity;
import spock.dataaccess.entities.ExperimentEntity;
import spock.dataaccess.entities.InterfaceConnectionEntity;
import spock.dataaccess.entities.MetricEntity;
import spock.dataaccess.entities.NetworkBehaviourEntity;
import spock.dataaccess.entities.NetworkEntity;
import spock.dataaccess.entities.UserEntity;
import spock.dataaccess.entities.UserInterfaceEntity;

/**
 *
 * @author Loren Chorley
 */
@ManagedBean
@SessionScoped
public class database {
    
    @ManagedProperty(value="#{components}") 
    private ComponentAccess components;

    public void setComponents(ComponentAccess components) {
        this.components = components;
    }
    
    protected String selectedDataField = "Experiments";
    protected String selectedEntry = "";

    public String getSelectedDataField() {
        return selectedDataField;
    }

    public void setSelectedDataField(String selectedDataField) {
        this.selectedDataField = selectedDataField;
        selectedEntry = ""; // Clear any selected entry from the previous view
    }
    
    public String getSelectedEntry() {
        return selectedEntry;
    }

    public void setSelectedEntry(String selectedEntry) {
        this.selectedEntry = selectedEntry;
    }

    /**
     * Generates a list of table names that can be listed - 
     * @return table names that can be listed
     */
    public Collection<String> getTables() {
        try {
            
            Collection<String> tables = new ArrayList<String>();
            
            tables.add("Experiments");
            tables.add("Interface Connections");
            tables.add("Environments");
            /*tables.add("Environment Interfaces");
            tables.add("Environment Nodes");*/
            tables.add("Networks");
            tables.add("Network Behaviours");
            /*tables.add("Network Connections");
            tables.add("Network Interfaces");
            tables.add("Network Nodes");*/
            tables.add("Users");
            tables.add("User Interfaces");
            tables.add("Metrics");
            tables.add("Configurations");
            
            return tables;
            
        } catch (Exception ex) {
            throw new EJBException("database.getTables() threw: " + ex.toString());
        }
    }
    
    /**
     * 
     * @return 
     */
    public Boolean showCollectionTables() {
        return getCollectionTables().size() > 0 && !"".equals(selectedEntry);
    }
    
    /**
     * Get the names of the collections associated with the selected table -
     * @return associated collection names
     */
    public Collection<String> getCollectionTables() {
        try {
            
            Collection<String> rtnCollection = null;
            
            if (selectedDataField.equals("Experiments")) {
                rtnCollection = ExperimentEntity.getCollectionNames();
            } else if (selectedDataField.equals("Interface Connections")) {
                rtnCollection = InterfaceConnectionEntity.getCollectionNames();
            } else if (selectedDataField.equals("Environments")) {
                rtnCollection = EnvironmentEntity.getCollectionNames();
            } else if (selectedDataField.equals("Networks")) {
                rtnCollection = NetworkEntity.getCollectionNames();
            } else if (selectedDataField.equals("Network Behaviours")) {
                rtnCollection = NetworkBehaviourEntity.getCollectionNames();
            } else if (selectedDataField.equals("Users")) {
                rtnCollection = UserEntity.getCollectionNames();
            } else if (selectedDataField.equals("User Interfaces")) {
                rtnCollection = UserInterfaceEntity.getCollectionNames();
            } else if (selectedDataField.equals("Metrics")) {
                rtnCollection = MetricEntity.getCollectionNames();
            } else if (selectedDataField.equals("Configurations")) {
                rtnCollection = ConfigurationEntity.getCollectionNames();
            } else {
                throw new EJBException("Collections not found! (" + selectedDataField + ")");
            }
            
            if (rtnCollection == null) {
                throw new EJBException("getCollectionNames() attribute returned null for " + selectedDataField);
            }
            
            for (String name : rtnCollection) {
                if ("".equals(name)) {
                    throw new EJBException("entry in getCollectionNames() attribute returned '' for " + selectedDataField);
                }
            }
            
            return rtnCollection;
            
            
        } catch (Exception ex) {
            throw new EJBException("database.getCollectionTables() threw: " + ex.toString());
        }
    }
    
    /**
     * Get the table headers for a selected table -
     * @return table headers
     */
    public Collection<String> getTableHeaders() {
        try {
            
            Collection<String> rtnCollection = null;
            
            if (selectedDataField.equals("Experiments")) {
                rtnCollection = ExperimentEntity.getFieldNames();
            } else if (selectedDataField.equals("Interface Connections")) {
                rtnCollection = InterfaceConnectionEntity.getFieldNames();
            } else if (selectedDataField.equals("Environments")) {
                rtnCollection = EnvironmentEntity.getFieldNames();
            /*} else if (SelectedDataField.equals("Environment Interfaces")) {
                rtnCollection = EnvironmentInterfaceEntity.getFieldNames();
            } else if (SelectedDataField.equals("Environment Nodes")) {
                rtnCollection = EnvironmentNodeEntity.getFieldNames();*/
            } else if (selectedDataField.equals("Networks")) {
                rtnCollection = NetworkEntity.getFieldNames();
            } else if (selectedDataField.equals("Network Behaviours")) {
                rtnCollection = NetworkBehaviourEntity.getFieldNames();
            /*} else if (SelectedDataField.equals("Network Connections")) {
                rtnCollection = NetworkConnectionEntity.getFieldNames();
            } else if (SelectedDataField.equals("Network Interfaces")) {
                rtnCollection = NetworkInterfaceEntity.getFieldNames();
            } else if (SelectedDataField.equals("Network Nodes")) {
                rtnCollection = NetworkNodeEntity.getFieldNames();*/
            } else if (selectedDataField.equals("Users")) {
                rtnCollection = UserEntity.getFieldNames();
            } else if (selectedDataField.equals("User Interfaces")) {
                rtnCollection = UserInterfaceEntity.getFieldNames();
            } else if (selectedDataField.equals("Metrics")) {
                rtnCollection = MetricEntity.getFieldNames();
            } else if (selectedDataField.equals("Configurations")) {
                rtnCollection = ConfigurationEntity.getFieldNames();
            }
            
            if (rtnCollection == null) {
                throw new EJBException("Data field not found! (" + selectedDataField + ")");
            }
            
            return rtnCollection;
            
        } catch (Exception ex) {
            throw new EJBException("database.getTableHeaders() threw: " + ex.toString());
        }
    }
    
    /**
     * 
     * @param collectionName
     * @return 
     */
    public Collection<String> getCollectionTableHeaders(String collectionName) {
        try {
            
            Collection<String> headers = new ArrayList<String>();
            
            headers.add("Name");
            
            return headers;
            
        } catch (Exception ex) {
            throw new EJBException("database.getCollectionTableHeaders() threw: " + ex.toString());
        }
    }
    
    /**
     * Get the table data -
     * @return table data
     */
    public Collection<Collection> getData() {
        try {
            
            Collection<Collection> rtn = null;
            Collection list = null;
            
            Collection<String> fieldNames = null;
            List<EntityPropertyAccess> allEntities = null;
            
            if (selectedDataField.equals("Experiments")) {
                allEntities = (List) components.getDataComponent().Experiment().retrieveEntity(null);
                fieldNames = ExperimentEntity.getFieldNames();
            } else if (selectedDataField.equals("Interface Connections")) {
                allEntities = (List) components.getDataComponent().Connection().retrieveEntity(null);
                fieldNames = InterfaceConnectionEntity.getFieldNames();
            } else if (selectedDataField.equals("Environments")) {
                allEntities = (List) components.getDataComponent().Environment().retrieveEntity(null);
                fieldNames = EnvironmentEntity.getFieldNames();
            /*} else if (SelectedDataField.equals("Environment Interfaces")) {
                allEntities = (List) components.getDataComponent().().retrieveEntity(null);
                fieldNames = EnvironmentInterfaceEntity.getFieldNames();
            } else if (SelectedDataField.equals("Environment Nodes")) {
                allEntities = (List) components.getDataComponent().().retrieveEntity(null);
                fieldNames = EnvironmentNodeEntity.getFieldNames();*/
            } else if (selectedDataField.equals("Networks")) {
                allEntities = (List) components.getDataComponent().Network().retrieveEntity(null);
                fieldNames = NetworkEntity.getFieldNames();
            } else if (selectedDataField.equals("Network Behaviours")) {
                allEntities = (List) components.getDataComponent().Behaviour().retrieveEntity(null);
                fieldNames = NetworkBehaviourEntity.getFieldNames();
            /*} else if (SelectedDataField.equals("Network Connections")) {
                allEntities = (List) components.getDataComponent().().retrieveEntity(null);
                fieldNames = NetworkConnectionEntity.getFieldNames();
            } else if (SelectedDataField.equals("Network Interfaces")) {
                allEntities = (List) components.getDataComponent().().retrieveEntity(null);
                fieldNames = NetworkInterfaceEntity.getFieldNames();
            } else if (SelectedDataField.equals("Network Nodes")) {
                allEntities = (List) components.getDataComponent().().retrieveEntity(null);
                fieldNames = NetworkNodeEntity.getFieldNames();*/
            } else if (selectedDataField.equals("Users")) {
                allEntities = (List) components.getDataComponent().User().retrieveEntity(null);
                fieldNames = UserEntity.getFieldNames();
            } else if (selectedDataField.equals("User Interfaces")) {
                allEntities = (List) components.getDataComponent().UserInterface().retrieveEntity(null);
                fieldNames = UserInterfaceEntity.getFieldNames();
            } else if (selectedDataField.equals("Metrics")) {
                allEntities = (List) components.getDataComponent().Metric().retrieveEntity(null);
                fieldNames = MetricEntity.getFieldNames();
            } else if (selectedDataField.equals("Configurations")) {
                allEntities = (List) components.getDataComponent().Configuration().retrieveEntity(null);
                fieldNames = ConfigurationEntity.getFieldNames();
            }
            
            if (components.isLoggedIn()) {
                rtn = new ArrayList<Collection>();
                
                for (EntityPropertyAccess entity : allEntities) {
                    list = new ArrayList<Object>();
                    for (String field : fieldNames) {
                        list.add(entity.getProperty(field));
                    }
                    rtn.add(list);
                }
            }
            
            return rtn;
        } catch (Exception ex) {
            throw new EJBException("database.getData() threw: " + ex.toString());
        }
    }
    
    /**
     * 
     * @param collectionName
     * @return 
     */
    public Collection<String> getCollectionData(String collectionName) {
        try {
            
            // Exclude instances where this method is called without a parameter
            if ("".equals(collectionName)) {
                return null;
            }
            
            Collection retrievedCollection;
            ArrayList<String> names = new ArrayList<String>();
            
            if ("".equals(selectedEntry)) {
                return names;
            } else if (selectedDataField.equals("Experiments")) {
                
                retrievedCollection = (Collection) components.getDataComponent().Experiment().retrieveEntity(selectedEntry).get(0).getProperty(collectionName);
                
                if (collectionName.equals("Networks")) {
                    for (NetworkEntity entity : (Collection<NetworkEntity>) retrievedCollection) {
                        names.add(entity.getId());
                    }
                } else if (collectionName.equals("Environments")) {
                    for (EnvironmentEntity entity : (Collection<EnvironmentEntity>) retrievedCollection) {
                        names.add(entity.getId());
                    }
                } else if (collectionName.equals("Interfaces")) {
                    for (UserInterfaceEntity entity : (Collection<UserInterfaceEntity>) retrievedCollection) {
                        names.add(entity.getId().toString());
                    }
                }
                
            } else if (selectedDataField.equals("Interface Connections")) {
                //rtnCollection = InterfaceConnectionEntity.getCollectionNames();
            } else if (selectedDataField.equals("Environments")) {
                //rtnCollection = EnvironmentEntity.getCollectionNames();
            } else if (selectedDataField.equals("Networks")) {
                //rtnCollection = NetworkEntity.getCollectionNames();
            } else if (selectedDataField.equals("Network Behaviours")) {
                //rtnCollection = NetworkBehaviourEntity.getCollectionNames();
            } else if (selectedDataField.equals("Users")) {
                //rtnCollection = UserEntity.getCollectionNames();
            } else if (selectedDataField.equals("User Interfaces")) {
                //rtnCollection = UserInterfaceEntity.getCollectionNames();
            } else if (selectedDataField.equals("Metrics")) {
                //rtnCollection = MetricEntity.getCollectionNames();
            } else if (selectedDataField.equals("Configurations")) {
                //rtnCollection = ConfigurationEntity.getCollectionNames();
            }
                        
            return names;
            
        } catch (Exception ex) {
            throw new EJBException("database.getCollectionData() threw: " + ex.toString());
        }
    }
    
    /**
     * Removes the spaces from a string
     * @param string to remove spaces from
     * @return a copy of the original string that has no spaces
     */
    public String removeSpaces(String str) {
        String newStr = str;
        return newStr.replaceAll("\\s","");
    }
    
}
