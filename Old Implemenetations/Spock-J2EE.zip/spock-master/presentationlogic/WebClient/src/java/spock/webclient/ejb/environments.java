package spock.webclient.ejb;

import java.util.ArrayList;
import java.util.Collection;
import javax.ejb.EJBException;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;
import spock.dataaccess.ejb.interfaces.entities.Environment;

/**
 *
 * @author Loren Chorley
 */
@ManagedBean
@SessionScoped
public class environments {
    
    @ManagedProperty(value="#{components}") 
    private ComponentAccess components;

    public void setComponents(ComponentAccess components) {
        this.components = components;
    }
    
    public Collection<Environment> getEnvironmentList() {
        try {
            
            Collection<Environment> rtn = new ArrayList<Environment>();
            
            if (!components.isLoggedIn()) {
                rtn = null;
            } else {
                rtn = components.getDataComponent().Environment().retrieveEntity(null);
            }
            
            return rtn;
        } catch (Exception ex) {
            throw new EJBException("experiments.getExperiments() threw: " + ex.getMessage() + " (" + ex.toString() + ")");
        }
    }
    
}
