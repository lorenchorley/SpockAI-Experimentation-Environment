package spock.webclient.ejb;

import java.util.ArrayList;
import java.util.Collection;
import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.RequestScoped;
import javax.faces.bean.SessionScoped;
import javax.inject.Named;
import spock.dataaccess.ejb.interfaces.entities.Network;

/**
 *
 * @author Loren Chorley
 */
@ManagedBean
@SessionScoped
public class networks {
    
    @ManagedProperty(value="#{components}") 
    private ComponentAccess components;

    public void setComponents(ComponentAccess components) {
        this.components = components;
    }
    
    public Collection<Network> getNetworkList() {
        try {
            
            Collection<Network> rtn = new ArrayList<Network>();
            
            if (!components.isLoggedIn()) {
                rtn = null;
            } else {
                rtn = components.getDataComponent().Network().retrieveEntity(null);
            }
            
            return rtn;
        } catch (Exception ex) {
            throw new EJBException("experiments.getExperiments() threw: " + ex.getMessage() + " (" + ex.toString() + ")");
        }
    }
    
}
