spock
=====

This is a modest attempt at a neural network based on J2EE and EJB with a focus on rapid development and ease of use for NN testing concepts.

Work on this project has been halted due to a lack of time on behalf of the developer, and that a new Javascript version has been started. Please see the SpockJS project for further details on this.
