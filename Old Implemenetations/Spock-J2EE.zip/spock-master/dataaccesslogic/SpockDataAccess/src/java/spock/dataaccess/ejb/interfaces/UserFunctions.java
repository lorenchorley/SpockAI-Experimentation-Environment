package spock.dataaccess.ejb.interfaces;

import java.io.Serializable;
import java.rmi.RemoteException;
import javax.ejb.Remote;
import spock.dataaccess.ejb.interfaces.entities.User;
import spock.dataaccess.ejb.interfaces.entities.UserInterface;
import spock.dataaccess.entities.UserEntity;

/**
 *
 * @author Loren Chorley
 */
@Remote
public interface UserFunctions extends Serializable, BasicEntity<User, String> {
    
    public BasicEntityCollection<User, UserInterface, Long> UserInterfaces() throws RemoteException;
    
    /**
     * 
     * @param username
     * @param passwordHash
     * @return 
     */
    public boolean verifiyUser(String username, String passwordHash) throws RemoteException;
    
}
