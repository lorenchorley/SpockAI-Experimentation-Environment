package spock.dataaccess.ejb.support;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.rmi.RemoteException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJBException;
import javax.persistence.EntityManager;
import java.security.*;
import javax.annotation.PostConstruct;
import spock.dataaccess.ejb.interfaces.BasicEntityCollection;
import spock.dataaccess.ejb.interfaces.UserFunctions;
import spock.dataaccess.ejb.interfaces.entities.User;
import spock.dataaccess.ejb.interfaces.entities.UserInterface;
import spock.dataaccess.ejb.support.collections.UserUserInterfaceCollection;
import spock.dataaccess.entities.UserEntity;
import javax.ejb.Stateful;
import spock.common.encryption.CurrentEncryptionMethod;
import spock.common.encryption.EncryptionMethod;

/**
 *
 * @author Loren Chorley
 */
@Stateful
public class ConcreteUserFunctions extends AbstractBasicEntity<User, String> implements UserFunctions {
    private static final Logger logger = Logger.getLogger("spockdataaccess.ejb.requestsupport.UserFunctions");
    
    private UserUserInterfaceCollection userUserInterfaceCollection;
    
    public EncryptionMethod encryptionMethod;

    public ConcreteUserFunctions() {
        super();
        userUserInterfaceCollection = new UserUserInterfaceCollection();
        managedCollections.add(userUserInterfaceCollection);
        
        encryptionMethod = new CurrentEncryptionMethod();
        
    }
    
    @Override
    public BasicEntityCollection<User, UserInterface, Long> UserInterfaces() throws RemoteException {
        return userUserInterfaceCollection;
    }
    
    @Override
    public boolean verifiyUser(String username, String passwordHash) throws RemoteException {
        
        try {
            
            boolean verified = false;
            
            // If there are no users, create an admin user with a default password
            if (this.countEntities() == 0) {
                this.setEntity(new UserEntity("admin", encryptionMethod.encrypt("admin"), "", UserEntity.ACCESSRIGHTS_ADMIN));
            }
            
            // Check to see if there is a user that matches
            User user = (User) this.retrieveEntity(username).get(0);
            
            if (user != null) {
                if (user.getUsername().equals(username) && user.getPassword().equals(passwordHash)) {
                    verified = true;
                }
            }
            
            return verified;
        
        } catch (Exception ex) {
            throw new EJBException("UserFunctions.verifiyUser threw: " + ex.getMessage());
        }
        
    }

    @Override
    protected User newEntity(String id) {
        User u = new UserEntity();
        u.setUsername(id);
        return u;
    }

    @Override
    protected void copyEntityProperties(User sourceEntity, User targetEntity) {
        targetEntity.setPassword(sourceEntity.getPassword());
        targetEntity.setEmail(sourceEntity.getEmail());
        targetEntity.setAccessRights(sourceEntity.getAccessRights());
        targetEntity.getInterfaces().clear();
        targetEntity.getInterfaces().addAll(sourceEntity.getInterfaces());
    }

    @Override
    protected String getEntityID(User entity) {
        return entity.getUsername();
    }

    @Override
    protected String getEntityName() {
        return "UserEntity";
    }

    @Override
    protected Class getEntityClass() {
        return UserEntity.class;
    }

    @Override
    protected void verifyBusinessLogic(User entity) {
        
    }
    
}
