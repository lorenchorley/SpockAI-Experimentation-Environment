package spock.dataaccess.ejb.interfaces.entities;

/**
 * Provides general getter and setter methods for accessing select properties
 * @author Loren Chorley
 */
public interface EntityPropertyAccess {
    public Object getProperty(String PropertyName);
    public void setProperty(String PropertyName, Object PropertyValue);
}
