package spock.dataaccess.ejb.interfaces;

import java.rmi.RemoteException;
import javax.ejb.Remote;

/**
 *
 * @author Loren Chorley
 */
@Remote
public interface DataRequest {
    public boolean login(String username, String passwordHash) throws RemoteException;
    public void logout() throws RemoteException;
    public String getLoggedInUser() throws RemoteException;
    public boolean userVerified() throws RemoteException;
    public void sendPasswordResetEmail(String username) throws RemoteException;
    public UserFunctions User() throws RemoteException;
    public ExperimentFunctions Experiment() throws RemoteException;
    public ConfigurationFunctions Configuration() throws RemoteException;
    public NetworkFunctions Network() throws RemoteException;
    public EnvironmentFunctions Environment() throws RemoteException;
    public UserInterfaceFunctions UserInterface() throws RemoteException;
    public ConnectionFunctions Connection() throws RemoteException;
    public BehaviourFunctions Behaviour() throws RemoteException;
    public MetricFunctions Metric() throws RemoteException;
    public String returnTestString() throws RemoteException;
}
