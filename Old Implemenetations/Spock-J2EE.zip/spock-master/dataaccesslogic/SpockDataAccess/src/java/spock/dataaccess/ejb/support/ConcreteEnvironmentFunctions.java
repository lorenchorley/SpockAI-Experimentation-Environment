package spock.dataaccess.ejb.support;

import java.rmi.RemoteException;
import java.util.logging.Logger;
import javax.persistence.EntityManager;
import spock.dataaccess.ejb.interfaces.BasicEntityCollection;
import spock.dataaccess.ejb.interfaces.EnvironmentFunctions;
import spock.dataaccess.ejb.interfaces.entities.Environment;
import spock.dataaccess.ejb.interfaces.entities.EnvironmentInterface;
import spock.dataaccess.ejb.interfaces.entities.EnvironmentNode;
import spock.dataaccess.ejb.interfaces.entities.Experiment;
import spock.dataaccess.ejb.interfaces.entities.Metric;
import spock.dataaccess.ejb.support.collections.EnvironmentExperimentCollection;
import spock.dataaccess.ejb.support.collections.EnvironmentInterfaceCollection;
import spock.dataaccess.ejb.support.collections.EnvironmentMetricCollection;
import spock.dataaccess.ejb.support.collections.EnvironmentNodeCollection;
import spock.dataaccess.entities.EnvironmentEntity;
import javax.ejb.Stateful;

/**
 *
 * @author Loren Chorley
 */
@Stateful
public class ConcreteEnvironmentFunctions extends AbstractBasicEntity<Environment, String> implements EnvironmentFunctions {
    private static final Logger logger = Logger.getLogger("spockdataaccess.ejb.requestsupport.EnvironmentFunctions");
    
    private EnvironmentExperimentCollection environmentExperimentCollection;
    private EnvironmentNodeCollection environmentNodeCollection;
    private EnvironmentInterfaceCollection environmentInterfaceCollection;
    private EnvironmentMetricCollection environmentMetricCollection;
    
    public ConcreteEnvironmentFunctions() {
        super();
        environmentExperimentCollection = new EnvironmentExperimentCollection();
        environmentNodeCollection = new EnvironmentNodeCollection();
        environmentInterfaceCollection = new EnvironmentInterfaceCollection();
        environmentMetricCollection = new EnvironmentMetricCollection();
        managedCollections.add(environmentExperimentCollection);
        managedCollections.add(environmentNodeCollection);
        managedCollections.add(environmentInterfaceCollection);
        managedCollections.add(environmentMetricCollection);
    }
    
    @Override
    public BasicEntityCollection<Environment, Experiment, String> Experiments() throws RemoteException {
        return environmentExperimentCollection;
    }
    
    @Override
    public BasicEntityCollection<Environment, EnvironmentNode, Long> Nodes() throws RemoteException {
        return environmentNodeCollection;
    }
    
    @Override
    public BasicEntityCollection<Environment, EnvironmentInterface, Long> Interfaces() throws RemoteException {
        return environmentInterfaceCollection;
    }
    
    @Override
    public BasicEntityCollection<Environment, Metric, String> Metrics() throws RemoteException {
        return environmentMetricCollection;
    }
    
    @Override
    protected Environment newEntity(String id) {
        Environment x = new EnvironmentEntity();
        x.setId(id);
        return x;
    }

    @Override
    protected void copyEntityProperties(Environment sourceEntity, Environment targetEntity) {
        targetEntity.setIsActive(sourceEntity.getIsActive());
        targetEntity.setCodeURL(sourceEntity.getCodeURL());
        targetEntity.setDataURL(sourceEntity.getDataURL());
        targetEntity.getExperiments().clear();
        targetEntity.getExperiments().addAll(sourceEntity.getExperiments());
        targetEntity.getEnvironmentInterfaces().clear();
        targetEntity.getEnvironmentInterfaces().addAll(sourceEntity.getEnvironmentInterfaces());
        targetEntity.getEnvironmentNodes().clear();
        targetEntity.getEnvironmentNodes().addAll(sourceEntity.getEnvironmentNodes());
    }

    @Override
    protected String getEntityID(Environment entity) {
        return entity.getId();
    }

    @Override
    protected String getEntityName() {
        return "EnvironmentEntity";
    }

    @Override
    protected Class getEntityClass() {
        return EnvironmentEntity.class;
    }

    @Override
    protected void verifyBusinessLogic(Environment entity) {
        
    }
    
}
