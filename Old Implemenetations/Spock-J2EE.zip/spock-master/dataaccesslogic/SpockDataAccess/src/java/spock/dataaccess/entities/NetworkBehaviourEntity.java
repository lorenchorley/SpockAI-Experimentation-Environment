package spock.dataaccess.entities;

import java.util.ArrayList;
import java.util.Collection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import spock.dataaccess.ejb.interfaces.entities.NetworkBehaviour;

/**
 *
 * @author Loren Chorley
 */
@Entity
@Table(name = "NetworkBehaviours")
public class NetworkBehaviourEntity implements NetworkBehaviour {
    private static final long serialVersionUID = 1L;
    
    @Id
    private String id;
    @NotNull
    protected String codeURL;

    public NetworkBehaviourEntity() {
    }

    public NetworkBehaviourEntity(String id, String codeURL) {
        this.id = id;
        this.codeURL = codeURL;
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public void setId(String id) {
        this.id = id;
    }

    @Override
    public String getCodeURL() {
        return codeURL;
    }

    @Override
    public void setCodeURL(String codeURL) {
        this.codeURL = codeURL;
    }


    public static Collection<String> getFieldNames() {
        Collection<String> list = new ArrayList<String>();
        list.add("ID");
        list.add("Code URL");
        return list;
    }
    
    public static Collection<String> getCollectionNames() {
        return new ArrayList<String>();
    }
    
    @Override
    public Object getProperty(String PropertyName) {
        if (PropertyName.equals("ID")) {
            return id;
        } else if (PropertyName.equals("Code URL")) {
            return codeURL;
        } else {
            return null;
        }
    }

    @Override
    public void setProperty(String PropertyName, Object PropertyValue) {
        if (PropertyName.equals("ID")) {
            id = (String) PropertyValue;
        } else if (PropertyName.equals("Code URL")) {
            codeURL = (String) PropertyValue;
        }
    }
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof NetworkBehaviourEntity)) {
            return false;
        }
        NetworkBehaviourEntity other = (NetworkBehaviourEntity) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "spockdataaccess.entity.NetworkBehaviour[ id=" + id + " ]";
    }
    
}
