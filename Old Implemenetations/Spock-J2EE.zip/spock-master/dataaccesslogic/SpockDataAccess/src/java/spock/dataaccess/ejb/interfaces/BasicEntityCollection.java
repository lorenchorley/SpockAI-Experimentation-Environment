package spock.dataaccess.ejb.interfaces;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.List;
import javax.ejb.Remote;
import javax.persistence.EntityManager;

/**
 * Supplies a generalised set of functions for managing collections of entities within another entity.
 * @author Loren Chorley
 * @param <Econtainer> Entity container - the entity that contains the collection of entities
 * @param <E> Entity collection - the entity collection contained within the container entity
 * @param <ID> the type of the entities id field
 */
@Remote
public interface BasicEntityCollection<Econtainer, E, ID> extends Serializable {
    
    /**
     * 
     * @param container
     * @param entity
     * @return 
     */
    public E setEntityWithinCollection(Econtainer container, E entity) throws RemoteException;
    
    /**
     * 
     * @param container
     * @param id
     * @return 
     */
    public List<E> retrieveEntityWithinCollection(Econtainer container, ID id) throws RemoteException;
    
    /**
     * 
     * @param container
     * @return 
     */
    public Integer countEntitiesWithinCollection(Econtainer container) throws RemoteException;
    
    /**
     * 
     * @param container
     * @param id 
     */
    public void removeEntityFromCollectionByID(Econtainer container, ID id) throws RemoteException;
    
    /**
     * 
     * @param container
     * @param entity 
     */
    public void removeEntityFromCollection(Econtainer container, E entity) throws RemoteException;
    
    /**
     * 
     * @param em 
     */
    public void setEntityManager(EntityManager em) throws RemoteException;
            
}
