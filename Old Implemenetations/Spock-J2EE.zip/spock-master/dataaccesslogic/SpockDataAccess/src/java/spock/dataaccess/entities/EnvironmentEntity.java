package spock.dataaccess.entities;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import spock.dataaccess.ejb.interfaces.entities.Environment;
import spock.dataaccess.ejb.interfaces.entities.EnvironmentInterface;
import spock.dataaccess.ejb.interfaces.entities.EnvironmentNode;
import spock.dataaccess.ejb.interfaces.entities.Experiment;
import spock.dataaccess.ejb.interfaces.entities.Metric;

/**
 *
 * @author Loren Chorley
 */
@Entity
@Table(name = "Environments")
public class EnvironmentEntity implements Environment {
    private static final long serialVersionUID = 1L;
    
    @Id
    private String id;
    @NotNull
    protected Boolean isActive;
    @NotNull
    protected String codeURL;
    @NotNull
    protected String dataURL;
    @ManyToMany(fetch=FetchType.EAGER)
    protected Collection<MetricEntity> metrics;
    
    @ManyToMany(mappedBy="environments",fetch=FetchType.EAGER)
    protected Collection<ExperimentEntity> experiments;
    @OneToMany(mappedBy="environment",fetch=FetchType.EAGER)
    protected Collection<EnvironmentNodeEntity> environmentNodes;
    @OneToMany(mappedBy="environment",fetch=FetchType.EAGER)
    protected Collection<EnvironmentInterfaceEntity> environmentInterfaces;
    
    public EnvironmentEntity() {
        experiments = new ArrayList<ExperimentEntity>();
        environmentNodes = new ArrayList<EnvironmentNodeEntity>();
        environmentInterfaces = new ArrayList<EnvironmentInterfaceEntity>();
        metrics = new ArrayList<MetricEntity>();
    }

    public EnvironmentEntity(String id, Boolean isActive, String codeURL, String dataURL) {
        experiments = new ArrayList<ExperimentEntity>();
        environmentNodes = new ArrayList<EnvironmentNodeEntity>();
        environmentInterfaces = new ArrayList<EnvironmentInterfaceEntity>();
        metrics = new ArrayList<MetricEntity>();
        this.id = id;
        this.isActive = isActive;
        this.codeURL = codeURL;
        this.dataURL = dataURL;
    }
    
    @Override
    public String getId() {
        return id;
    }

    @Override
    public void setId(String id) {
        this.id = id;
    }

    @Override
    public Boolean getIsActive() {
        return isActive;
    }

    @Override
    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    @Override
    public Collection<Experiment> getExperiments() {
        return (Collection) experiments;
    }
    
    @Override
    public void addExperiment(Experiment experiment) {
        experiments.add((ExperimentEntity) experiment);
    }
    
    @Override
    public String getCodeURL() {
        return codeURL;
    }

    @Override
    public void setCodeURL(String codeURL) {
        this.codeURL = codeURL;
    }

    @Override
    public String getDataURL() {
        return dataURL;
    }

    @Override
    public void setDataURL(String dataURL) {
        this.dataURL = dataURL;
    }

    @Override
    public Collection<EnvironmentInterface> getEnvironmentInterfaces() {
        return (List) environmentInterfaces;
    }

    @Override
    public void setEnvironmentInterfaces(Collection<EnvironmentInterface> environmentInterfaces) {
        this.environmentInterfaces = (List) environmentInterfaces;
    }

    @Override
    public Collection<EnvironmentNode> getEnvironmentNodes() {
        return (List) environmentNodes;
    }

    @Override
    public void setEnvironmentNodes(Collection<EnvironmentNode> environmentNodes) {
        this.environmentNodes = (List) environmentNodes;
    }
    
    @Override
    public void addEnvironmentInterface(EnvironmentInterface environmentInterface) {
        environmentInterfaces.add((EnvironmentInterfaceEntity) environmentInterface);
    }
    
    @Override
    public void addEnvironmentNode(EnvironmentNode environmentNode) {
        environmentNodes.add((EnvironmentNodeEntity) environmentNode);
    }

    @Override
    public Collection<Metric> getMetrics() {
        return (List) metrics; //TODO Find better soln! This sacrifices all type safety
    }

    @Override
    public void setMetrics(Collection<Metric> metrics) {
        this.metrics = (List) metrics; //TODO Find better soln! This sacrifices all type safety
    }
    
    
    public static Collection<String> getFieldNames() {
        Collection<String> list = new ArrayList<String>();
        list.add("Id");
        list.add("Is Active");
        list.add("Code URL");
        list.add("Data URL");
        return list;
    }
    
    public static Collection<String> getCollectionNames() {
        Collection<String> list = new ArrayList<String>();
        list.add("Experiments");
        list.add("Environment Nodes");
        list.add("Environment Interfaces");
        return list;
    }
    
    @Override
    public Object getProperty(String PropertyName) {
        if (PropertyName.equals("ID")) {
            return id;
        } else if (PropertyName.equals("Is Active")) {
            return isActive;
        } else if (PropertyName.equals("Code URL")) {
            return codeURL;
        } else if (PropertyName.equals("Data URL")) {
            return dataURL;
        } else if (PropertyName.equals("Experiments")) {
            return experiments;
        } else if (PropertyName.equals("Environment Nodes")) {
            return environmentNodes;
        } else if (PropertyName.equals("Environment Interfaces")) {
            return environmentInterfaces;
        } else {
            return null;
        }
    }

    @Override
    public void setProperty(String PropertyName, Object PropertyValue) {
        if (PropertyName.equals("ID")) {
            id = (String) PropertyValue;
        } else if (PropertyName.equals("Is Active")) {
            isActive = (Boolean) PropertyValue;
        } else if (PropertyName.equals("Code URL")) {
            codeURL = (String) PropertyValue;
        } else if (PropertyName.equals("Data URL")) {
            dataURL = (String) PropertyValue;
        } else if (PropertyName.equals("Experiments")) {
            experiments = (Collection) PropertyValue;
        } else if (PropertyName.equals("Environment Nodes")) {
            environmentNodes = (Collection) PropertyValue;
        } else if (PropertyName.equals("Environment Interfaces")) {
            environmentInterfaces = (Collection) PropertyValue;
        }
    }
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof EnvironmentEntity)) {
            return false;
        }
        EnvironmentEntity other = (EnvironmentEntity) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "spockdataaccess.entity.Environment[ id=" + id + " ]";
    }
    
}
